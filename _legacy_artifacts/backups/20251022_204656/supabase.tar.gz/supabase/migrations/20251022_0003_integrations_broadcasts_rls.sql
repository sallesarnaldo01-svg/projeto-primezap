-- Ensure RLS enabled and basic policies for integrations and broadcasts

-- Create tables if not exist (minimal definitions to satisfy Supabase tooling)
create extension if not exists pgcrypto;

create table if not exists public.integrations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  platform varchar(50) not null,
  name varchar(255) not null,
  status varchar(50) default 'active',
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  constraint integrations_user_id_fkey foreign key (user_id) references public.public_users(id) on delete cascade
);

create table if not exists public.broadcasts (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  name varchar(255) not null,
  status varchar(50) default 'DRAFT',
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  constraint broadcasts_tenant_id_fkey foreign key (tenant_id) references public.tenants(id) on delete cascade
);

-- integrations
alter table if exists public.integrations enable row level security;

do $$ begin
  if not exists (
    select 1 from pg_policies where schemaname = 'public' and tablename = 'integrations' and policyname = 'owner_or_tenant_select_integrations'
  ) then
    create policy owner_or_tenant_select_integrations on public.integrations
      for select
      using (
        exists (
          select 1
          from public.public_users u_cur
          where u_cur.id = auth.uid() and u_cur.tenant_id = (
            select u_owner.tenant_id from public.public_users u_owner where u_owner.id = integrations.user_id
          )
        )
      );
  end if;
end $$;

-- broadcasts
alter table if exists public.broadcasts enable row level security;

do $$ begin
  if not exists (
    select 1 from pg_policies where schemaname = 'public' and tablename = 'broadcasts' and policyname = 'tenant_select_broadcasts'
  ) then
    create policy tenant_select_broadcasts on public.broadcasts
      for select
      using (
        exists (
          select 1 from public.public_users u_cur where u_cur.id = auth.uid() and u_cur.tenant_id = broadcasts.tenant_id
        )
      );
  end if;
end $$;
