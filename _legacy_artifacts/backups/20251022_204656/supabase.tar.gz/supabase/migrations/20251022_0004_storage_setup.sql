-- Create buckets and basic RLS for Supabase Storage
create schema if not exists storage;

-- Buckets
insert into storage.buckets (id, name, public)
values ('media', 'media', true)
on conflict (id) do nothing;

insert into storage.buckets (id, name, public)
values ('knowledge', 'knowledge', false)
on conflict (id) do nothing;

-- Policies: allow read public files in 'media'
do $$ begin
  if not exists (
    select 1 from pg_policies where schemaname = 'storage' and tablename = 'objects' and policyname = 'public_read_media'
  ) then
    create policy public_read_media on storage.objects
      for select using ((bucket_id = 'media') and (visibility = 'public' or (metadata->>'isPublic')::boolean is true));
  end if;
end $$;

-- Tenant-based access for private buckets (knowledge)
do $$ begin
  if not exists (
    select 1 from pg_policies where schemaname = 'storage' and tablename = 'objects' and policyname = 'tenant_read_knowledge'
  ) then
    create policy tenant_read_knowledge on storage.objects
      for select using (
        bucket_id = 'knowledge' and exists (
          select 1 from public.public_users u where u.id = auth.uid() and u.tenant_id::text = (objects.metadata->>'tenantId')
        )
      );
  end if;
end $$;

