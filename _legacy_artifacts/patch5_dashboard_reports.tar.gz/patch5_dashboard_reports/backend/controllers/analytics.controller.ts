/**
 * Analytics Controller
 * Primeflow-Hub - Patch 5
 * 
 * Métricas e analytics em tempo real
 */

import { Request, Response } from 'express';
import { prisma } from '../lib/prisma.js';
import { analyticsService } from '../services/analytics.service.js';

export const analyticsController = {
  /**
   * Obter métricas gerais do dashboard
   * GET /api/analytics/dashboard
   */
  async getDashboardMetrics(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(401).json({ error: 'Tenant não identificado' });
      }

      const { period = '30d' } = req.query;

      const metrics = await analyticsService.getDashboardMetrics(tenantId, period as string);

      return res.json(metrics);
    } catch (error) {
      console.error('Erro ao buscar métricas do dashboard:', error);
      return res.status(500).json({ error: 'Erro ao buscar métricas' });
    }
  },

  /**
   * Obter estatísticas de conversas
   * GET /api/analytics/conversations
   */
  async getConversationStats(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(401).json({ error: 'Tenant não identificado' });
      }

      const { startDate, endDate, channel } = req.query;

      const stats = await analyticsService.getConversationStats(
        tenantId,
        startDate as string,
        endDate as string,
        channel as string
      );

      return res.json(stats);
    } catch (error) {
      console.error('Erro ao buscar estatísticas de conversas:', error);
      return res.status(500).json({ error: 'Erro ao buscar estatísticas' });
    }
  },

  /**
   * Obter estatísticas de agentes de IA
   * GET /api/analytics/ai-agents
   */
  async getAIAgentStats(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(401).json({ error: 'Tenant não identificado' });
      }

      const { startDate, endDate } = req.query;

      const stats = await analyticsService.getAIAgentStats(
        tenantId,
        startDate as string,
        endDate as string
      );

      return res.json(stats);
    } catch (error) {
      console.error('Erro ao buscar estatísticas de agentes:', error);
      return res.status(500).json({ error: 'Erro ao buscar estatísticas' });
    }
  },

  /**
   * Obter estatísticas de produtos
   * GET /api/analytics/products
   */
  async getProductStats(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(401).json({ error: 'Tenant não identificado' });
      }

      const { startDate, endDate } = req.query;

      const stats = await analyticsService.getProductStats(
        tenantId,
        startDate as string,
        endDate as string
      );

      return res.json(stats);
    } catch (error) {
      console.error('Erro ao buscar estatísticas de produtos:', error);
      return res.status(500).json({ error: 'Erro ao buscar estatísticas' });
    }
  },

  /**
   * Obter gráfico de conversas ao longo do tempo
   * GET /api/analytics/conversations/timeline
   */
  async getConversationsTimeline(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(401).json({ error: 'Tenant não identificado' });
      }

      const { startDate, endDate, granularity = 'day' } = req.query;

      const timeline = await analyticsService.getConversationsTimeline(
        tenantId,
        startDate as string,
        endDate as string,
        granularity as 'hour' | 'day' | 'week' | 'month'
      );

      return res.json(timeline);
    } catch (error) {
      console.error('Erro ao buscar timeline de conversas:', error);
      return res.status(500).json({ error: 'Erro ao buscar timeline' });
    }
  },

  /**
   * Obter distribuição de conversas por canal
   * GET /api/analytics/conversations/by-channel
   */
  async getConversationsByChannel(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(401).json({ error: 'Tenant não identificado' });
      }

      const { startDate, endDate } = req.query;

      const distribution = await analyticsService.getConversationsByChannel(
        tenantId,
        startDate as string,
        endDate as string
      );

      return res.json(distribution);
    } catch (error) {
      console.error('Erro ao buscar distribuição por canal:', error);
      return res.status(500).json({ error: 'Erro ao buscar distribuição' });
    }
  },

  /**
   * Obter top produtos mais mencionados
   * GET /api/analytics/products/top-mentioned
   */
  async getTopMentionedProducts(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(401).json({ error: 'Tenant não identificado' });
      }

      const { startDate, endDate, limit = 10 } = req.query;

      const topProducts = await analyticsService.getTopMentionedProducts(
        tenantId,
        startDate as string,
        endDate as string,
        parseInt(limit as string)
      );

      return res.json(topProducts);
    } catch (error) {
      console.error('Erro ao buscar produtos mais mencionados:', error);
      return res.status(500).json({ error: 'Erro ao buscar produtos' });
    }
  },

  /**
   * Obter taxa de conversão
   * GET /api/analytics/conversion-rate
   */
  async getConversionRate(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(401).json({ error: 'Tenant não identificado' });
      }

      const { startDate, endDate } = req.query;

      const conversionRate = await analyticsService.getConversionRate(
        tenantId,
        startDate as string,
        endDate as string
      );

      return res.json(conversionRate);
    } catch (error) {
      console.error('Erro ao buscar taxa de conversão:', error);
      return res.status(500).json({ error: 'Erro ao buscar taxa de conversão' });
    }
  },

  /**
   * Obter tempo médio de resposta
   * GET /api/analytics/response-time
   */
  async getAverageResponseTime(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(401).json({ error: 'Tenant não identificado' });
      }

      const { startDate, endDate } = req.query;

      const responseTime = await analyticsService.getAverageResponseTime(
        tenantId,
        startDate as string,
        endDate as string
      );

      return res.json(responseTime);
    } catch (error) {
      console.error('Erro ao buscar tempo de resposta:', error);
      return res.status(500).json({ error: 'Erro ao buscar tempo de resposta' });
    }
  },

  /**
   * Obter satisfação do cliente (CSAT)
   * GET /api/analytics/customer-satisfaction
   */
  async getCustomerSatisfaction(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(401).json({ error: 'Tenant não identificado' });
      }

      const { startDate, endDate } = req.query;

      const satisfaction = await analyticsService.getCustomerSatisfaction(
        tenantId,
        startDate as string,
        endDate as string
      );

      return res.json(satisfaction);
    } catch (error) {
      console.error('Erro ao buscar satisfação do cliente:', error);
      return res.status(500).json({ error: 'Erro ao buscar satisfação' });
    }
  },

  /**
   * Exportar dados de analytics
   * POST /api/analytics/export
   */
  async exportAnalytics(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(401).json({ error: 'Tenant não identificado' });
      }

      const { type, startDate, endDate, format = 'json' } = req.body;

      const data = await analyticsService.exportAnalytics(
        tenantId,
        type,
        startDate,
        endDate,
        format
      );

      if (format === 'csv') {
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', `attachment; filename="analytics-${type}-${Date.now()}.csv"`);
        return res.send(data);
      }

      return res.json(data);
    } catch (error) {
      console.error('Erro ao exportar analytics:', error);
      return res.status(500).json({ error: 'Erro ao exportar dados' });
    }
  },
};

