/**
 * Reports Controller
 * Primeflow-Hub - Patch 5
 * 
 * Geração de relatórios detalhados
 */

import { Request, Response } from 'express';
import { prisma } from '../lib/prisma.js';
import { reportsService } from '../services/reports.service.js';

export const reportsController = {
  /**
   * Gerar relatório de conversas
   * POST /api/reports/conversations
   */
  async generateConversationsReport(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(401).json({ error: 'Tenant não identificado' });
      }

      const { startDate, endDate, channel, format = 'json' } = req.body;

      const report = await reportsService.generateConversationsReport(
        tenantId,
        startDate,
        endDate,
        channel,
        format
      );

      if (format === 'pdf') {
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', `attachment; filename="relatorio-conversas-${Date.now()}.pdf"`);
        return res.send(report);
      }

      if (format === 'excel') {
        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        res.setHeader('Content-Disposition', `attachment; filename="relatorio-conversas-${Date.now()}.xlsx"`);
        return res.send(report);
      }

      return res.json(report);
    } catch (error) {
      console.error('Erro ao gerar relatório de conversas:', error);
      return res.status(500).json({ error: 'Erro ao gerar relatório' });
    }
  },

  /**
   * Gerar relatório de produtos
   * POST /api/reports/products
   */
  async generateProductsReport(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(401).json({ error: 'Tenant não identificado' });
      }

      const { startDate, endDate, category, format = 'json' } = req.body;

      const report = await reportsService.generateProductsReport(
        tenantId,
        startDate,
        endDate,
        category,
        format
      );

      if (format === 'pdf') {
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', `attachment; filename="relatorio-produtos-${Date.now()}.pdf"`);
        return res.send(report);
      }

      if (format === 'excel') {
        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        res.setHeader('Content-Disposition', `attachment; filename="relatorio-produtos-${Date.now()}.xlsx"`);
        return res.send(report);
      }

      return res.json(report);
    } catch (error) {
      console.error('Erro ao gerar relatório de produtos:', error);
      return res.status(500).json({ error: 'Erro ao gerar relatório' });
    }
  },

  /**
   * Gerar relatório de agentes de IA
   * POST /api/reports/ai-agents
   */
  async generateAIAgentsReport(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(401).json({ error: 'Tenant não identificado' });
      }

      const { startDate, endDate, agentId, format = 'json' } = req.body;

      const report = await reportsService.generateAIAgentsReport(
        tenantId,
        startDate,
        endDate,
        agentId,
        format
      );

      if (format === 'pdf') {
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', `attachment; filename="relatorio-agentes-${Date.now()}.pdf"`);
        return res.send(report);
      }

      if (format === 'excel') {
        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        res.setHeader('Content-Disposition', `attachment; filename="relatorio-agentes-${Date.now()}.xlsx"`);
        return res.send(report);
      }

      return res.json(report);
    } catch (error) {
      console.error('Erro ao gerar relatório de agentes:', error);
      return res.status(500).json({ error: 'Erro ao gerar relatório' });
    }
  },

  /**
   * Gerar relatório de performance
   * POST /api/reports/performance
   */
  async generatePerformanceReport(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(401).json({ error: 'Tenant não identificado' });
      }

      const { startDate, endDate, format = 'json' } = req.body;

      const report = await reportsService.generatePerformanceReport(
        tenantId,
        startDate,
        endDate,
        format
      );

      if (format === 'pdf') {
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', `attachment; filename="relatorio-performance-${Date.now()}.pdf"`);
        return res.send(report);
      }

      return res.json(report);
    } catch (error) {
      console.error('Erro ao gerar relatório de performance:', error);
      return res.status(500).json({ error: 'Erro ao gerar relatório' });
    }
  },

  /**
   * Listar relatórios salvos
   * GET /api/reports
   */
  async listReports(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(401).json({ error: 'Tenant não identificado' });
      }

      const { page = 1, limit = 20 } = req.query;

      const reports = await prisma.report.findMany({
        where: { tenantId },
        skip: (Number(page) - 1) * Number(limit),
        take: Number(limit),
        orderBy: { createdAt: 'desc' },
      });

      const total = await prisma.report.count({ where: { tenantId } });

      return res.json({
        data: reports,
        pagination: {
          page: Number(page),
          limit: Number(limit),
          total,
          totalPages: Math.ceil(total / Number(limit)),
        },
      });
    } catch (error) {
      console.error('Erro ao listar relatórios:', error);
      return res.status(500).json({ error: 'Erro ao listar relatórios' });
    }
  },

  /**
   * Buscar relatório por ID
   * GET /api/reports/:id
   */
  async getReportById(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(401).json({ error: 'Tenant não identificado' });
      }

      const { id } = req.params;

      const report = await prisma.report.findFirst({
        where: { id, tenantId },
      });

      if (!report) {
        return res.status(404).json({ error: 'Relatório não encontrado' });
      }

      return res.json(report);
    } catch (error) {
      console.error('Erro ao buscar relatório:', error);
      return res.status(500).json({ error: 'Erro ao buscar relatório' });
    }
  },

  /**
   * Deletar relatório
   * DELETE /api/reports/:id
   */
  async deleteReport(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(401).json({ error: 'Tenant não identificado' });
      }

      const { id } = req.params;

      const report = await prisma.report.findFirst({
        where: { id, tenantId },
      });

      if (!report) {
        return res.status(404).json({ error: 'Relatório não encontrado' });
      }

      await prisma.report.delete({ where: { id } });

      return res.status(204).send();
    } catch (error) {
      console.error('Erro ao deletar relatório:', error);
      return res.status(500).json({ error: 'Erro ao deletar relatório' });
    }
  },

  /**
   * Agendar geração de relatório
   * POST /api/reports/schedule
   */
  async scheduleReport(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(401).json({ error: 'Tenant não identificado' });
      }

      const { type, frequency, config } = req.body;

      const scheduledReport = await prisma.scheduledReport.create({
        data: {
          tenantId,
          type,
          frequency,
          config,
          isActive: true,
        },
      });

      return res.status(201).json(scheduledReport);
    } catch (error) {
      console.error('Erro ao agendar relatório:', error);
      return res.status(500).json({ error: 'Erro ao agendar relatório' });
    }
  },

  /**
   * Listar relatórios agendados
   * GET /api/reports/scheduled
   */
  async listScheduledReports(req: Request, res: Response) {
    try {
      const tenantId = req.user?.tenantId;
      if (!tenantId) {
        return res.status(401).json({ error: 'Tenant não identificado' });
      }

      const scheduledReports = await prisma.scheduledReport.findMany({
        where: { tenantId },
        orderBy: { createdAt: 'desc' },
      });

      return res.json(scheduledReports);
    } catch (error) {
      console.error('Erro ao listar relatórios agendados:', error);
      return res.status(500).json({ error: 'Erro ao listar relatórios agendados' });
    }
  },
};

