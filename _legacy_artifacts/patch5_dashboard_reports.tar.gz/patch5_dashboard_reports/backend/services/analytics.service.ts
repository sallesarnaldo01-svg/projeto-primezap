/**
 * Analytics Service
 * Primeflow-Hub - Patch 5
 * 
 * Lógica de negócio para analytics e métricas
 */

import { prisma } from '../lib/prisma.js';

export const analyticsService = {
  /**
   * Obter métricas gerais do dashboard
   */
  async getDashboardMetrics(tenantId: string, period: string) {
    const { startDate, endDate } = this.getPeriodDates(period);

    const [
      totalConversations,
      totalMessages,
      totalContacts,
      totalProducts,
      activeAIAgents,
      conversationsGrowth,
      messagesGrowth,
    ] = await Promise.all([
      // Total de conversas no período
      prisma.conversation.count({
        where: {
          tenantId,
          createdAt: { gte: startDate, lte: endDate },
        },
      }),
      // Total de mensagens no período
      prisma.message.count({
        where: {
          tenantId,
          createdAt: { gte: startDate, lte: endDate },
        },
      }),
      // Total de contatos
      prisma.contact.count({
        where: { tenantId },
      }),
      // Total de produtos
      prisma.product.count({
        where: { tenantId, isActive: true },
      }),
      // Agentes de IA ativos
      prisma.aIAgent.count({
        where: { tenantId, isActive: true },
      }),
      // Crescimento de conversas (comparar com período anterior)
      this.getGrowthRate(tenantId, 'conversation', startDate, endDate),
      // Crescimento de mensagens
      this.getGrowthRate(tenantId, 'message', startDate, endDate),
    ]);

    return {
      totalConversations,
      totalMessages,
      totalContacts,
      totalProducts,
      activeAIAgents,
      conversationsGrowth,
      messagesGrowth,
      period: {
        startDate,
        endDate,
      },
    };
  },

  /**
   * Obter estatísticas de conversas
   */
  async getConversationStats(
    tenantId: string,
    startDate?: string,
    endDate?: string,
    channel?: string
  ) {
    const where: any = { tenantId };

    if (startDate && endDate) {
      where.createdAt = {
        gte: new Date(startDate),
        lte: new Date(endDate),
      };
    }

    if (channel) {
      where.channel = channel;
    }

    const [total, active, closed, avgDuration, byStatus] = await Promise.all([
      prisma.conversation.count({ where }),
      prisma.conversation.count({ where: { ...where, status: 'active' } }),
      prisma.conversation.count({ where: { ...where, status: 'closed' } }),
      this.getAverageConversationDuration(tenantId, startDate, endDate),
      prisma.conversation.groupBy({
        by: ['status'],
        where,
        _count: true,
      }),
    ]);

    return {
      total,
      active,
      closed,
      avgDuration,
      byStatus: byStatus.map((s) => ({
        status: s.status,
        count: s._count,
      })),
    };
  },

  /**
   * Obter estatísticas de agentes de IA
   */
  async getAIAgentStats(tenantId: string, startDate?: string, endDate?: string) {
    const where: any = { tenantId };

    if (startDate && endDate) {
      where.createdAt = {
        gte: new Date(startDate),
        lte: new Date(endDate),
      };
    }

    const [totalAgents, activeAgents, totalInteractions] = await Promise.all([
      prisma.aIAgent.count({ where: { tenantId } }),
      prisma.aIAgent.count({ where: { tenantId, isActive: true } }),
      prisma.message.count({
        where: {
          tenantId,
          isFromAgent: true,
          ...(startDate && endDate
            ? { createdAt: { gte: new Date(startDate), lte: new Date(endDate) } }
            : {}),
        },
      }),
    ]);

    return {
      totalAgents,
      activeAgents,
      totalInteractions,
    };
  },

  /**
   * Obter estatísticas de produtos
   */
  async getProductStats(tenantId: string, startDate?: string, endDate?: string) {
    const [totalProducts, activeProducts, totalValue, lowStock] = await Promise.all([
      prisma.product.count({ where: { tenantId } }),
      prisma.product.count({ where: { tenantId, isActive: true } }),
      prisma.product.aggregate({
        where: { tenantId, isActive: true },
        _sum: { price: true },
      }),
      prisma.product.count({
        where: { tenantId, isActive: true, stock: { lte: 10 } },
      }),
    ]);

    return {
      totalProducts,
      activeProducts,
      totalValue: totalValue._sum.price || 0,
      lowStock,
    };
  },

  /**
   * Obter timeline de conversas
   */
  async getConversationsTimeline(
    tenantId: string,
    startDate: string,
    endDate: string,
    granularity: 'hour' | 'day' | 'week' | 'month'
  ) {
    const conversations = await prisma.conversation.findMany({
      where: {
        tenantId,
        createdAt: {
          gte: new Date(startDate),
          lte: new Date(endDate),
        },
      },
      select: {
        createdAt: true,
      },
    });

    // Agrupar por granularidade
    const grouped = this.groupByTime(conversations, granularity);

    return grouped;
  },

  /**
   * Obter distribuição de conversas por canal
   */
  async getConversationsByChannel(tenantId: string, startDate?: string, endDate?: string) {
    const where: any = { tenantId };

    if (startDate && endDate) {
      where.createdAt = {
        gte: new Date(startDate),
        lte: new Date(endDate),
      };
    }

    const distribution = await prisma.conversation.groupBy({
      by: ['channel'],
      where,
      _count: true,
    });

    return distribution.map((d) => ({
      channel: d.channel,
      count: d._count,
    }));
  },

  /**
   * Obter produtos mais mencionados
   */
  async getTopMentionedProducts(
    tenantId: string,
    startDate?: string,
    endDate?: string,
    limit: number = 10
  ) {
    // Esta é uma implementação simplificada
    // Em produção, você precisaria de uma tabela de tracking de menções
    const products = await prisma.product.findMany({
      where: { tenantId, isActive: true },
      take: limit,
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        name: true,
        price: true,
        images: true,
      },
    });

    return products.map((p) => ({
      ...p,
      mentions: Math.floor(Math.random() * 100), // Placeholder
    }));
  },

  /**
   * Obter taxa de conversão
   */
  async getConversionRate(tenantId: string, startDate?: string, endDate?: string) {
    const where: any = { tenantId };

    if (startDate && endDate) {
      where.createdAt = {
        gte: new Date(startDate),
        lte: new Date(endDate),
      };
    }

    const [totalConversations, convertedConversations] = await Promise.all([
      prisma.conversation.count({ where }),
      prisma.conversation.count({
        where: {
          ...where,
          status: 'closed',
          // Adicionar condição de conversão quando implementado
        },
      }),
    ]);

    const rate = totalConversations > 0 ? (convertedConversations / totalConversations) * 100 : 0;

    return {
      total: totalConversations,
      converted: convertedConversations,
      rate: parseFloat(rate.toFixed(2)),
    };
  },

  /**
   * Obter tempo médio de resposta
   */
  async getAverageResponseTime(tenantId: string, startDate?: string, endDate?: string) {
    // Implementação simplificada
    // Em produção, calcular baseado em timestamps de mensagens
    return {
      average: 120, // segundos
      median: 90,
      min: 30,
      max: 300,
    };
  },

  /**
   * Obter satisfação do cliente
   */
  async getCustomerSatisfaction(tenantId: string, startDate?: string, endDate?: string) {
    // Implementação simplificada
    // Em produção, buscar de tabela de feedback
    return {
      score: 4.5,
      total: 100,
      distribution: {
        5: 60,
        4: 25,
        3: 10,
        2: 3,
        1: 2,
      },
    };
  },

  /**
   * Exportar dados de analytics
   */
  async exportAnalytics(
    tenantId: string,
    type: string,
    startDate: string,
    endDate: string,
    format: string
  ) {
    let data: any;

    switch (type) {
      case 'conversations':
        data = await this.getConversationStats(tenantId, startDate, endDate);
        break;
      case 'products':
        data = await this.getProductStats(tenantId, startDate, endDate);
        break;
      case 'ai-agents':
        data = await this.getAIAgentStats(tenantId, startDate, endDate);
        break;
      default:
        throw new Error('Tipo de export inválido');
    }

    if (format === 'csv') {
      return this.convertToCSV(data);
    }

    return data;
  },

  // Funções auxiliares

  getPeriodDates(period: string) {
    const endDate = new Date();
    let startDate = new Date();

    switch (period) {
      case '7d':
        startDate.setDate(endDate.getDate() - 7);
        break;
      case '30d':
        startDate.setDate(endDate.getDate() - 30);
        break;
      case '90d':
        startDate.setDate(endDate.getDate() - 90);
        break;
      case '1y':
        startDate.setFullYear(endDate.getFullYear() - 1);
        break;
      default:
        startDate.setDate(endDate.getDate() - 30);
    }

    return { startDate, endDate };
  },

  async getGrowthRate(tenantId: string, model: string, startDate: Date, endDate: Date) {
    const periodDuration = endDate.getTime() - startDate.getTime();
    const previousStartDate = new Date(startDate.getTime() - periodDuration);

    const modelMap: any = {
      conversation: prisma.conversation,
      message: prisma.message,
    };

    const [currentCount, previousCount] = await Promise.all([
      modelMap[model].count({
        where: {
          tenantId,
          createdAt: { gte: startDate, lte: endDate },
        },
      }),
      modelMap[model].count({
        where: {
          tenantId,
          createdAt: { gte: previousStartDate, lte: startDate },
        },
      }),
    ]);

    const growth = previousCount > 0 ? ((currentCount - previousCount) / previousCount) * 100 : 0;

    return parseFloat(growth.toFixed(2));
  },

  async getAverageConversationDuration(tenantId: string, startDate?: string, endDate?: string) {
    // Implementação simplificada
    return 1800; // 30 minutos em segundos
  },

  groupByTime(data: any[], granularity: string) {
    const grouped: any = {};

    data.forEach((item) => {
      const date = new Date(item.createdAt);
      let key: string;

      switch (granularity) {
        case 'hour':
          key = `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()} ${date.getHours()}:00`;
          break;
        case 'day':
          key = `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`;
          break;
        case 'week':
          const weekNumber = this.getWeekNumber(date);
          key = `${date.getFullYear()}-W${weekNumber}`;
          break;
        case 'month':
          key = `${date.getFullYear()}-${date.getMonth() + 1}`;
          break;
        default:
          key = `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`;
      }

      grouped[key] = (grouped[key] || 0) + 1;
    });

    return Object.entries(grouped).map(([date, count]) => ({ date, count }));
  },

  getWeekNumber(date: Date) {
    const firstDayOfYear = new Date(date.getFullYear(), 0, 1);
    const pastDaysOfYear = (date.getTime() - firstDayOfYear.getTime()) / 86400000;
    return Math.ceil((pastDaysOfYear + firstDayOfYear.getDay() + 1) / 7);
  },

  convertToCSV(data: any) {
    // Implementação simplificada de conversão para CSV
    const headers = Object.keys(data).join(',');
    const values = Object.values(data).join(',');
    return `${headers}\n${values}`;
  },
};

