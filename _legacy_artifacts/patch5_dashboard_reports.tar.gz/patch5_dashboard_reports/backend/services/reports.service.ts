/**
 * Reports Service
 * Primeflow-Hub - Patch 5
 * 
 * Geração de relatórios em múltiplos formatos
 */

import { prisma } from '../lib/prisma.js';
import PDFDocument from 'pdfkit';
import ExcelJS from 'exceljs';

export const reportsService = {
  /**
   * Gerar relatório de conversas
   */
  async generateConversationsReport(
    tenantId: string,
    startDate: string,
    endDate: string,
    channel?: string,
    format: string = 'json'
  ) {
    const where: any = {
      tenantId,
      createdAt: {
        gte: new Date(startDate),
        lte: new Date(endDate),
      },
    };

    if (channel) {
      where.channel = channel;
    }

    const conversations = await prisma.conversation.findMany({
      where,
      include: {
        contact: {
          select: {
            name: true,
            phone: true,
          },
        },
        _count: {
          select: { messages: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    const stats = {
      total: conversations.length,
      byChannel: await this.groupByField(conversations, 'channel'),
      byStatus: await this.groupByField(conversations, 'status'),
      totalMessages: conversations.reduce((sum, c) => sum + c._count.messages, 0),
    };

    const reportData = {
      title: 'Relatório de Conversas',
      period: { startDate, endDate },
      stats,
      conversations: conversations.map((c) => ({
        id: c.id,
        contactName: c.contact?.name || 'Desconhecido',
        contactPhone: c.contact?.phone || '',
        channel: c.channel,
        status: c.status,
        messagesCount: c._count.messages,
        createdAt: c.createdAt,
        updatedAt: c.updatedAt,
      })),
    };

    if (format === 'pdf') {
      return this.generatePDF(reportData);
    }

    if (format === 'excel') {
      return this.generateExcel(reportData);
    }

    // Salvar relatório no banco
    await this.saveReport(tenantId, 'conversations', reportData);

    return reportData;
  },

  /**
   * Gerar relatório de produtos
   */
  async generateProductsReport(
    tenantId: string,
    startDate: string,
    endDate: string,
    category?: string,
    format: string = 'json'
  ) {
    const where: any = { tenantId };

    if (category) {
      where.category = category;
    }

    const products = await prisma.product.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    });

    const stats = {
      total: products.length,
      active: products.filter((p) => p.isActive).length,
      inactive: products.filter((p) => !p.isActive).length,
      totalValue: products.reduce((sum, p) => sum + p.price, 0),
      totalStock: products.reduce((sum, p) => sum + (p.stock || 0), 0),
      byCategory: await this.groupByField(products, 'category'),
    };

    const reportData = {
      title: 'Relatório de Produtos',
      period: { startDate, endDate },
      stats,
      products: products.map((p) => ({
        id: p.id,
        name: p.name,
        sku: p.sku,
        price: p.price,
        stock: p.stock,
        category: p.category,
        isActive: p.isActive,
        createdAt: p.createdAt,
      })),
    };

    if (format === 'pdf') {
      return this.generatePDF(reportData);
    }

    if (format === 'excel') {
      return this.generateExcel(reportData);
    }

    await this.saveReport(tenantId, 'products', reportData);

    return reportData;
  },

  /**
   * Gerar relatório de agentes de IA
   */
  async generateAIAgentsReport(
    tenantId: string,
    startDate: string,
    endDate: string,
    agentId?: string,
    format: string = 'json'
  ) {
    const where: any = { tenantId };

    if (agentId) {
      where.id = agentId;
    }

    const agents = await prisma.aIAgent.findMany({
      where,
      include: {
        _count: {
          select: { conversations: true },
        },
      },
    });

    const stats = {
      total: agents.length,
      active: agents.filter((a) => a.isActive).length,
      inactive: agents.filter((a) => !a.isActive).length,
      totalConversations: agents.reduce((sum, a) => sum + a._count.conversations, 0),
    };

    const reportData = {
      title: 'Relatório de Agentes de IA',
      period: { startDate, endDate },
      stats,
      agents: agents.map((a) => ({
        id: a.id,
        name: a.name,
        model: a.model,
        isActive: a.isActive,
        conversationsCount: a._count.conversations,
        createdAt: a.createdAt,
      })),
    };

    if (format === 'pdf') {
      return this.generatePDF(reportData);
    }

    if (format === 'excel') {
      return this.generateExcel(reportData);
    }

    await this.saveReport(tenantId, 'ai-agents', reportData);

    return reportData;
  },

  /**
   * Gerar relatório de performance
   */
  async generatePerformanceReport(
    tenantId: string,
    startDate: string,
    endDate: string,
    format: string = 'json'
  ) {
    const where = {
      tenantId,
      createdAt: {
        gte: new Date(startDate),
        lte: new Date(endDate),
      },
    };

    const [conversationsCount, messagesCount, contactsCount, productsCount] = await Promise.all([
      prisma.conversation.count({ where }),
      prisma.message.count({ where }),
      prisma.contact.count({ where: { tenantId } }),
      prisma.product.count({ where: { tenantId } }),
    ]);

    const reportData = {
      title: 'Relatório de Performance',
      period: { startDate, endDate },
      metrics: {
        conversations: conversationsCount,
        messages: messagesCount,
        contacts: contactsCount,
        products: productsCount,
        avgMessagesPerConversation:
          conversationsCount > 0 ? (messagesCount / conversationsCount).toFixed(2) : 0,
      },
    };

    if (format === 'pdf') {
      return this.generatePDF(reportData);
    }

    await this.saveReport(tenantId, 'performance', reportData);

    return reportData;
  },

  // Funções auxiliares

  async groupByField(data: any[], field: string) {
    const grouped: any = {};

    data.forEach((item) => {
      const key = item[field] || 'Não definido';
      grouped[key] = (grouped[key] || 0) + 1;
    });

    return grouped;
  },

  async saveReport(tenantId: string, type: string, data: any) {
    try {
      await prisma.report.create({
        data: {
          tenantId,
          type,
          title: data.title,
          data: data,
          generatedAt: new Date(),
        },
      });
    } catch (error) {
      console.error('Erro ao salvar relatório:', error);
    }
  },

  /**
   * Gerar PDF do relatório
   */
  async generatePDF(reportData: any): Promise<Buffer> {
    return new Promise((resolve, reject) => {
      try {
        const doc = new PDFDocument({ margin: 50 });
        const chunks: Buffer[] = [];

        doc.on('data', (chunk) => chunks.push(chunk));
        doc.on('end', () => resolve(Buffer.concat(chunks)));
        doc.on('error', reject);

        // Cabeçalho
        doc
          .fontSize(20)
          .text(reportData.title, { align: 'center' })
          .moveDown();

        // Período
        if (reportData.period) {
          doc
            .fontSize(12)
            .text(
              `Período: ${new Date(reportData.period.startDate).toLocaleDateString('pt-BR')} - ${new Date(reportData.period.endDate).toLocaleDateString('pt-BR')}`,
              { align: 'center' }
            )
            .moveDown(2);
        }

        // Estatísticas
        if (reportData.stats) {
          doc.fontSize(16).text('Estatísticas', { underline: true }).moveDown();

          Object.entries(reportData.stats).forEach(([key, value]) => {
            if (typeof value === 'object') {
              doc.fontSize(12).text(`${key}:`, { underline: true });
              Object.entries(value as any).forEach(([subKey, subValue]) => {
                doc.fontSize(10).text(`  ${subKey}: ${subValue}`);
              });
              doc.moveDown();
            } else {
              doc.fontSize(12).text(`${key}: ${value}`);
            }
          });

          doc.moveDown(2);
        }

        // Métricas
        if (reportData.metrics) {
          doc.fontSize(16).text('Métricas', { underline: true }).moveDown();

          Object.entries(reportData.metrics).forEach(([key, value]) => {
            doc.fontSize(12).text(`${key}: ${value}`);
          });

          doc.moveDown(2);
        }

        // Rodapé
        doc
          .fontSize(8)
          .text(
            `Gerado em: ${new Date().toLocaleString('pt-BR')}`,
            50,
            doc.page.height - 50,
            { align: 'center' }
          );

        doc.end();
      } catch (error) {
        reject(error);
      }
    });
  },

  /**
   * Gerar Excel do relatório
   */
  async generateExcel(reportData: any): Promise<Buffer> {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Relatório');

    // Cabeçalho
    worksheet.addRow([reportData.title]);
    worksheet.addRow([]);

    // Período
    if (reportData.period) {
      worksheet.addRow([
        'Período:',
        `${new Date(reportData.period.startDate).toLocaleDateString('pt-BR')} - ${new Date(reportData.period.endDate).toLocaleDateString('pt-BR')}`,
      ]);
      worksheet.addRow([]);
    }

    // Estatísticas
    if (reportData.stats) {
      worksheet.addRow(['Estatísticas']);
      Object.entries(reportData.stats).forEach(([key, value]) => {
        if (typeof value === 'object') {
          worksheet.addRow([key]);
          Object.entries(value as any).forEach(([subKey, subValue]) => {
            worksheet.addRow(['', subKey, subValue]);
          });
        } else {
          worksheet.addRow([key, value]);
        }
      });
      worksheet.addRow([]);
    }

    // Dados detalhados (conversas, produtos, etc.)
    if (reportData.conversations) {
      worksheet.addRow(['Conversas']);
      worksheet.addRow([
        'ID',
        'Contato',
        'Telefone',
        'Canal',
        'Status',
        'Mensagens',
        'Criado em',
      ]);

      reportData.conversations.forEach((c: any) => {
        worksheet.addRow([
          c.id,
          c.contactName,
          c.contactPhone,
          c.channel,
          c.status,
          c.messagesCount,
          new Date(c.createdAt).toLocaleString('pt-BR'),
        ]);
      });
    }

    if (reportData.products) {
      worksheet.addRow(['Produtos']);
      worksheet.addRow(['ID', 'Nome', 'SKU', 'Preço', 'Estoque', 'Categoria', 'Ativo']);

      reportData.products.forEach((p: any) => {
        worksheet.addRow([
          p.id,
          p.name,
          p.sku,
          p.price,
          p.stock,
          p.category,
          p.isActive ? 'Sim' : 'Não',
        ]);
      });
    }

    return await workbook.xlsx.writeBuffer() as Buffer;
  },
};

