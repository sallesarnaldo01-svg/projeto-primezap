-- ============================================================
-- Patch 5: Dashboard e Reports - Database Migration
-- Primeflow-Hub
-- Versão: 1.0.0
-- Data: 12/10/2025
-- ============================================================

-- Tabela de Relatórios
CREATE TABLE IF NOT EXISTS reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  type VARCHAR(50) NOT NULL, -- 'conversations', 'products', 'ai-agents', 'performance'
  title VARCHAR(255) NOT NULL,
  data JSONB NOT NULL DEFAULT '{}',
  generated_at TIMESTAMP NOT NULL DEFAULT NOW(),
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Índices para relatórios
CREATE INDEX IF NOT EXISTS idx_reports_tenant ON reports(tenant_id);
CREATE INDEX IF NOT EXISTS idx_reports_type ON reports(type);
CREATE INDEX IF NOT EXISTS idx_reports_generated ON reports(generated_at DESC);
CREATE INDEX IF NOT EXISTS idx_reports_created ON reports(created_at DESC);

-- Tabela de Relatórios Agendados
CREATE TABLE IF NOT EXISTS scheduled_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  type VARCHAR(50) NOT NULL,
  frequency VARCHAR(20) NOT NULL, -- 'daily', 'weekly', 'monthly'
  config JSONB NOT NULL DEFAULT '{}',
  is_active BOOLEAN DEFAULT true,
  last_run_at TIMESTAMP,
  next_run_at TIMESTAMP,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Índices para relatórios agendados
CREATE INDEX IF NOT EXISTS idx_scheduled_reports_tenant ON scheduled_reports(tenant_id);
CREATE INDEX IF NOT EXISTS idx_scheduled_reports_active ON scheduled_reports(is_active);
CREATE INDEX IF NOT EXISTS idx_scheduled_reports_next_run ON scheduled_reports(next_run_at);

-- Tabela de Cache de Métricas (para otimização)
CREATE TABLE IF NOT EXISTS metrics_cache (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  metric_key VARCHAR(100) NOT NULL,
  metric_value JSONB NOT NULL,
  period_start TIMESTAMP NOT NULL,
  period_end TIMESTAMP NOT NULL,
  expires_at TIMESTAMP NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  UNIQUE(tenant_id, metric_key, period_start, period_end)
);

-- Índices para cache de métricas
CREATE INDEX IF NOT EXISTS idx_metrics_cache_tenant ON metrics_cache(tenant_id);
CREATE INDEX IF NOT EXISTS idx_metrics_cache_key ON metrics_cache(metric_key);
CREATE INDEX IF NOT EXISTS idx_metrics_cache_expires ON metrics_cache(expires_at);

-- View para estatísticas de conversas (otimização de queries)
CREATE OR REPLACE VIEW conversation_stats AS
SELECT
  c.tenant_id,
  c.channel,
  c.status,
  DATE(c.created_at) as date,
  COUNT(*) as conversation_count,
  COUNT(DISTINCT c.contact_id) as unique_contacts,
  SUM((SELECT COUNT(*) FROM messages m WHERE m.conversation_id = c.id)) as total_messages
FROM conversations c
GROUP BY c.tenant_id, c.channel, c.status, DATE(c.created_at);

-- View para estatísticas de produtos
CREATE OR REPLACE VIEW product_stats AS
SELECT
  p.tenant_id,
  p.category,
  p.is_active,
  COUNT(*) as product_count,
  SUM(p.price) as total_value,
  SUM(p.stock) as total_stock,
  AVG(p.price) as avg_price
FROM products p
GROUP BY p.tenant_id, p.category, p.is_active;

-- View para estatísticas de agentes de IA
CREATE OR REPLACE VIEW ai_agent_stats AS
SELECT
  a.tenant_id,
  a.model,
  a.is_active,
  COUNT(*) as agent_count,
  COUNT(DISTINCT c.id) as conversation_count,
  COUNT(DISTINCT m.id) as message_count
FROM ai_agents a
LEFT JOIN conversations c ON c.ai_agent_id = a.id
LEFT JOIN messages m ON m.conversation_id = c.id AND m.is_from_agent = true
GROUP BY a.tenant_id, a.model, a.is_active;

-- Função para limpar cache expirado
CREATE OR REPLACE FUNCTION clean_expired_metrics_cache()
RETURNS void AS $$
BEGIN
  DELETE FROM metrics_cache WHERE expires_at < NOW();
END;
$$ LANGUAGE plpgsql;

-- Função para calcular próxima execução de relatório agendado
CREATE OR REPLACE FUNCTION calculate_next_run(frequency VARCHAR, last_run TIMESTAMP)
RETURNS TIMESTAMP AS $$
BEGIN
  CASE frequency
    WHEN 'daily' THEN
      RETURN COALESCE(last_run, NOW()) + INTERVAL '1 day';
    WHEN 'weekly' THEN
      RETURN COALESCE(last_run, NOW()) + INTERVAL '1 week';
    WHEN 'monthly' THEN
      RETURN COALESCE(last_run, NOW()) + INTERVAL '1 month';
    ELSE
      RETURN COALESCE(last_run, NOW()) + INTERVAL '1 day';
  END CASE;
END;
$$ LANGUAGE plpgsql;

-- Trigger para atualizar updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS update_reports_updated_at ON reports;
CREATE TRIGGER update_reports_updated_at
  BEFORE UPDATE ON reports
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_scheduled_reports_updated_at ON scheduled_reports;
CREATE TRIGGER update_scheduled_reports_updated_at
  BEFORE UPDATE ON scheduled_reports
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Trigger para calcular next_run_at automaticamente
CREATE OR REPLACE FUNCTION set_next_run_at()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.is_active = true THEN
    NEW.next_run_at = calculate_next_run(NEW.frequency, NEW.last_run_at);
  ELSE
    NEW.next_run_at = NULL;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS set_scheduled_report_next_run ON scheduled_reports;
CREATE TRIGGER set_scheduled_report_next_run
  BEFORE INSERT OR UPDATE ON scheduled_reports
  FOR EACH ROW
  EXECUTE FUNCTION set_next_run_at();

-- Job para limpar cache expirado (executar periodicamente via cron ou scheduler)
-- SELECT clean_expired_metrics_cache();

-- Comentários nas tabelas
COMMENT ON TABLE reports IS 'Relatórios gerados e salvos';
COMMENT ON TABLE scheduled_reports IS 'Relatórios agendados para geração automática';
COMMENT ON TABLE metrics_cache IS 'Cache de métricas para otimização de performance';
COMMENT ON VIEW conversation_stats IS 'Estatísticas agregadas de conversas';
COMMENT ON VIEW product_stats IS 'Estatísticas agregadas de produtos';
COMMENT ON VIEW ai_agent_stats IS 'Estatísticas agregadas de agentes de IA';

-- Permissões (ajustar conforme necessário)
-- GRANT SELECT, INSERT, UPDATE, DELETE ON reports TO primeflow_api;
-- GRANT SELECT, INSERT, UPDATE, DELETE ON scheduled_reports TO primeflow_api;
-- GRANT SELECT, INSERT, UPDATE, DELETE ON metrics_cache TO primeflow_api;
-- GRANT SELECT ON conversation_stats TO primeflow_api;
-- GRANT SELECT ON product_stats TO primeflow_api;
-- GRANT SELECT ON ai_agent_stats TO primeflow_api;

-- ============================================================
-- Fim da Migration
-- ============================================================

