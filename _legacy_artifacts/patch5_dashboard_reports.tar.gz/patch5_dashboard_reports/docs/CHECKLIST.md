# ✅ Checklist de Validação - Patch 5: Dashboard e Reports

**Projeto**: Primeflow-Hub  
**Versão**: 1.0.0  
**Data**: 12/10/2025

---

## Instruções

Use este checklist para validar a instalação e o funcionamento do **Patch 5**. Marque cada item como `[x]` após a conclusão e verificação bem-sucedida.

---

## 1. Verificação da Instalação

| Status | Tarefa | Detalhes |
| :----: | ------ | -------- |
| `[ ]` | **Arquivos do Backend Copiados** | Verifique se os controllers e services estão em `apps/api/src/`. |
| `[ ]` | **Arquivos do Frontend Copiados** | Verifique se as páginas, hooks e services estão em `apps/front/src/`. |
| `[ ]` | **Dependências Instaladas** | Confirme que `pdfkit`, `exceljs`, `recharts`, `lucide-react` e `date-fns` foram adicionados aos `package.json` corretos e instalados. |
| `[ ]` | **Migration do Banco de Dados Aplicada** | Confirme que as tabelas `reports`, `scheduled_reports`, `metrics_cache` e as views (`conversation_stats`, etc.) existem no banco de dados. |
| `[ ]` | **Rotas do Backend Adicionadas** | Verifique se as novas rotas de analytics e reports foram adicionadas ao `apps/api/src/index.ts`. |
| `[ ]` | **Rotas do Frontend Adicionadas** | Verifique se as rotas para `/dashboard` e `/relatorios` foram adicionadas no `App.tsx` ou similar. |
| `[ ]` | **Links de Navegação Adicionados** | Confirme que os links para "Dashboard" e "Relatórios" aparecem no menu lateral. |
| `[ ]` | **Aplicação Reiniciada** | Garanta que o servidor foi reiniciado após todas as alterações. |

---

## 2. Validação do Dashboard

| Status | Tarefa | Passos para Validar |
| :----: | ------ | ------------------- |
| `[ ]` | **Acesso à Página do Dashboard** | 1. Clique no link "Dashboard" no menu. <br> 2. A página deve carregar sem erros. |
| `[ ]` | **Carregamento dos Cards de Métricas** | 1. Verifique se os cards (Conversas, Mensagens, Contatos, Produtos) exibem números. <br> 2. Os números devem parecer razoáveis (não devem ser zero se houver dados). |
| `[ ]` | **Filtro de Período** | 1. Altere o período (ex: "Últimos 7 dias"). <br> 2. Os dados nos cards e gráficos devem ser atualizados. |
| `[ ]` | **Gráfico de Timeline de Conversas** | 1. Verifique se o gráfico de linha é exibido. <br> 2. O gráfico deve mostrar a tendência de conversas ao longo do tempo. |
| `[ ]` | **Gráfico de Distribuição por Canal** | 1. Verifique se o gráfico de pizza é exibido. <br> 2. O gráfico deve mostrar a proporção de conversas por canal (WhatsApp, Facebook, etc.). |
| `[ ]` | **Responsividade** | 1. Redimensione a janela do navegador. <br> 2. Os cards e gráficos devem se ajustar ao novo tamanho da tela sem quebrar o layout. |

---

## 3. Validação dos Relatórios

| Status | Tarefa | Passos para Validar |
| :----: | ------ | ------------------- |
| `[ ]` | **Acesso à Página de Relatórios** | 1. Clique no link "Relatórios" no menu. <br> 2. A página deve carregar sem erros. |
| `[ ]` | **Geração de Relatório (JSON)** | 1. Clique em "Gerar Relatório". <br> 2. Selecione o tipo "Conversas", formato "JSON (Salvar)" e um período com dados. <br> 3. Clique em "Gerar". <br> 4. Um novo relatório deve aparecer na lista. |
| `[ ]` | **Geração e Download de Relatório (PDF)** | 1. Clique em "Gerar Relatório". <br> 2. Selecione o tipo "Produtos", formato "PDF (Download)" e um período. <br> 3. Clique em "Gerar". <br> 4. O download de um arquivo PDF deve iniciar. <br> 5. Abra o PDF e verifique se o conteúdo está correto. |
| `[ ]` | **Geração e Download de Relatório (Excel)** | 1. Clique em "Gerar Relatório". <br> 2. Selecione o tipo "Performance", formato "Excel (Download)" e um período. <br> 3. Clique em "Gerar". <br> 4. O download de um arquivo `.xlsx` deve iniciar. <br> 5. Abra a planilha e verifique se os dados estão corretos e bem formatados. |
| `[ ]` | **Listagem de Relatórios Salvos** | 1. Verifique se os relatórios gerados em formato JSON aparecem na lista. <br> 2. As informações (título, tipo, data) devem estar corretas. |
| `[ ]` | **Deleção de Relatório** | 1. Clique no ícone de lixeira em um dos relatórios salvos. <br> 2. Confirme a exclusão. <br> 3. O relatório deve desaparecer da lista. |

---

## 4. Validação da Base de Dados

| Status | Tarefa | Passos para Validar |
| :----: | ------ | ------------------- |
| `[ ]` | **Tabela `reports`** | 1. Conecte-se ao banco de dados. <br> 2. Execute `SELECT * FROM reports;`. <br> 3. Verifique se os relatórios salvos (JSON) estão sendo registrados corretamente. |
| `[ ]` | **Views de Analytics** | 1. Execute `SELECT * FROM conversation_stats LIMIT 10;`. <br> 2. A view deve retornar dados agregados sem erros. <br> 3. Repita para `product_stats` e `ai_agent_stats`. |

---

**Validação concluída!** Se todos os itens foram marcados, o Patch 5 foi instalado e configurado com sucesso.

