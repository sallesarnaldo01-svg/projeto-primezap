# 📖 Guia de Configuração - Patch 5: Dashboard e Reports

**Projeto**: Primeflow-Hub  
**Versão**: 1.0.0  
**Data**: 12/10/2025

---

## 1. Visão Geral

Este guia fornece instruções detalhadas para instalar e configurar o **Patch 5**, que adiciona funcionalidades de **Dashboard, Analytics e Relatórios** ao Primeflow-Hub. Siga os passos cuidadosamente para garantir uma implementação bem-sucedida.

---

## 2. Pré-requisitos

Antes de iniciar a instalação, certifique-se de que seu ambiente atende aos seguintes requisitos:

### Dependências do Sistema
- **Node.js**: v18.x ou superior
- **PNPM**: v8.x ou superior
- **PostgreSQL**: v12 ou superior

### Dependências do Projeto (Novas)

As seguintes dependências serão instaladas pelo script, mas é bom estar ciente delas:

**Backend**:
- `pdfkit`: Para geração de relatórios em PDF.
- `exceljs`: Para geração de relatórios em Excel.
- `@types/pdfkit`: Tipos para `pdfkit`.

**Frontend**:
- `recharts`: Para criação de gráficos interativos.
- `lucide-react`: Biblioteca de ícones.
- `date-fns`: Para formatação de datas.

### Patches Anteriores
- É **obrigatório** que os Patches 1, 2, 3 e 4 já estejam instalados e funcionando corretamente.

---

## 3. Instalação

A instalação pode ser feita de forma automática (recomendado) ou manual.

### 3.1. Método Automático (Recomendado)

O script `install.sh` automatiza todo o processo de cópia de arquivos e instalação de dependências.

**Tempo estimado**: 5-10 minutos.

**Passos**:

1.  **Faça o Upload e Extraia o Pacote**:
    - Envie o arquivo `patch5_dashboard_reports.tar.gz` para o diretório `/home/administrator` do seu servidor.
    - Conecte-se ao servidor via SSH e execute os seguintes comandos:

    ```bash
    # Navegue até o diretório
    cd /home/administrator

    # Extraia o pacote do patch
    tar -xzf patch5_dashboard_reports.tar.gz

    # Entre no diretório do patch
    cd patch5_dashboard_reports
    ```

2.  **Execute o Script de Instalação**:
    - O script de instalação precisa de um argumento: o caminho completo para o diretório principal do projeto Primeflow-Hub.

    ```bash
    # Dê permissão de execução ao script
    chmod +x scripts/install.sh

    # Execute o script com o caminho do projeto como argumento
    # Exemplo: /home/administrator/unified/primeflow-hub-main
    sudo bash scripts/install.sh /caminho/para/seu/projeto/primeflow-hub
    ```

    O script irá:
    - Copiar os arquivos do backend, frontend e database para os locais corretos.
    - Instalar as novas dependências (`pdfkit`, `exceljs`, `recharts`, etc.) usando `pnpm`.

3.  **Aplique a Migration do Banco de Dados**:
    - A migration adiciona as tabelas e views necessárias para o sistema de analytics.

    ```bash
    # Execute o arquivo SQL na sua base de dados
    # Substitua [usuario], [banco] e [senha] pelos seus dados
    PGPASSWORD="[senha]" psql -h localhost -U [usuario] -d [banco] -f database/001_reports_analytics.sql
    ```

4.  **Reinicie a Aplicação**:
    - Navegue até o diretório do projeto e reinicie o servidor para que as alterações tenham efeito.

    ```bash
    cd /caminho/para/seu/projeto/primeflow-hub
    pnpm dev
    ```

### 3.2. Método Manual

Se preferir, você pode copiar os arquivos e instalar as dependências manualmente.

1.  **Copie os Arquivos do Backend**:
    - Copie o conteúdo de `patch5_dashboard_reports/backend/` para `[seu_projeto]/apps/api/src/`.

2.  **Copie os Arquivos do Frontend**:
    - Copie o conteúdo de `patch5_dashboard_reports/frontend/` para `[seu_projeto]/apps/front/src/`.

3.  **Instale as Dependências**:
    - Navegue até o diretório raiz do seu projeto e execute:

    ```bash
    # Dependências do Backend
    pnpm add pdfkit exceljs
    pnpm add -D @types/pdfkit

    # Dependências do Frontend
    pnpm add recharts lucide-react date-fns
    ```

4.  **Aplique a Migration e Reinicie**:
    - Siga os passos 3 e 4 do método automático.

---

## 4. Configuração Pós-Instalação

Após a instalação, algumas configurações manuais são necessárias para integrar as novas funcionalidades à aplicação existente.

### 4.1. Adicionar Rotas no Backend

Edite o arquivo `[seu_projeto]/apps/api/src/index.ts` e adicione as seguintes rotas:

```typescript
// Importe os novos controllers no início do arquivo
import { analyticsController } from './controllers/analytics.controller';
import { reportsController } from './controllers/reports.controller';

// ... (código existente)

// Adicione as rotas de Analytics
app.get('/api/analytics/dashboard', analyticsController.getDashboardMetrics);
app.get('/api/analytics/conversations', analyticsController.getConversationStats);
app.get('/api/analytics/conversations/timeline', analyticsController.getConversationsTimeline);
app.get('/api/analytics/conversations/by-channel', analyticsController.getConversationsByChannel);
// ... (adicione todas as outras rotas do analytics.controller.ts)

// Adicione as rotas de Reports
app.post('/api/reports/conversations', reportsController.generateConversationsReport);
app.post('/api/reports/products', reportsController.generateProductsReport);
app.get('/api/reports', reportsController.listReports);
app.delete('/api/reports/:id', reportsController.deleteReport);
// ... (adicione todas as outras rotas do reports.controller.ts)
```

### 4.2. Adicionar Páginas no Frontend

Edite o arquivo de rotas do seu frontend (geralmente `[seu_projeto]/apps/front/src/App.tsx` ou similar) e adicione as novas páginas:

```typescript
// Importe as novas páginas
import Dashboard from './pages/Dashboard';
import Relatorios from './pages/Relatorios';

// ... (código existente)

// Adicione as rotas dentro do seu Router
<Route path="/dashboard" element={<Dashboard />} />
<Route path="/relatorios" element={<Relatorios />} />
```

### 4.3. Adicionar Links no Menu de Navegação

Edite o componente da barra lateral (ex: `[seu_projeto]/apps/front/src/components/Sidebar.tsx`) e adicione os links para as novas páginas.

```typescript
// Importe os ícones
import { LayoutDashboard, FileText } from 'lucide-react';

// Adicione os itens ao seu array de navegação
{
  name: 'Dashboard',
  href: '/dashboard',
  icon: LayoutDashboard,
},
{
  name: 'Relatórios',
  href: '/relatorios',
  icon: FileText,
},
```

---

## 5. Troubleshooting

### Problema: Gráficos não aparecem ou aparecem quebrados.
- **Causa**: A dependência `recharts` pode não ter sido instalada corretamente.
- **Solução**: Rode `pnpm install` na raiz do projeto para garantir que todas as dependências estão instaladas. Limpe o cache do seu navegador.

### Problema: Erro ao gerar relatórios em PDF/Excel.
- **Causa**: As dependências `pdfkit` ou `exceljs` podem estar faltando no backend.
- **Solução**: Navegue até `[seu_projeto]/apps/api` e rode `pnpm install pdfkit exceljs`. Reinicie o servidor.

### Problema: Erro 500 ao acessar as páginas de Dashboard ou Relatórios.
- **Causa**: A migration do banco de dados pode não ter sido aplicada corretamente, ou as rotas do backend não foram adicionadas.
- **Solução**: Verifique se a migration foi executada sem erros. Confira se todas as rotas foram adicionadas corretamente no `index.ts` do backend.

---

**Instalação concluída!** Agora você pode acessar as novas funcionalidades de Dashboard e Relatórios no seu Primeflow-Hub.

