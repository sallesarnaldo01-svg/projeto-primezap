/**
 * useDashboard Hook
 * Primeflow-Hub - Patch 5
 */

import { useState, useCallback } from 'react';
import { analyticsService } from '../services/analytics.service';

interface DashboardMetrics {
  totalConversations: number;
  totalMessages: number;
  totalContacts: number;
  totalProducts: number;
  activeAIAgents: number;
  conversationsGrowth: number;
  messagesGrowth: number;
  period: {
    startDate: string;
    endDate: string;
  };
}

interface ConversationStats {
  total: number;
  active: number;
  closed: number;
  avgDuration: number;
  byStatus: Array<{ status: string; count: number }>;
}

interface TimelineData {
  date: string;
  count: number;
}

interface ChannelDistribution {
  channel: string;
  count: number;
}

export function useDashboard() {
  const [metrics, setMetrics] = useState<DashboardMetrics | null>(null);
  const [conversationStats, setConversationStats] = useState<ConversationStats | null>(null);
  const [timeline, setTimeline] = useState<TimelineData[]>([]);
  const [channelDistribution, setChannelDistribution] = useState<ChannelDistribution[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchDashboardMetrics = useCallback(async (period: string = '30d') => {
    setLoading(true);
    setError(null);
    try {
      const data = await analyticsService.getDashboardMetrics(period);
      setMetrics(data);
    } catch (err: any) {
      setError(err.message || 'Erro ao buscar métricas');
      console.error('Erro ao buscar métricas:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchConversationStats = useCallback(
    async (startDate?: string, endDate?: string, channel?: string) => {
      setLoading(true);
      setError(null);
      try {
        const data = await analyticsService.getConversationStats(startDate, endDate, channel);
        setConversationStats(data);
      } catch (err: any) {
        setError(err.message || 'Erro ao buscar estatísticas');
        console.error('Erro ao buscar estatísticas:', err);
      } finally {
        setLoading(false);
      }
    },
    []
  );

  const fetchConversationsTimeline = useCallback(
    async (period: string = '30d', granularity: 'hour' | 'day' | 'week' | 'month' = 'day') => {
      setLoading(true);
      setError(null);
      try {
        const { startDate, endDate } = getPeriodDates(period);
        const data = await analyticsService.getConversationsTimeline(
          startDate,
          endDate,
          granularity
        );
        setTimeline(data);
      } catch (err: any) {
        setError(err.message || 'Erro ao buscar timeline');
        console.error('Erro ao buscar timeline:', err);
      } finally {
        setLoading(false);
      }
    },
    []
  );

  const fetchConversationsByChannel = useCallback(async (period: string = '30d') => {
    setLoading(true);
    setError(null);
    try {
      const { startDate, endDate } = getPeriodDates(period);
      const data = await analyticsService.getConversationsByChannel(startDate, endDate);
      setChannelDistribution(data);
    } catch (err: any) {
      setError(err.message || 'Erro ao buscar distribuição');
      console.error('Erro ao buscar distribuição:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    metrics,
    conversationStats,
    timeline,
    channelDistribution,
    loading,
    error,
    fetchDashboardMetrics,
    fetchConversationStats,
    fetchConversationsTimeline,
    fetchConversationsByChannel,
  };
}

// Função auxiliar para calcular datas do período
function getPeriodDates(period: string) {
  const endDate = new Date().toISOString();
  let startDate = new Date();

  switch (period) {
    case '7d':
      startDate.setDate(startDate.getDate() - 7);
      break;
    case '30d':
      startDate.setDate(startDate.getDate() - 30);
      break;
    case '90d':
      startDate.setDate(startDate.getDate() - 90);
      break;
    case '1y':
      startDate.setFullYear(startDate.getFullYear() - 1);
      break;
    default:
      startDate.setDate(startDate.getDate() - 30);
  }

  return {
    startDate: startDate.toISOString(),
    endDate,
  };
}

