/**
 * useReports Hook
 * Primeflow-Hub - Patch 5
 */

import { useState, useCallback } from 'react';
import { reportsService } from '../services/reports.service';

interface Report {
  id: string;
  type: string;
  title: string;
  data: any;
  generatedAt: string;
  createdAt: string;
}

interface Pagination {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

interface GenerateReportParams {
  type: string;
  format: string;
  startDate: string;
  endDate: string;
  channel?: string;
  category?: string;
  agentId?: string;
}

export function useReports() {
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pagination, setPagination] = useState<Pagination | null>(null);

  const fetchReports = useCallback(async (params?: { page?: number; limit?: number }) => {
    setLoading(true);
    setError(null);
    try {
      const response = await reportsService.list(params);
      setReports(response.data);
      setPagination(response.pagination);
    } catch (err: any) {
      setError(err.message || 'Erro ao buscar relatórios');
      console.error('Erro ao buscar relatórios:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  const generateReport = useCallback(async (params: GenerateReportParams) => {
    setLoading(true);
    setError(null);
    try {
      const result = await reportsService.generate(params);
      return result;
    } catch (err: any) {
      setError(err.message || 'Erro ao gerar relatório');
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const deleteReport = useCallback(async (id: string) => {
    setLoading(true);
    setError(null);
    try {
      await reportsService.delete(id);
      setReports((prev) => prev.filter((r) => r.id !== id));
    } catch (err: any) {
      setError(err.message || 'Erro ao deletar relatório');
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const scheduleReport = useCallback(
    async (type: string, frequency: string, config: any) => {
      setLoading(true);
      setError(null);
      try {
        const result = await reportsService.schedule(type, frequency, config);
        return result;
      } catch (err: any) {
        setError(err.message || 'Erro ao agendar relatório');
        throw err;
      } finally {
        setLoading(false);
      }
    },
    []
  );

  return {
    reports,
    loading,
    error,
    pagination,
    fetchReports,
    generateReport,
    deleteReport,
    scheduleReport,
  };
}

