/**
 * Página de Dashboard
 * Primeflow-Hub - Patch 5
 */

import React, { useState, useEffect } from 'react';
import { useDashboard } from '../hooks/useDashboard';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import {
  MessageSquare,
  Users,
  Package,
  Bot,
  TrendingUp,
  TrendingDown,
  Activity,
  Clock,
} from 'lucide-react';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

export default function Dashboard() {
  const {
    metrics,
    conversationStats,
    timeline,
    channelDistribution,
    loading,
    fetchDashboardMetrics,
    fetchConversationsTimeline,
    fetchConversationsByChannel,
  } = useDashboard();

  const [period, setPeriod] = useState('30d');

  useEffect(() => {
    fetchDashboardMetrics(period);
    fetchConversationsTimeline(period);
    fetchConversationsByChannel(period);
  }, [period]);

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('pt-BR').format(num);
  };

  const formatPercent = (num: number) => {
    const sign = num >= 0 ? '+' : '';
    return `${sign}${num.toFixed(1)}%`;
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground">Visão geral do seu negócio</p>
        </div>
        <Select value={period} onValueChange={setPeriod}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Período" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7d">Últimos 7 dias</SelectItem>
            <SelectItem value="30d">Últimos 30 dias</SelectItem>
            <SelectItem value="90d">Últimos 90 dias</SelectItem>
            <SelectItem value="1y">Último ano</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="text-center py-12">Carregando métricas...</div>
      ) : (
        <>
          {/* Cards de Métricas */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Conversas */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Conversas</CardTitle>
                <MessageSquare className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {formatNumber(metrics?.totalConversations || 0)}
                </div>
                {metrics?.conversationsGrowth !== undefined && (
                  <p className="text-xs text-muted-foreground flex items-center mt-1">
                    {metrics.conversationsGrowth >= 0 ? (
                      <TrendingUp className="h-3 w-3 mr-1 text-green-500" />
                    ) : (
                      <TrendingDown className="h-3 w-3 mr-1 text-red-500" />
                    )}
                    <span
                      className={
                        metrics.conversationsGrowth >= 0 ? 'text-green-500' : 'text-red-500'
                      }
                    >
                      {formatPercent(metrics.conversationsGrowth)}
                    </span>
                    <span className="ml-1">vs período anterior</span>
                  </p>
                )}
              </CardContent>
            </Card>

            {/* Mensagens */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Mensagens</CardTitle>
                <Activity className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {formatNumber(metrics?.totalMessages || 0)}
                </div>
                {metrics?.messagesGrowth !== undefined && (
                  <p className="text-xs text-muted-foreground flex items-center mt-1">
                    {metrics.messagesGrowth >= 0 ? (
                      <TrendingUp className="h-3 w-3 mr-1 text-green-500" />
                    ) : (
                      <TrendingDown className="h-3 w-3 mr-1 text-red-500" />
                    )}
                    <span
                      className={
                        metrics.messagesGrowth >= 0 ? 'text-green-500' : 'text-red-500'
                      }
                    >
                      {formatPercent(metrics.messagesGrowth)}
                    </span>
                    <span className="ml-1">vs período anterior</span>
                  </p>
                )}
              </CardContent>
            </Card>

            {/* Contatos */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Contatos</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {formatNumber(metrics?.totalContacts || 0)}
                </div>
                <p className="text-xs text-muted-foreground mt-1">Total de contatos</p>
              </CardContent>
            </Card>

            {/* Produtos */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Produtos</CardTitle>
                <Package className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {formatNumber(metrics?.totalProducts || 0)}
                </div>
                <p className="text-xs text-muted-foreground mt-1">Produtos ativos</p>
              </CardContent>
            </Card>
          </div>

          {/* Gráficos */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Timeline de Conversas */}
            <Card>
              <CardHeader>
                <CardTitle>Conversas ao Longo do Tempo</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={timeline}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="count"
                      stroke="#8884d8"
                      name="Conversas"
                      strokeWidth={2}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Distribuição por Canal */}
            <Card>
              <CardHeader>
                <CardTitle>Conversas por Canal</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={channelDistribution}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={(entry) => `${entry.channel}: ${entry.count}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="count"
                    >
                      {channelDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Estatísticas de Conversas */}
          {conversationStats && (
            <Card>
              <CardHeader>
                <CardTitle>Estatísticas de Conversas</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Total</p>
                    <p className="text-2xl font-bold">{formatNumber(conversationStats.total)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Ativas</p>
                    <p className="text-2xl font-bold text-green-500">
                      {formatNumber(conversationStats.active)}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Fechadas</p>
                    <p className="text-2xl font-bold text-gray-500">
                      {formatNumber(conversationStats.closed)}
                    </p>
                  </div>
                </div>

                {conversationStats.byStatus && conversationStats.byStatus.length > 0 && (
                  <div className="mt-6">
                    <p className="text-sm font-medium mb-2">Por Status</p>
                    <ResponsiveContainer width="100%" height={200}>
                      <BarChart data={conversationStats.byStatus}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="status" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="count" fill="#8884d8" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}

