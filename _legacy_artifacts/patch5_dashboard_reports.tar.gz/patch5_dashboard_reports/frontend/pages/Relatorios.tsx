/**
 * Página de Relatórios
 * Primeflow-Hub - Patch 5
 */

import React, { useState, useEffect } from 'react';
import { useReports } from '../hooks/useReports';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { FileText, Download, Trash2, Calendar, Filter } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function Relatorios() {
  const {
    reports,
    loading,
    pagination,
    fetchReports,
    generateReport,
    deleteReport,
  } = useReports();

  const [isGenerateDialogOpen, setIsGenerateDialogOpen] = useState(false);
  const [reportType, setReportType] = useState<string>('conversations');
  const [reportFormat, setReportFormat] = useState<string>('json');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  const [channel, setChannel] = useState<string>('');
  const [generating, setGenerating] = useState(false);

  useEffect(() => {
    fetchReports();
  }, []);

  const handleGenerateReport = async () => {
    if (!startDate || !endDate) {
      toast.error('Selecione o período do relatório');
      return;
    }

    setGenerating(true);
    try {
      const result = await generateReport({
        type: reportType,
        format: reportFormat,
        startDate,
        endDate,
        channel: channel || undefined,
      });

      if (reportFormat === 'json') {
        toast.success('Relatório gerado com sucesso!');
        setIsGenerateDialogOpen(false);
        fetchReports();
      } else {
        // Download automático para PDF e Excel
        const blob = new Blob([result], {
          type:
            reportFormat === 'pdf'
              ? 'application/pdf'
              : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `relatorio-${reportType}-${Date.now()}.${reportFormat === 'pdf' ? 'pdf' : 'xlsx'}`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);

        toast.success('Relatório baixado com sucesso!');
        setIsGenerateDialogOpen(false);
      }
    } catch (error) {
      toast.error('Erro ao gerar relatório');
    } finally {
      setGenerating(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Tem certeza que deseja deletar este relatório?')) {
      try {
        await deleteReport(id);
        toast.success('Relatório deletado com sucesso!');
        fetchReports();
      } catch (error) {
        toast.error('Erro ao deletar relatório');
      }
    }
  };

  const getReportTypeName = (type: string) => {
    const types: { [key: string]: string } = {
      conversations: 'Conversas',
      products: 'Produtos',
      'ai-agents': 'Agentes de IA',
      performance: 'Performance',
    };
    return types[type] || type;
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Relatórios</h1>
          <p className="text-muted-foreground">Gere e gerencie relatórios detalhados</p>
        </div>
        <Button onClick={() => setIsGenerateDialogOpen(true)}>
          <FileText className="mr-2 h-4 w-4" />
          Gerar Relatório
        </Button>
      </div>

      {/* Lista de Relatórios */}
      {loading ? (
        <div className="text-center py-12">Carregando relatórios...</div>
      ) : reports.length === 0 ? (
        <Card className="p-12 text-center">
          <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <p className="text-muted-foreground mb-4">Nenhum relatório gerado ainda</p>
          <Button onClick={() => setIsGenerateDialogOpen(true)}>
            Gerar primeiro relatório
          </Button>
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {reports.map((report) => (
            <Card key={report.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <FileText className="h-5 w-5 text-primary" />
                      <h3 className="text-lg font-semibold">{report.title}</h3>
                      <Badge variant="outline">{getReportTypeName(report.type)}</Badge>
                    </div>

                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        <span>
                          {format(new Date(report.generatedAt), "dd 'de' MMMM 'de' yyyy", {
                            locale: ptBR,
                          })}
                        </span>
                      </div>
                    </div>

                    {report.data?.period && (
                      <p className="text-sm text-muted-foreground mt-2">
                        Período:{' '}
                        {format(new Date(report.data.period.startDate), 'dd/MM/yyyy')} -{' '}
                        {format(new Date(report.data.period.endDate), 'dd/MM/yyyy')}
                      </p>
                    )}

                    {report.data?.stats && (
                      <div className="mt-3 flex gap-4">
                        {Object.entries(report.data.stats)
                          .slice(0, 3)
                          .map(([key, value]) => (
                            <div key={key}>
                              <p className="text-xs text-muted-foreground">{key}</p>
                              <p className="text-sm font-medium">
                                {typeof value === 'number' ? value : JSON.stringify(value)}
                              </p>
                            </div>
                          ))}
                      </div>
                    )}
                  </div>

                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        // Implementar visualização do relatório
                        toast.info('Visualização em desenvolvimento');
                      }}
                    >
                      <FileText className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDelete(report.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Paginação */}
      {pagination && pagination.totalPages > 1 && (
        <div className="flex justify-center gap-2">
          {Array.from({ length: pagination.totalPages }, (_, i) => i + 1).map((page) => (
            <Button
              key={page}
              variant={page === pagination.page ? 'default' : 'outline'}
              onClick={() => fetchReports({ page })}
            >
              {page}
            </Button>
          ))}
        </div>
      )}

      {/* Dialog de Geração de Relatório */}
      <Dialog open={isGenerateDialogOpen} onOpenChange={setIsGenerateDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Gerar Novo Relatório</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            {/* Tipo de Relatório */}
            <div>
              <label className="text-sm font-medium">Tipo de Relatório</label>
              <Select value={reportType} onValueChange={setReportType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="conversations">Conversas</SelectItem>
                  <SelectItem value="products">Produtos</SelectItem>
                  <SelectItem value="ai-agents">Agentes de IA</SelectItem>
                  <SelectItem value="performance">Performance</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Formato */}
            <div>
              <label className="text-sm font-medium">Formato</label>
              <Select value={reportFormat} onValueChange={setReportFormat}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="json">JSON (Salvar)</SelectItem>
                  <SelectItem value="pdf">PDF (Download)</SelectItem>
                  <SelectItem value="excel">Excel (Download)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Data Início */}
            <div>
              <label className="text-sm font-medium">Data Início</label>
              <Input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
            </div>

            {/* Data Fim */}
            <div>
              <label className="text-sm font-medium">Data Fim</label>
              <Input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>

            {/* Canal (apenas para relatório de conversas) */}
            {reportType === 'conversations' && (
              <div>
                <label className="text-sm font-medium">Canal (Opcional)</label>
                <Select value={channel} onValueChange={setChannel}>
                  <SelectTrigger>
                    <SelectValue placeholder="Todos os canais" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Todos</SelectItem>
                    <SelectItem value="whatsapp">WhatsApp</SelectItem>
                    <SelectItem value="facebook">Facebook</SelectItem>
                    <SelectItem value="instagram">Instagram</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsGenerateDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleGenerateReport} disabled={generating}>
              {generating ? 'Gerando...' : 'Gerar'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

