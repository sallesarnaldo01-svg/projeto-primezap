/**
 * Analytics Service
 * Primeflow-Hub - Patch 5
 */

import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3333/api';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Interceptor para adicionar token de autenticação
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const analyticsService = {
  /**
   * Obter métricas do dashboard
   */
  async getDashboardMetrics(period: string = '30d') {
    const response = await api.get('/analytics/dashboard', { params: { period } });
    return response.data;
  },

  /**
   * Obter estatísticas de conversas
   */
  async getConversationStats(startDate?: string, endDate?: string, channel?: string) {
    const response = await api.get('/analytics/conversations', {
      params: { startDate, endDate, channel },
    });
    return response.data;
  },

  /**
   * Obter estatísticas de agentes de IA
   */
  async getAIAgentStats(startDate?: string, endDate?: string) {
    const response = await api.get('/analytics/ai-agents', {
      params: { startDate, endDate },
    });
    return response.data;
  },

  /**
   * Obter estatísticas de produtos
   */
  async getProductStats(startDate?: string, endDate?: string) {
    const response = await api.get('/analytics/products', {
      params: { startDate, endDate },
    });
    return response.data;
  },

  /**
   * Obter timeline de conversas
   */
  async getConversationsTimeline(
    startDate: string,
    endDate: string,
    granularity: 'hour' | 'day' | 'week' | 'month' = 'day'
  ) {
    const response = await api.get('/analytics/conversations/timeline', {
      params: { startDate, endDate, granularity },
    });
    return response.data;
  },

  /**
   * Obter distribuição de conversas por canal
   */
  async getConversationsByChannel(startDate?: string, endDate?: string) {
    const response = await api.get('/analytics/conversations/by-channel', {
      params: { startDate, endDate },
    });
    return response.data;
  },

  /**
   * Obter produtos mais mencionados
   */
  async getTopMentionedProducts(startDate?: string, endDate?: string, limit: number = 10) {
    const response = await api.get('/analytics/products/top-mentioned', {
      params: { startDate, endDate, limit },
    });
    return response.data;
  },

  /**
   * Obter taxa de conversão
   */
  async getConversionRate(startDate?: string, endDate?: string) {
    const response = await api.get('/analytics/conversion-rate', {
      params: { startDate, endDate },
    });
    return response.data;
  },

  /**
   * Obter tempo médio de resposta
   */
  async getAverageResponseTime(startDate?: string, endDate?: string) {
    const response = await api.get('/analytics/response-time', {
      params: { startDate, endDate },
    });
    return response.data;
  },

  /**
   * Obter satisfação do cliente
   */
  async getCustomerSatisfaction(startDate?: string, endDate?: string) {
    const response = await api.get('/analytics/customer-satisfaction', {
      params: { startDate, endDate },
    });
    return response.data;
  },

  /**
   * Exportar dados de analytics
   */
  async exportAnalytics(
    type: string,
    startDate: string,
    endDate: string,
    format: string = 'json'
  ) {
    const response = await api.post('/analytics/export', {
      type,
      startDate,
      endDate,
      format,
    });
    return response.data;
  },
};

