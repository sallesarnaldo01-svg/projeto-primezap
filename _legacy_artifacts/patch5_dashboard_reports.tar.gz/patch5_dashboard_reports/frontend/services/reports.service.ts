/**
 * Reports Service
 * Primeflow-Hub - Patch 5
 */

import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3333/api';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Interceptor para adicionar token de autenticação
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const reportsService = {
  /**
   * Gerar relatório
   */
  async generate(params: {
    type: string;
    format: string;
    startDate: string;
    endDate: string;
    channel?: string;
    category?: string;
    agentId?: string;
  }) {
    const endpoint = `/reports/${params.type}`;

    if (params.format === 'pdf' || params.format === 'excel') {
      // Para PDF e Excel, fazer download direto
      const response = await api.post(
        endpoint,
        {
          startDate: params.startDate,
          endDate: params.endDate,
          channel: params.channel,
          category: params.category,
          agentId: params.agentId,
          format: params.format,
        },
        {
          responseType: 'blob',
        }
      );
      return response.data;
    }

    // Para JSON, retornar dados
    const response = await api.post(endpoint, {
      startDate: params.startDate,
      endDate: params.endDate,
      channel: params.channel,
      category: params.category,
      agentId: params.agentId,
      format: params.format,
    });
    return response.data;
  },

  /**
   * Listar relatórios
   */
  async list(params?: { page?: number; limit?: number }) {
    const response = await api.get('/reports', { params });
    return response.data;
  },

  /**
   * Buscar relatório por ID
   */
  async getById(id: string) {
    const response = await api.get(`/reports/${id}`);
    return response.data;
  },

  /**
   * Deletar relatório
   */
  async delete(id: string) {
    await api.delete(`/reports/${id}`);
  },

  /**
   * Agendar relatório
   */
  async schedule(type: string, frequency: string, config: any) {
    const response = await api.post('/reports/schedule', {
      type,
      frequency,
      config,
    });
    return response.data;
  },

  /**
   * Listar relatórios agendados
   */
  async listScheduled() {
    const response = await api.get('/reports/scheduled');
    return response.data;
  },
};

