#!/bin/bash

# ============================================================
# Script de Instalação - Patch 5: Dashboard e Reports
# Primeflow-Hub
# ============================================================

# Cores para o output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Função para printar mensagens
info() {
    echo -e "${GREEN}[INFO] $1${NC}"
}

warn() {
    echo -e "${YELLOW}[AVISO] $1${NC}"
}

error() {
    echo -e "${RED}[ERRO] $1${NC}"
    exit 1
}

# Verifica se o script está sendo executado como root
if [ "$EUID" -ne 0 ]; then
  warn "Este script pode precisar de permissões de superusuário para copiar arquivos. Se ocorrerem erros, execute com sudo."
fi

# Verifica se o caminho do projeto foi fornecido
if [ -z "$1" ]; then
    error "O caminho para o diretório do projeto Primeflow-Hub é obrigatório. \nUso: sudo bash install.sh /caminho/para/o/projeto"
fi

# --- Variáveis ---
PROJECT_DIR=$1
PATCH_DIR=$(dirname "$(dirname "$0")") # Diretório do patch (um nível acima de scripts/)

# Caminhos de destino
BACKEND_DIR="$PROJECT_DIR/apps/api/src"
FRONTEND_DIR="$PROJECT_DIR/apps/front/src"
DB_DIR="$PROJECT_DIR/database/migrations" # Supondo que as migrations fiquem aqui

info "Iniciando a instalação do Patch 5: Dashboard e Reports..."
info "Diretório do Projeto: $PROJECT_DIR"
info "Diretório do Patch: $PATCH_DIR"

# --- Validação dos Diretórios ---
if [ ! -d "$PROJECT_DIR" ]; then
    error "O diretório do projeto especificado não existe: $PROJECT_DIR"
fi

if [ ! -d "$BACKEND_DIR" ]; then
    error "O diretório do backend não foi encontrado: $BACKEND_DIR"
fi

if [ ! -d "$FRONTEND_DIR" ]; then
    error "O diretório do frontend não foi encontrado: $FRONTEND_DIR"
fi

# --- Cópia dos Arquivos ---

info "Copiando arquivos do backend..."
cp -r "$PATCH_DIR/backend/controllers" "$BACKEND_DIR/"
cp -r "$PATCH_DIR/backend/services" "$BACKEND_DIR/"
if [ $? -ne 0 ]; then error "Falha ao copiar arquivos do backend."; fi

info "Copiando arquivos do frontend..."
cp -r "$PATCH_DIR/frontend/pages" "$FRONTEND_DIR/"
cp -r "$PATCH_DIR/frontend/hooks" "$FRONTEND_DIR/"
cp -r "$PATCH_DIR/frontend/services" "$FRONTEND_DIR/"
if [ $? -ne 0 ]; then error "Falha ao copiar arquivos do frontend."; fi

info "Copiando arquivo de migration do banco de dados..."
mkdir -p "$DB_DIR"
cp "$PATCH_DIR/database/001_reports_analytics.sql" "$DB_DIR/"
if [ $? -ne 0 ]; then error "Falha ao copiar arquivo de migration."; fi

info "Arquivos copiados com sucesso!"

# --- Instalação de Dependências ---

info "Navegando para o diretório do projeto para instalar dependências..."
cd "$PROJECT_DIR"
if [ $? -ne 0 ]; then error "Não foi possível acessar o diretório do projeto."; fi

info "Instalando dependências do backend (pdfkit, exceljs)..."
# O pnpm workspace gerencia isso a partir da raiz
pnpm add pdfkit exceljs --filter api
if [ $? -ne 0 ]; then warn "Falha ao instalar dependências do backend. Tente instalar manualmente."; fi

pnpm add -D @types/pdfkit --filter api
if [ $? -ne 0 ]; then warn "Falha ao instalar tipos do backend. Tente instalar manualmente."; fi

info "Instalando dependências do frontend (recharts, lucide-react, date-fns)..."
pnpm add recharts lucide-react date-fns --filter front
if [ $? -ne 0 ]; then warn "Falha ao instalar dependências do frontend. Tente instalar manualmente."; fi

info "Dependências instaladas com sucesso!"

# --- Finalização ---

info "============================================================"
info "✅ Instalação do Patch 5 concluída com sucesso!"
info "============================================================"

warn "AÇÕES MANUAIS NECESSÁRIAS:"
warn "1. Aplique a migration do banco de dados:"
warn "   PGPASSWORD=\"sua_senha\" psql -h localhost -U seu_usuario -d primeflow -f $DB_DIR/001_reports_analytics.sql"
warn "2. Adicione as novas rotas nos arquivos do backend e frontend (consulte o Guia de Configuração)."
warn "3. Adicione os links de navegação para as novas páginas no menu lateral."
warn "4. Reinicie a aplicação para que as alterações tenham efeito: pnpm dev"

echo -e "${GREEN}Patch 5 está pronto para ser configurado e utilizado!${NC}"

exit 0

