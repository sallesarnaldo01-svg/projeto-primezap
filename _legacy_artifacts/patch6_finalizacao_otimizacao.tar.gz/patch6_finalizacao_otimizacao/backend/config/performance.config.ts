/**
 * Performance Configuration
 * Primeflow-Hub - Patch 6
 * 
 * Configurações e middlewares de otimização de performance
 */

import compression from 'compression';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import slowDown from 'express-slow-down';
import { Express } from 'express';

/**
 * Configurar middlewares de performance
 */
export function setupPerformanceMiddlewares(app: Express) {
  // Compressão de respostas
  app.use(
    compression({
      filter: (req, res) => {
        if (req.headers['x-no-compression']) {
          return false;
        }
        return compression.filter(req, res);
      },
      level: 6, // Nível de compressão (0-9)
    })
  );

  // Segurança com Helmet
  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          styleSrc: ["'self'", "'unsafe-inline'"],
          scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
          imgSrc: ["'self'", 'data:', 'https:'],
        },
      },
      crossOriginEmbedderPolicy: false,
    })
  );

  // Rate Limiting - Limite de requisições
  const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutos
    max: 100, // Limite de 100 requisições por IP
    message: 'Muitas requisições deste IP, tente novamente mais tarde.',
    standardHeaders: true,
    legacyHeaders: false,
  });

  app.use('/api/', limiter);

  // Rate Limiting mais restritivo para autenticação
  const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 5, // Apenas 5 tentativas de login
    message: 'Muitas tentativas de login, tente novamente em 15 minutos.',
    skipSuccessfulRequests: true,
  });

  app.use('/api/auth/login', authLimiter);
  app.use('/api/auth/register', authLimiter);

  // Slow Down - Reduz velocidade após muitas requisições
  const speedLimiter = slowDown({
    windowMs: 15 * 60 * 1000,
    delayAfter: 50,
    delayMs: 500,
  });

  app.use('/api/', speedLimiter);

  console.log('✅ Middlewares de performance configurados');
}

/**
 * Configurações de otimização de queries
 */
export const queryOptimizations = {
  // Tamanho padrão de página para paginação
  defaultPageSize: 20,
  maxPageSize: 100,

  // Timeout para queries longas (em ms)
  queryTimeout: 30000,

  // Configurações de pool de conexões
  connectionPool: {
    min: 2,
    max: 10,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 2000,
  },
};

/**
 * Configurações de cache
 */
export const cacheConfig = {
  // TTL padrão (em segundos)
  defaultTTL: 300, // 5 minutos

  // TTL por tipo de recurso
  ttl: {
    conversations: 60, // 1 minuto
    messages: 30, // 30 segundos
    contacts: 300, // 5 minutos
    products: 600, // 10 minutos
    aiAgents: 600, // 10 minutos
    analytics: 300, // 5 minutos
    reports: 3600, // 1 hora
  },

  // Prefixos de chave
  keyPrefixes: {
    conversation: 'conv:',
    message: 'msg:',
    contact: 'contact:',
    product: 'product:',
    aiAgent: 'agent:',
    analytics: 'analytics:',
    report: 'report:',
  },
};

/**
 * Gerar chave de cache
 */
export function generateCacheKey(type: string, identifier: string, params?: any): string {
  const prefix = cacheConfig.keyPrefixes[type as keyof typeof cacheConfig.keyPrefixes] || type;
  const paramsStr = params ? `:${JSON.stringify(params)}` : '';
  return `${prefix}${identifier}${paramsStr}`;
}

/**
 * Configurações de otimização de assets
 */
export const assetsConfig = {
  // Tamanho máximo de upload (em bytes)
  maxUploadSize: 50 * 1024 * 1024, // 50MB

  // Tipos de arquivo permitidos
  allowedMimeTypes: [
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp',
    'video/mp4',
    'video/webm',
    'audio/mpeg',
    'audio/wav',
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  ],

  // Configurações de compressão de imagens
  imageCompression: {
    quality: 80,
    maxWidth: 1920,
    maxHeight: 1080,
  },

  // Configurações de thumbnails
  thumbnails: {
    small: { width: 150, height: 150 },
    medium: { width: 300, height: 300 },
    large: { width: 600, height: 600 },
  },
};

/**
 * Monitoramento de performance
 */
export class PerformanceMonitor {
  private metrics: Map<string, number[]> = new Map();

  /**
   * Registrar tempo de execução
   */
  record(operation: string, duration: number) {
    if (!this.metrics.has(operation)) {
      this.metrics.set(operation, []);
    }
    this.metrics.get(operation)!.push(duration);

    // Manter apenas os últimos 100 registros
    const records = this.metrics.get(operation)!;
    if (records.length > 100) {
      records.shift();
    }
  }

  /**
   * Obter estatísticas de uma operação
   */
  getStats(operation: string) {
    const records = this.metrics.get(operation) || [];
    if (records.length === 0) {
      return null;
    }

    const sorted = [...records].sort((a, b) => a - b);
    const sum = records.reduce((a, b) => a + b, 0);

    return {
      count: records.length,
      avg: sum / records.length,
      min: sorted[0],
      max: sorted[sorted.length - 1],
      p50: sorted[Math.floor(sorted.length * 0.5)],
      p95: sorted[Math.floor(sorted.length * 0.95)],
      p99: sorted[Math.floor(sorted.length * 0.99)],
    };
  }

  /**
   * Obter todas as estatísticas
   */
  getAllStats() {
    const stats: any = {};
    for (const [operation, _] of this.metrics) {
      stats[operation] = this.getStats(operation);
    }
    return stats;
  }

  /**
   * Limpar métricas
   */
  clear() {
    this.metrics.clear();
  }
}

export const performanceMonitor = new PerformanceMonitor();

/**
 * Middleware de monitoramento de performance
 */
export function performanceMiddleware() {
  return (req: any, res: any, next: any) => {
    const start = Date.now();

    res.on('finish', () => {
      const duration = Date.now() - start;
      const route = `${req.method} ${req.route?.path || req.path}`;
      performanceMonitor.record(route, duration);

      // Log de requisições lentas (> 1 segundo)
      if (duration > 1000) {
        console.warn(`⚠️ Requisição lenta: ${route} - ${duration}ms`);
      }
    });

    next();
  };
}

export default {
  setupPerformanceMiddlewares,
  queryOptimizations,
  cacheConfig,
  generateCacheKey,
  assetsConfig,
  performanceMonitor,
  performanceMiddleware,
};

