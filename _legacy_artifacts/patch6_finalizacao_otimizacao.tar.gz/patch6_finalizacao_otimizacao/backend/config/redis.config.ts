/**
 * Redis Configuration
 * Primeflow-Hub - Patch 6
 * 
 * Configuração de cache Redis para otimização de performance
 */

import Redis from 'ioredis';

// Configuração do Redis
const redisConfig = {
  host: process.env.REDIS_HOST || 'localhost',
  port: parseInt(process.env.REDIS_PORT || '6379'),
  password: process.env.REDIS_PASSWORD || undefined,
  db: parseInt(process.env.REDIS_DB || '0'),
  retryStrategy: (times: number) => {
    const delay = Math.min(times * 50, 2000);
    return delay;
  },
  maxRetriesPerRequest: 3,
};

// Cliente Redis
export const redis = new Redis(redisConfig);

// Event handlers
redis.on('connect', () => {
  console.log('✅ Redis conectado com sucesso');
});

redis.on('error', (err) => {
  console.error('❌ Erro no Redis:', err);
});

redis.on('reconnecting', () => {
  console.log('🔄 Reconectando ao Redis...');
});

/**
 * Cache Helper Functions
 */

export const cache = {
  /**
   * Obter valor do cache
   */
  async get<T>(key: string): Promise<T | null> {
    try {
      const value = await redis.get(key);
      return value ? JSON.parse(value) : null;
    } catch (error) {
      console.error(`Erro ao buscar cache [${key}]:`, error);
      return null;
    }
  },

  /**
   * Definir valor no cache
   */
  async set(key: string, value: any, ttl: number = 3600): Promise<boolean> {
    try {
      const serialized = JSON.stringify(value);
      await redis.setex(key, ttl, serialized);
      return true;
    } catch (error) {
      console.error(`Erro ao definir cache [${key}]:`, error);
      return false;
    }
  },

  /**
   * Deletar valor do cache
   */
  async del(key: string): Promise<boolean> {
    try {
      await redis.del(key);
      return true;
    } catch (error) {
      console.error(`Erro ao deletar cache [${key}]:`, error);
      return false;
    }
  },

  /**
   * Deletar múltiplas chaves por padrão
   */
  async delPattern(pattern: string): Promise<number> {
    try {
      const keys = await redis.keys(pattern);
      if (keys.length === 0) return 0;
      
      const deleted = await redis.del(...keys);
      return deleted;
    } catch (error) {
      console.error(`Erro ao deletar padrão [${pattern}]:`, error);
      return 0;
    }
  },

  /**
   * Verificar se chave existe
   */
  async exists(key: string): Promise<boolean> {
    try {
      const exists = await redis.exists(key);
      return exists === 1;
    } catch (error) {
      console.error(`Erro ao verificar existência [${key}]:`, error);
      return false;
    }
  },

  /**
   * Definir TTL de uma chave
   */
  async expire(key: string, ttl: number): Promise<boolean> {
    try {
      await redis.expire(key, ttl);
      return true;
    } catch (error) {
      console.error(`Erro ao definir TTL [${key}]:`, error);
      return false;
    }
  },

  /**
   * Incrementar valor numérico
   */
  async incr(key: string): Promise<number> {
    try {
      return await redis.incr(key);
    } catch (error) {
      console.error(`Erro ao incrementar [${key}]:`, error);
      return 0;
    }
  },

  /**
   * Decrementar valor numérico
   */
  async decr(key: string): Promise<number> {
    try {
      return await redis.decr(key);
    } catch (error) {
      console.error(`Erro ao decrementar [${key}]:`, error);
      return 0;
    }
  },

  /**
   * Limpar todo o cache
   */
  async flush(): Promise<boolean> {
    try {
      await redis.flushdb();
      return true;
    } catch (error) {
      console.error('Erro ao limpar cache:', error);
      return false;
    }
  },
};

/**
 * Middleware de cache para Express
 */
export function cacheMiddleware(ttl: number = 300) {
  return async (req: any, res: any, next: any) => {
    // Apenas cache GET requests
    if (req.method !== 'GET') {
      return next();
    }

    const key = `cache:${req.originalUrl}`;

    try {
      const cachedResponse = await cache.get(key);
      
      if (cachedResponse) {
        console.log(`✅ Cache HIT: ${key}`);
        return res.json(cachedResponse);
      }

      console.log(`❌ Cache MISS: ${key}`);

      // Interceptar res.json para cachear a resposta
      const originalJson = res.json.bind(res);
      res.json = (data: any) => {
        cache.set(key, data, ttl);
        return originalJson(data);
      };

      next();
    } catch (error) {
      console.error('Erro no middleware de cache:', error);
      next();
    }
  };
}

/**
 * Invalidar cache por padrão
 */
export async function invalidateCache(pattern: string) {
  const deleted = await cache.delPattern(`cache:*${pattern}*`);
  console.log(`🗑️ Cache invalidado: ${deleted} chaves deletadas`);
  return deleted;
}

export default redis;

