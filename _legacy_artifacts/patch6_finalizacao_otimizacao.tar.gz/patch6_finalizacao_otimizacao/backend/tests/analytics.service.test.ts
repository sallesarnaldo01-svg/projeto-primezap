/**
 * Analytics Service Tests
 * Primeflow-Hub - Patch 6
 */

import { analyticsService } from '../src/services/analytics.service';
import { prisma } from '../src/lib/prisma';

describe('Analytics Service', () => {
  const mockTenantId = 'tenant-123';

  describe('getDashboardMetrics', () => {
    it('deve retornar métricas do dashboard corretamente', async () => {
      // Mock dos dados
      (prisma.conversation.count as jest.Mock).mockResolvedValue(100);
      (prisma.message.count as jest.Mock).mockResolvedValue(500);
      (prisma.contact.count as jest.Mock).mockResolvedValue(50);
      (prisma.product.count as jest.Mock).mockResolvedValue(20);
      (prisma.aIAgent.count as jest.Mock).mockResolvedValue(3);

      const result = await analyticsService.getDashboardMetrics(mockTenantId, '30d');

      expect(result).toHaveProperty('totalConversations', 100);
      expect(result).toHaveProperty('totalMessages', 500);
      expect(result).toHaveProperty('totalContacts', 50);
      expect(result).toHaveProperty('totalProducts', 20);
      expect(result).toHaveProperty('activeAIAgents', 3);
      expect(result).toHaveProperty('conversationsGrowth');
      expect(result).toHaveProperty('messagesGrowth');
    });

    it('deve calcular crescimento corretamente', async () => {
      // Mock de dados para período atual
      (prisma.conversation.count as jest.Mock)
        .mockResolvedValueOnce(100) // Período atual
        .mockResolvedValueOnce(80); // Período anterior

      const result = await analyticsService.getDashboardMetrics(mockTenantId, '30d');

      // Crescimento esperado: ((100 - 80) / 80) * 100 = 25%
      expect(result.conversationsGrowth).toBeCloseTo(25, 1);
    });
  });

  describe('getConversationStats', () => {
    it('deve retornar estatísticas de conversas', async () => {
      const mockConversations = [
        { status: 'active' },
        { status: 'active' },
        { status: 'closed' },
      ];

      (prisma.conversation.count as jest.Mock)
        .mockResolvedValueOnce(3) // total
        .mockResolvedValueOnce(2) // active
        .mockResolvedValueOnce(1); // closed

      (prisma.conversation.groupBy as jest.Mock).mockResolvedValue([
        { status: 'active', _count: 2 },
        { status: 'closed', _count: 1 },
      ]);

      const result = await analyticsService.getConversationStats(
        mockTenantId,
        '2025-01-01',
        '2025-01-31'
      );

      expect(result).toHaveProperty('total', 3);
      expect(result).toHaveProperty('active', 2);
      expect(result).toHaveProperty('closed', 1);
      expect(result.byStatus).toHaveLength(2);
    });

    it('deve filtrar por canal quando fornecido', async () => {
      (prisma.conversation.count as jest.Mock).mockResolvedValue(10);

      await analyticsService.getConversationStats(
        mockTenantId,
        '2025-01-01',
        '2025-01-31',
        'whatsapp'
      );

      expect(prisma.conversation.count).toHaveBeenCalledWith(
        expect.objectContaining({
          where: expect.objectContaining({
            channel: 'whatsapp',
          }),
        })
      );
    });
  });

  describe('getProductStats', () => {
    it('deve retornar estatísticas de produtos', async () => {
      (prisma.product.count as jest.Mock)
        .mockResolvedValueOnce(50) // total
        .mockResolvedValueOnce(45) // active
        .mockResolvedValueOnce(5); // low stock

      (prisma.product.aggregate as jest.Mock).mockResolvedValue({
        _sum: { price: 10000 },
      });

      const result = await analyticsService.getProductStats(mockTenantId);

      expect(result).toHaveProperty('totalProducts', 50);
      expect(result).toHaveProperty('activeProducts', 45);
      expect(result).toHaveProperty('totalValue', 10000);
      expect(result).toHaveProperty('lowStock', 5);
    });
  });

  describe('getConversationsTimeline', () => {
    it('deve agrupar conversas por dia', async () => {
      const mockConversations = [
        { createdAt: new Date('2025-01-01T10:00:00Z') },
        { createdAt: new Date('2025-01-01T15:00:00Z') },
        { createdAt: new Date('2025-01-02T12:00:00Z') },
      ];

      (prisma.conversation.findMany as jest.Mock).mockResolvedValue(mockConversations);

      const result = await analyticsService.getConversationsTimeline(
        mockTenantId,
        '2025-01-01',
        '2025-01-03',
        'day'
      );

      expect(result).toHaveLength(2);
      expect(result[0]).toHaveProperty('date');
      expect(result[0]).toHaveProperty('count');
    });
  });

  describe('getConversionRate', () => {
    it('deve calcular taxa de conversão corretamente', async () => {
      (prisma.conversation.count as jest.Mock)
        .mockResolvedValueOnce(100) // total
        .mockResolvedValueOnce(25); // converted

      const result = await analyticsService.getConversionRate(mockTenantId);

      expect(result).toHaveProperty('total', 100);
      expect(result).toHaveProperty('converted', 25);
      expect(result).toHaveProperty('rate', 25);
    });

    it('deve retornar 0 quando não houver conversas', async () => {
      (prisma.conversation.count as jest.Mock).mockResolvedValue(0);

      const result = await analyticsService.getConversionRate(mockTenantId);

      expect(result.rate).toBe(0);
    });
  });

  describe('Funções auxiliares', () => {
    describe('getPeriodDates', () => {
      it('deve calcular datas para período de 7 dias', () => {
        const { startDate, endDate } = analyticsService.getPeriodDates('7d');
        const diff = endDate.getTime() - startDate.getTime();
        const days = diff / (1000 * 60 * 60 * 24);

        expect(days).toBeCloseTo(7, 0);
      });

      it('deve calcular datas para período de 30 dias', () => {
        const { startDate, endDate } = analyticsService.getPeriodDates('30d');
        const diff = endDate.getTime() - startDate.getTime();
        const days = diff / (1000 * 60 * 60 * 24);

        expect(days).toBeCloseTo(30, 0);
      });
    });

    describe('groupByTime', () => {
      it('deve agrupar por dia corretamente', () => {
        const data = [
          { createdAt: new Date('2025-01-01T10:00:00Z') },
          { createdAt: new Date('2025-01-01T15:00:00Z') },
          { createdAt: new Date('2025-01-02T12:00:00Z') },
        ];

        const result = analyticsService.groupByTime(data, 'day');

        expect(result).toHaveLength(2);
        expect(result[0].count).toBe(2);
        expect(result[1].count).toBe(1);
      });
    });
  });
});

