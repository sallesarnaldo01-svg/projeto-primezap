-- ============================================================
-- Criação de Usuário Supremo
-- Primeflow-Hub - Patch 6
-- ============================================================

-- Este script cria um usuário administrador supremo
-- Login: admin@primezapia.com
-- Senha: 123456

-- Nota: A senha deve ser hasheada usando bcrypt antes de inserir
-- Este é apenas um exemplo. Em produção, use um hash real.

-- Verificar se o tenant padrão existe, caso contrário criar
INSERT INTO tenants (id, name, slug, is_active, created_at, updated_at)
VALUES (
  'default-tenant-id',
  'Primezap',
  'primezap',
  true,
  NOW(),
  NOW()
)
ON CONFLICT (id) DO NOTHING;

-- Criar usuário administrador supremo
-- Senha "123456" hasheada com bcrypt (cost 10):
-- $2b$10$rBV2kHYgLcIyZLFYQqHqXOYvzqKZ5mJ5YqXqHqXqHqXqHqXqHqXqH
-- IMPORTANTE: Substitua este hash por um hash real gerado com bcrypt

INSERT INTO users (
  id,
  tenant_id,
  email,
  password,
  name,
  role,
  is_active,
  created_at,
  updated_at
)
VALUES (
  gen_random_uuid(),
  'default-tenant-id',
  'admin@primezapia.com',
  '$2b$10$rBV2kHYgLcIyZLFYQqHqXOYvzqKZ5mJ5YqXqHqXqHqXqHqXqHqXqH', -- Hash da senha "123456"
  'Administrador Supremo',
  'admin',
  true,
  NOW(),
  NOW()
)
ON CONFLICT (email) DO UPDATE SET
  password = EXCLUDED.password,
  role = 'admin',
  is_active = true,
  updated_at = NOW();

-- Comentário
COMMENT ON TABLE users IS 'Usuários do sistema com autenticação';

-- Log de sucesso
DO $$
BEGIN
  RAISE NOTICE '✅ Usuário supremo criado com sucesso!';
  RAISE NOTICE '   Email: admin@primezapia.com';
  RAISE NOTICE '   Senha: 123456';
  RAISE NOTICE '   IMPORTANTE: Altere a senha após o primeiro login!';
END $$;

-- ============================================================
-- Fim do Script
-- ============================================================

