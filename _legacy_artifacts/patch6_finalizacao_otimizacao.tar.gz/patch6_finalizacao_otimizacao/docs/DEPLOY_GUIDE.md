# 🚀 Guia de Deploy - Primeflow-Hub

**Projeto**: Primeflow-Hub  
**Versão**: 1.0.0 (Final)  
**Data**: 12/10/2025

---

## 1. Visão Geral

Este guia fornece um passo a passo completo para fazer o deploy do Primeflow-Hub em um servidor de produção. O processo utiliza **Docker** para containerização, **Nginx** como proxy reverso e **Certbot** para certificados SSL.

---

## 2. Pré-requisitos do Servidor

- **Sistema Operacional**: Ubuntu 22.04 LTS (recomendado)
- **CPU**: 2 vCPUs ou mais
- **RAM**: 4 GB ou mais
- **Armazenamento**: 50 GB de SSD ou mais
- **Acesso**: Acesso root ou um usuário com privilégios `sudo`.
- **Domínios**: Dois domínios (ou subdomínios) configurados para apontar para o IP do seu servidor. Ex:
  - `primezap.primezapia.com` (para o frontend)
  - `api.primezapia.com` (para o backend)

---

## 3. Instalação de Dependências do Servidor

Conecte-se ao seu servidor via SSH e execute os seguintes comandos:

### 3.1. Atualizar o Sistema

```bash
sudo apt update && sudo apt upgrade -y
```

### 3.2. Instalar Docker e Docker Compose

```bash
sudo apt install -y docker.io docker-compose
sudo systemctl start docker
sudo systemctl enable docker
sudo usermod -aG docker $USER
# Faça logout e login novamente para aplicar as permissões do Docker
```

### 3.3. Instalar Nginx

```bash
sudo apt install -y nginx
sudo systemctl start nginx
sudo systemctl enable nginx
```

### 3.4. Instalar Certbot (para SSL)

```bash
sudo apt install -y certbot python3-certbot-nginx
```

---

## 4. Configuração do Ambiente

### 4.1. Clonar o Repositório

Clone o projeto para o diretório de sua preferência (ex: `/home/administrator/unified`).

```bash
cd /home/administrator/unified
git clone https://github.com/seu-usuario/primeflow-hub.git primeflow-hub-main
cd primeflow-hub-main
```

### 4.2. Configurar Variáveis de Ambiente

Copie o arquivo de exemplo `.env.example` para `.env` e preencha com seus valores.

```bash
cp .env.example .env
nano .env
```

**Preencha todas as variáveis, especialmente:**
- `DB_PASSWORD`
- `REDIS_PASSWORD`
- `JWT_SECRET` (gere uma chave forte com `openssl rand -base64 32`)
- `GEMINI_API_KEY`
- `EVOLUTION_API_URL` e `EVOLUTION_API_KEY`
- `FACEBOOK_APP_ID`, `FACEBOOK_APP_SECRET`, `FACEBOOK_VERIFY_TOKEN`
- `SMTP_USER` e `SMTP_PASSWORD`

### 4.3. Configurar Nginx

Copie o arquivo de configuração do Nginx do projeto para o diretório do Nginx.

```bash
sudo cp config/nginx/primeflow-hub.conf /etc/nginx/sites-available/primeflow-hub.conf
sudo ln -s /etc/nginx/sites-available/primeflow-hub.conf /etc/nginx/sites-enabled/

# Teste a configuração do Nginx
sudo nginx -t

# Reinicie o Nginx
sudo systemctl restart nginx
```

### 4.4. Gerar Certificados SSL

Use o Certbot para gerar os certificados SSL para seus domínios.

```bash
sudo certbot --nginx -d primezap.primezapia.com -d api.primezapia.com
```

Siga as instruções na tela. O Certbot irá configurar automaticamente o Nginx para usar os certificados SSL.

---

## 5. Build e Deploy com Docker Compose

Com o ambiente configurado, você pode agora construir as imagens Docker e iniciar os containers.

### 5.1. Construir e Iniciar os Containers

No diretório raiz do projeto, execute:

```bash
docker-compose -f config/docker/docker-compose.prod.yml up --build -d
```

- `--build`: Força a reconstrução das imagens.
- `-d`: Executa os containers em modo detached (background).

### 5.2. Executar a Migration do Banco de Dados

Após os containers estarem rodando, execute a migration inicial e crie o usuário administrador.

```bash
# Aguarde o PostgreSQL iniciar completamente
sleep 15

# Execute a migration
docker-compose -f config/docker/docker-compose.prod.yml exec postgres psql -U ${DB_USER} -d ${DB_NAME} -f /path/to/your/migration.sql

# Crie o usuário administrador
docker-compose -f config/docker/docker-compose.prod.yml exec postgres psql -U ${DB_USER} -d ${DB_NAME} -f /path/to/create_admin_user.sql
```

---

## 6. Verificação Pós-Deploy

- **Verificar Containers**: `docker ps` - Todos os containers (postgres, redis, backend, frontend, nginx) devem estar com o status `Up`.
- **Verificar Logs**: `docker-compose -f config/docker/docker-compose.prod.yml logs -f` - Verifique se há erros nos logs.
- **Acessar a Aplicação**:
  - Frontend: `https://primezap.primezapia.com`
  - Backend Health Check: `https://api.primezapia.com/health` (deve retornar `OK`)
- **Login**: Faça login com o usuário `admin@primezapia.com` e senha `123456`.

---

## 7. Checklist Pós-Deploy

| Status | Tarefa | Verificação |
| :----: | ------ | ----------- |
| `[ ]` | **Acesso ao Frontend** | Acessar `https://primezap.primezapia.com` carrega a página de login. |
| `[ ]` | **Acesso ao Backend** | Acessar `https://api.primezapia.com/health` retorna `OK`. |
| `[ ]` | **Certificado SSL** | O cadeado no navegador deve indicar uma conexão segura. |
| `[ ]` | **Login do Admin** | Login com `admin@primezapia.com` e `123456` funciona. |
| `[ ]` | **Funcionalidades Principais** | Testar o envio de uma mensagem, criação de um produto e visualização do dashboard. |
| `[ ]` | **Upload de Arquivos** | Fazer upload de uma imagem em um produto. |
| `[ ]` | **Webhooks** | Configurar e testar um webhook de uma das integrações. |

---

**Deploy concluído!** Sua instância do Primeflow-Hub está pronta para uso.

