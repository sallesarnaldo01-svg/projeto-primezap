# 🛠️ Guia de Manutenção - Primeflow-Hub

**Projeto**: Primeflow-Hub  
**Versão**: 1.0.0 (Final)  
**Data**: 12/10/2025

---

## 1. Visão Geral

Este guia descreve os procedimentos essenciais para a manutenção, monitoramento e atualização de uma instância em produção do Primeflow-Hub.

---

## 2. Monitoramento

### 2.1. Verificando o Status dos Serviços

Use o Docker para verificar o status dos containers:

```bash
docker ps
```

Todos os serviços (postgres, redis, backend, frontend, nginx) devem estar com o status `Up`.

### 2.2. Verificando Logs em Tempo Real

Para visualizar os logs de todos os serviços:

```bash
docker-compose -f config/docker/docker-compose.prod.yml logs -f
```

Para visualizar os logs de um serviço específico (ex: backend):

```bash
docker-compose -f config/docker/docker-compose.prod.yml logs -f backend
```

### 2.3. Health Checks

- **Backend**: `https://api.primezapia.com/health` (deve retornar `OK`)
- **Frontend**: Acessar `https://primezap.primezapia.com` deve carregar a página.

### 2.4. Monitoramento Avançado (Prometheus & Grafana)

Para um monitoramento mais robusto, considere integrar o Prometheus e o Grafana. O backend expõe um endpoint de métricas em `/metrics` que pode ser consumido pelo Prometheus.

---

## 3. Backups

### 3.1. Backup do Banco de Dados

É crucial fazer backups regulares do banco de dados PostgreSQL.

```bash
docker-compose -f config/docker/docker-compose.prod.yml exec postgres pg_dump -U ${DB_USER} -d ${DB_NAME} | gzip > /home/administrator/backups/db_backup_$(date +%Y%m%d_%H%M%S).sql.gz
```

### 3.2. Backup dos Arquivos de Upload

Os arquivos de upload estão no volume `uploads`. Faça o backup deste volume.

```bash
sudo tar -czf /home/administrator/backups/uploads_backup_$(date +%Y%m%d_%H%M%S).tar.gz /var/lib/docker/volumes/primeflow-hub-main_uploads/_data
```

### 3.3. Automatizando Backups

Use o `cron` para automatizar os backups. Edite o crontab:

```bash
crontab -e
```

Adicione as seguintes linhas para fazer backups diários:

```cron
# Backup diário do banco de dados às 2h da manhã
0 2 * * * docker-compose -f /home/administrator/unified/primeflow-hub-main/config/docker/docker-compose.prod.yml exec postgres pg_dump -U primeflow -d primeflow | gzip > /home/administrator/backups/db_backup_$(date +\%Y\%m\%d).sql.gz

# Backup diário dos uploads às 2h30 da manhã
30 2 * * * sudo tar -czf /home/administrator/backups/uploads_backup_$(date +\%Y\%m\%d).tar.gz /var/lib/docker/volumes/primeflow-hub-main_uploads/_data
```

---

## 4. Atualizações

### 4.1. Atualizando a Aplicação

Para atualizar a aplicação com a versão mais recente do repositório:

```bash
cd /home/administrator/unified/primeflow-hub-main

# 1. Obter o código mais recente
git pull origin main

# 2. Reconstruir e reiniciar os containers
docker-compose -f config/docker/docker-compose.prod.yml up --build -d

# 3. Executar novas migrations (se houver)
docker-compose -f config/docker/docker-compose.prod.yml exec postgres psql -U ${DB_USER} -d ${DB_NAME} -f /path/to/new/migration.sql

# 4. Limpar imagens antigas do Docker
docker image prune -f
```

### 4.2. Renovando Certificados SSL

O Certbot geralmente renova os certificados automaticamente. Para forçar uma renovação:

```bash
sudo certbot renew --dry-run  # Testar a renovação
sudo certbot renew            # Renovar de fato
```

---

## 5. Troubleshooting

### Problema: A aplicação está lenta.
- **Causa**: Pode ser sobrecarga no servidor ou queries ineficientes.
- **Solução**: 
  1. Verifique o uso de CPU e RAM com `htop`.
  2. Verifique os logs do backend por queries lentas.
  3. Considere aumentar os recursos do servidor.
  4. Verifique o cache Redis: `docker-compose exec redis redis-cli monitor`.

### Problema: Erro 502 Bad Gateway.
- **Causa**: O container do backend pode estar fora do ar ou reiniciando.
- **Solução**:
  1. Verifique o status do container: `docker ps`.
  2. Verifique os logs do backend: `docker-compose logs -f backend`.
  3. Reinicie o container: `docker-compose restart backend`.

### Problema: Não consigo fazer upload de arquivos.
- **Causa**: Permissões incorretas no volume de uploads ou limite de tamanho do Nginx.
- **Solução**:
  1. Verifique as permissões do diretório `/var/lib/docker/volumes/primeflow-hub-main_uploads/_data`.
  2. Verifique a configuração `client_max_body_size` no arquivo do Nginx.

---

Este guia cobre os aspectos básicos da manutenção. Para problemas mais complexos, consulte a documentação oficial das tecnologias utilizadas (Docker, Nginx, PostgreSQL, etc.).

