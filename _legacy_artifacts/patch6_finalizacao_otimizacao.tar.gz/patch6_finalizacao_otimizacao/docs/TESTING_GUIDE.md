# 🧪 Guia de Testes - Primeflow-Hub

**Projeto**: Primeflow-Hub  
**Versão**: 1.0.0 (Final)  
**Data**: 12/10/2025

---

## 1. Visão Geral

Este guia explica como executar os testes automatizados do Primeflow-Hub para garantir a qualidade e a estabilidade do código. O projeto utiliza **Jest** para testes unitários no backend e **Playwright** para testes end-to-end (E2E) no frontend.

---

## 2. Configuração do Ambiente de Testes

Antes de executar os testes, certifique-se de que todas as dependências de desenvolvimento estão instaladas.

```bash
# No diretório raiz do projeto
pnpm install
```

---

## 3. Testes Unitários (Backend com Jest)

Os testes unitários validam a lógica de negócio dos services e controllers do backend de forma isolada.

### 3.1. Executando Todos os Testes Unitários

Para executar todos os testes unitários do backend:

```bash
pnpm test:backend
```

Este comando irá:
- Executar todos os arquivos `*.test.ts` e `*.spec.ts` no diretório `apps/api`.
- Gerar um relatório de cobertura de testes no diretório `apps/api/coverage`.

### 3.2. Executando Testes em Modo Watch

Para executar os testes em modo watch, que re-executa os testes automaticamente ao salvar uma alteração:

```bash
pnpm test:backend:watch
```

### 3.3. Verificando a Cobertura de Testes

Após executar os testes, você pode abrir o relatório de cobertura em HTML para uma análise detalhada:

```bash
open apps/api/coverage/lcov-report/index.html
```

A meta é manter a cobertura acima de **70%** para branches, funções, linhas e statements.

---

## 4. Testes End-to-End (Frontend com Playwright)

Os testes E2E simulam a interação de um usuário real com a aplicação no navegador, validando fluxos completos.

### 4.1. Instalando os Navegadores do Playwright

Antes da primeira execução, instale os navegadores necessários:

```bash
pnpm exec playwright install --with-deps
```

### 4.2. Executando os Testes E2E

Para executar todos os testes E2E:

```bash
pnpm test:e2e
```

Este comando irá:
- Iniciar o servidor de desenvolvimento.
- Executar os testes nos navegadores configurados (Chromium, Firefox, WebKit).
- Gerar um relatório em HTML.

### 4.3. Executando Testes em Modo UI

O Playwright oferece uma UI interativa para depurar testes:

```bash
pnpm test:e2e:ui
```

### 4.4. Visualizando o Relatório de Testes

Após a execução, visualize o relatório HTML:

```bash
pnpm test:e2e:report
```

O relatório mostra o resultado de cada teste, com screenshots, vídeos e traces para facilitar a depuração de falhas.

---

## 5. Executando Todos os Testes (CI)

Para executar todos os testes (lint, type-check, unitários e E2E), use o comando principal de teste:

```bash
pnpm test
```

Este é o comando utilizado no pipeline de Integração Contínua (CI) para garantir que todas as alterações passem pelas verificações de qualidade antes de serem integradas.

---

Manter uma suíte de testes robusta é essencial para a saúde do projeto a longo prazo. Contribua escrevendo testes para novas funcionalidades e corrigindo testes quebrados.

