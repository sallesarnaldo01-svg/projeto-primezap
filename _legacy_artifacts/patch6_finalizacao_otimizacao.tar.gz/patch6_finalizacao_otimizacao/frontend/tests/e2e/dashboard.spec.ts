/**
 * Dashboard E2E Tests
 * Primeflow-Hub - Patch 6
 */

import { test, expect } from '@playwright/test';

test.describe('Dashboard', () => {
  test.beforeEach(async ({ page }) => {
    // Login antes de cada teste
    await page.goto('/login');
    await page.fill('input[name="email"]', 'admin@primezapia.com');
    await page.fill('input[name="password"]', '123456');
    await page.click('button[type="submit"]');
    
    // Aguardar redirecionamento
    await page.waitForURL('/dashboard');
  });

  test('deve carregar o dashboard corretamente', async ({ page }) => {
    await page.goto('/dashboard');

    // Verificar título da página
    await expect(page.locator('h1')).toContainText('Dashboard');

    // Verificar se os cards de métricas estão visíveis
    await expect(page.locator('text=Conversas')).toBeVisible();
    await expect(page.locator('text=Mensagens')).toBeVisible();
    await expect(page.locator('text=Contatos')).toBeVisible();
    await expect(page.locator('text=Produtos')).toBeVisible();
  });

  test('deve exibir números nas métricas', async ({ page }) => {
    await page.goto('/dashboard');

    // Aguardar carregamento dos dados
    await page.waitForTimeout(2000);

    // Verificar se há números nos cards (não apenas "0")
    const conversasCard = page.locator('text=Conversas').locator('..');
    const numero = await conversasCard.locator('.text-2xl').textContent();
    
    expect(numero).toBeTruthy();
    expect(numero).not.toBe('0');
  });

  test('deve permitir filtrar por período', async ({ page }) => {
    await page.goto('/dashboard');

    // Clicar no seletor de período
    await page.click('[role="combobox"]');

    // Selecionar "Últimos 7 dias"
    await page.click('text=Últimos 7 dias');

    // Aguardar atualização dos dados
    await page.waitForTimeout(1000);

    // Verificar se o filtro foi aplicado
    await expect(page.locator('[role="combobox"]')).toContainText('Últimos 7 dias');
  });

  test('deve exibir gráfico de timeline', async ({ page }) => {
    await page.goto('/dashboard');

    // Aguardar carregamento do gráfico
    await page.waitForSelector('.recharts-wrapper', { timeout: 5000 });

    // Verificar se o gráfico está visível
    const grafico = page.locator('.recharts-wrapper').first();
    await expect(grafico).toBeVisible();
  });

  test('deve exibir gráfico de distribuição por canal', async ({ page }) => {
    await page.goto('/dashboard');

    // Aguardar carregamento do gráfico de pizza
    await page.waitForSelector('.recharts-pie', { timeout: 5000 });

    // Verificar se o gráfico de pizza está visível
    const graficoPizza = page.locator('.recharts-pie');
    await expect(graficoPizza).toBeVisible();
  });

  test('deve exibir estatísticas de conversas', async ({ page }) => {
    await page.goto('/dashboard');

    // Aguardar carregamento
    await page.waitForTimeout(2000);

    // Verificar se a seção de estatísticas está visível
    await expect(page.locator('text=Estatísticas de Conversas')).toBeVisible();
    await expect(page.locator('text=Total')).toBeVisible();
    await expect(page.locator('text=Ativas')).toBeVisible();
    await expect(page.locator('text=Fechadas')).toBeVisible();
  });

  test('deve ser responsivo em mobile', async ({ page }) => {
    // Configurar viewport mobile
    await page.setViewportSize({ width: 375, height: 667 });
    await page.goto('/dashboard');

    // Verificar se o layout se adapta
    const cards = page.locator('[class*="grid"]').first();
    await expect(cards).toBeVisible();

    // Verificar se os gráficos ainda são visíveis
    await page.waitForSelector('.recharts-wrapper', { timeout: 5000 });
    const grafico = page.locator('.recharts-wrapper').first();
    await expect(grafico).toBeVisible();
  });

  test('deve exibir indicadores de crescimento', async ({ page }) => {
    await page.goto('/dashboard');
    await page.waitForTimeout(2000);

    // Verificar se há ícones de tendência (TrendingUp ou TrendingDown)
    const trendingIcons = page.locator('svg[class*="lucide-trending"]');
    const count = await trendingIcons.count();
    
    expect(count).toBeGreaterThan(0);
  });

  test('deve atualizar dados ao mudar o período', async ({ page }) => {
    await page.goto('/dashboard');
    await page.waitForTimeout(2000);

    // Capturar valor inicial
    const conversasCard = page.locator('text=Conversas').locator('..');
    const valorInicial = await conversasCard.locator('.text-2xl').textContent();

    // Mudar período
    await page.click('[role="combobox"]');
    await page.click('text=Últimos 90 dias');
    await page.waitForTimeout(1000);

    // Capturar novo valor
    const valorNovo = await conversasCard.locator('.text-2xl').textContent();

    // Os valores podem ser diferentes (ou não, dependendo dos dados)
    // O importante é que não houve erro
    expect(valorNovo).toBeTruthy();
  });
});

