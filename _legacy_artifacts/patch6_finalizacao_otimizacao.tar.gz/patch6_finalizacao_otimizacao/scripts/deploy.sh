#!/bin/bash

# ============================================================
# Script de Deploy - Primeflow-Hub
# Patch 6 - Finalização e Otimização
# ============================================================

set -e  # Exit on error

# Cores
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Funções de log
info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
    exit 1
}

step() {
    echo -e "${BLUE}[STEP]${NC} $1"
}

# Verificar se está sendo executado como root
if [ "$EUID" -eq 0 ]; then
    error "Este script não deve ser executado como root. Use um usuário normal com sudo."
fi

# Variáveis
PROJECT_DIR="/home/administrator/unified/primeflow-hub-main"
BACKUP_DIR="/home/administrator/backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# Banner
echo "============================================================"
echo "  Primeflow-Hub - Deploy Script"
echo "  Patch 6 - Finalização e Otimização"
echo "============================================================"
echo ""

# 1. Verificar diretório do projeto
step "1/10 - Verificando diretório do projeto..."
if [ ! -d "$PROJECT_DIR" ]; then
    error "Diretório do projeto não encontrado: $PROJECT_DIR"
fi
cd "$PROJECT_DIR"
info "Diretório do projeto OK"

# 2. Criar backup
step "2/10 - Criando backup..."
mkdir -p "$BACKUP_DIR"
tar -czf "$BACKUP_DIR/primeflow-backup-$TIMESTAMP.tar.gz" \
    --exclude="node_modules" \
    --exclude="dist" \
    --exclude=".git" \
    "$PROJECT_DIR" 2>/dev/null || warn "Backup parcial criado"
info "Backup criado: primeflow-backup-$TIMESTAMP.tar.gz"

# 3. Atualizar código
step "3/10 - Atualizando código do repositório..."
git fetch origin
git pull origin main || warn "Falha ao atualizar código. Continuando..."
info "Código atualizado"

# 4. Instalar dependências
step "4/10 - Instalando dependências..."
pnpm install --frozen-lockfile || error "Falha ao instalar dependências"
info "Dependências instaladas"

# 5. Executar migrations
step "5/10 - Executando migrations do banco de dados..."
if [ -f ".env" ]; then
    source .env
    PGPASSWORD="$DB_PASSWORD" psql -h "${DB_HOST:-localhost}" -U "$DB_USER" -d "$DB_NAME" \
        -f database/migrations/*.sql 2>/dev/null || warn "Algumas migrations podem ter falhado"
    info "Migrations executadas"
else
    warn "Arquivo .env não encontrado. Pulando migrations."
fi

# 6. Build do backend
step "6/10 - Compilando backend..."
pnpm build:backend || error "Falha ao compilar backend"
info "Backend compilado"

# 7. Build do frontend
step "7/10 - Compilando frontend..."
pnpm build:frontend || error "Falha ao compilar frontend"
info "Frontend compilado"

# 8. Parar serviços
step "8/10 - Parando serviços..."
pm2 stop primeflow-hub 2>/dev/null || info "Serviço não estava rodando"

# 9. Iniciar serviços
step "9/10 - Iniciando serviços..."
pm2 start ecosystem.config.js || pm2 restart primeflow-hub
pm2 save
info "Serviços iniciados"

# 10. Verificar saúde
step "10/10 - Verificando saúde da aplicação..."
sleep 5
HEALTH_CHECK=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:3333/health || echo "000")

if [ "$HEALTH_CHECK" = "200" ]; then
    info "✅ Health check OK (HTTP 200)"
else
    warn "⚠️ Health check retornou: $HEALTH_CHECK"
fi

# Resumo
echo ""
echo "============================================================"
echo -e "${GREEN}✅ Deploy concluído com sucesso!${NC}"
echo "============================================================"
echo ""
echo "Informações:"
echo "  - Backup: $BACKUP_DIR/primeflow-backup-$TIMESTAMP.tar.gz"
echo "  - Backend: http://localhost:3333"
echo "  - Frontend: http://localhost:5173"
echo "  - Logs: pm2 logs primeflow-hub"
echo ""
echo "Próximos passos:"
echo "  1. Verificar logs: pm2 logs"
echo "  2. Verificar status: pm2 status"
echo "  3. Acessar a aplicação: https://primezap.primezapia.com"
echo ""

exit 0

