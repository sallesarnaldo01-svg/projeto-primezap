# Checklist de Verificação Pós-Patch V8

## ✅ Pré-Deploy

### Ambiente
- [ ] `.env` configurado com todas as variáveis
- [ ] Credenciais do Supabase válidas
- [ ] Banco de dados acessível
- [ ] Redis rodando
- [ ] Portas disponíveis (4000, 6379, 8080)

### Dependências
- [ ] Node.js 18+ ou 20+ instalado
- [ ] Docker e Docker Compose instalados
- [ ] npm ou yarn instalado
- [ ] Git instalado

### Código
- [ ] Patch aplicado com sucesso
- [ ] Backup criado
- [ ] Dependências instaladas (`npm ci --legacy-peer-deps`)
- [ ] Build executado sem erros (`npm run build`)

---

## ✅ Deploy

### Backend API
- [ ] Servidor iniciado (`cd apps/api && npm start`)
- [ ] Health check OK (`curl http://localhost:4000/api/health`)
- [ ] Logs sem erros (`docker logs primeflow-api`)
- [ ] Conexão com banco OK
- [ ] Conexão com Redis OK

### Workers
- [ ] Workers iniciados (`cd apps/worker && npm start`)
- [ ] Redis conectado (`docker logs primeflow-worker | grep "Redis connected"`)
- [ ] Queues registradas (8 queues)
- [ ] Processors ativos (3 processors)

### Frontend
- [ ] Servidor iniciado (`npm run dev` ou `docker run`)
- [ ] Página carrega sem tela branca
- [ ] Console sem erros críticos
- [ ] Assets carregando corretamente
- [ ] Rotas funcionando (SPA fallback OK)

---

## ✅ Funcionalidades

### Autenticação
- [ ] Login funcional
- [ ] Registro de usuário funcional
- [ ] Reset de senha funcional
- [ ] JWT gerado corretamente
- [ ] Sessão persiste após refresh

### Dashboard
- [ ] Métricas carregam dados reais
- [ ] Gráficos renderizam corretamente
- [ ] Filtros funcionam
- [ ] Atualização em tempo real OK

### CRM
- [ ] Criar contato funcional
- [ ] Editar contato funcional
- [ ] Deletar contato funcional
- [ ] Busca funcional
- [ ] Filtros funcionam
- [ ] Kanban atualiza

### Conversas
- [ ] Lista de conversas carrega
- [ ] Mensagens carregam
- [ ] Enviar mensagem funcional
- [ ] Realtime updates funcionam
- [ ] Histórico completo visível

### Workflows
- [ ] Criar workflow funcional
- [ ] Editar workflow funcional
- [ ] **Salvar workflow funcional** ✅ (RESTAURADO)
- [ ] **Carregar workflow funcional** ✅ (RESTAURADO)
- [ ] Nodes e edges persistem
- [ ] Execução de workflow OK

### IA
- [ ] Painel de IA carrega
- [ ] Agentes listados
- [ ] Chat com IA funcional
- [ ] Streaming de resposta OK
- [ ] **Monitoramento de uso funcional** ✅ (RESTAURADO)
- [ ] **Custos registrados** ✅ (RESTAURADO)
- [ ] Function calling OK

### WhatsApp
- [ ] Conexão estabelecida
- [ ] QR Code gerado
- [ ] Enviar mensagem funcional
- [ ] Receber mensagem funcional
- [ ] Webhook configurado

### Workers
- [ ] Bulk AI processa
- [ ] Follow-up dispara
- [ ] Knowledge indexa
- [ ] Broadcasts enviam
- [ ] Filas processam

---

## ✅ Performance

### Frontend
- [ ] Tempo de carregamento < 3s
- [ ] First Contentful Paint < 1.5s
- [ ] Time to Interactive < 3s
- [ ] Lighthouse Score > 80

### Backend
- [ ] Tempo de resposta API < 200ms
- [ ] Queries otimizadas
- [ ] Índices criados
- [ ] Cache configurado

### Workers
- [ ] Jobs processam < 5s
- [ ] Concorrência configurada
- [ ] Retry logic funciona
- [ ] Dead letter queue OK

---

## ✅ Segurança

### Configuração
- [ ] CSP configurado no Nginx
- [ ] CORS configurado corretamente
- [ ] Rate limiting ativo
- [ ] JWT secret forte
- [ ] Variáveis sensíveis em .env

### Validação
- [ ] Input validation em todos os endpoints
- [ ] Sanitização de HTML
- [ ] SQL injection protegido (Prisma)
- [ ] XSS protegido
- [ ] CSRF protegido

### Autenticação
- [ ] Senhas hasheadas (bcrypt)
- [ ] Tokens expiram
- [ ] Refresh tokens funcionam
- [ ] Logout limpa sessão

---

## ✅ Monitoramento

### Logs
- [ ] Logs estruturados
- [ ] Níveis de log configurados
- [ ] Logs centralizados (opcional)
- [ ] Alertas configurados (opcional)

### Métricas
- [ ] CPU monitorada
- [ ] Memória monitorada
- [ ] Disco monitorado
- [ ] Rede monitorada

### Health Checks
- [ ] `/api/health` responde
- [ ] Banco de dados acessível
- [ ] Redis acessível
- [ ] Workers ativos

---

## ✅ Backup e Recuperação

### Backup
- [ ] Backup automático configurado
- [ ] Backup manual testado
- [ ] Backup do banco configurado
- [ ] Backup de arquivos configurado

### Recuperação
- [ ] Rollback testado
- [ ] Restore de backup testado
- [ ] Plano de disaster recovery documentado

---

## ✅ Documentação

### Código
- [ ] README atualizado
- [ ] CHANGELOG atualizado
- [ ] Comentários em código crítico
- [ ] JSDoc em funções principais

### APIs
- [ ] Swagger/OpenAPI configurado (opcional)
- [ ] Endpoints documentados
- [ ] Exemplos de requisição
- [ ] Exemplos de resposta

### Deploy
- [ ] Guia de instalação atualizado
- [ ] Guia de deploy atualizado
- [ ] Troubleshooting documentado
- [ ] FAQ atualizado

---

## 🎯 Resultado Final

### Checklist Completo
- [ ] Todos os itens acima verificados
- [ ] Nenhum erro crítico
- [ ] Performance aceitável
- [ ] Segurança validada
- [ ] Documentação completa

### Aprovação
- [ ] **Aprovado para produção** ✅
- [ ] **Versão 8 estável** ✅
- [ ] **Patch aplicado com sucesso** ✅

---

**Data de Verificação**: ___/___/___  
**Responsável**: _________________  
**Assinatura**: _________________
