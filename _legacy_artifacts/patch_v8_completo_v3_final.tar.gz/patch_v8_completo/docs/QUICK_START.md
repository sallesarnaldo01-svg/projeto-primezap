# Guia de Instalação Rápida - Primeflow-Hub V8

## 🚀 Instalação em 5 Minutos

### Pré-requisitos

- Node.js 18+ ou 20+
- Docker e Docker Compose
- PostgreSQL 14+ (ou usar Supabase)
- Redis 6+
- Git

### Passo 1: Clonar e Aplicar Patch

```bash
# Navegar para o diretório do projeto
cd /home/administrator/unified/primeflow-hub-main

# Aplicar o patch completo
bash /path/to/apply-patch-v8-complete.sh
```

### Passo 2: Configurar Ambiente

```bash
# Copiar .env.example para .env
cp .env.example .env

# Editar .env com suas credenciais
nano .env
```

**Variáveis obrigatórias**:
```bash
VITE_SUPABASE_URL=https://seu-projeto.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=eyJhbGci...
DATABASE_URL=postgresql://user:pass@host:5432/db
REDIS_HOST=localhost
JWT_SECRET=seu_secret_aqui
```

### Passo 3: Instalar Dependências

```bash
# Frontend
npm ci --legacy-peer-deps

# Backend
cd apps/api && npm ci
cd ../worker && npm ci
cd ../..
```

### Passo 4: Executar Migrations

```bash
npx prisma migrate deploy
```

### Passo 5: Iniciar Serviços

#### Opção A: Docker (Recomendado)

```bash
make docker-up
```

#### Opção B: Manual

```bash
# Terminal 1: Frontend
npm run dev

# Terminal 2: Backend
cd apps/api && npm start

# Terminal 3: Workers
cd apps/worker && npm start
```

### Passo 6: Verificar

```bash
# Health check
make health-check

# Ou manualmente
curl http://localhost:4000/api/health
curl http://localhost:8080/
```

## ✅ Pronto!

Acesse: **http://localhost:8080**

---

## 🔧 Comandos Úteis

### Build

```bash
# Build do frontend
npm run build

# Build do backend
cd apps/api && npm run build
```

### Testes

```bash
# Testes unitários
npm test

# Testes e2e
npm run test:e2e
```

### Logs

```bash
# Logs do backend
docker logs primeflow-api

# Logs dos workers
docker logs primeflow-worker

# Logs do frontend
docker logs primezap-frontend
```

### Backup

```bash
# Criar backup
./scripts/create-backup.sh

# Restaurar backup
./scripts/rollback-patch.sh
```

---

## 🆘 Problemas Comuns

### Erro: "Tela branca"

```bash
rm -rf node_modules dist
npm ci --legacy-peer-deps
npm run build
```

### Erro: "Types do Supabase vazios"

```bash
npx prisma migrate deploy
npx supabase gen types typescript --local > src/integrations/supabase/types.ts
```

### Erro: "Workers não processam"

```bash
# Verificar Redis
docker logs primeflow-redis

# Reiniciar workers
docker restart primeflow-worker
```

---

## 📚 Documentação Completa

- [Relatório do Patch](./PATCH_REPORT.md)
- [Arquitetura](./ARCHITECTURE.md)
- [API Reference](./API_REFERENCE.md)
- [Troubleshooting](./TROUBLESHOOTING.md)
