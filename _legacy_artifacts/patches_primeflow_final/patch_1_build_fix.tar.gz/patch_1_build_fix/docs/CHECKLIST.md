# ✅ Checklist de Validação - Patch 1

Use este checklist para garantir que o Patch 1 foi aplicado corretamente.

---

## Pré-Aplicação

- [ ] Backup do projeto criado
- [ ] PostgreSQL rodando
- [ ] Redis rodando (opcional)
- [ ] Node.js >= 18 instalado
- [ ] pnpm ou npm instalado

---

## Durante a Aplicação

- [ ] Script de instalação executado sem erros
- [ ] Arquivos de configuração copiados
- [ ] Imports corrigidos
- [ ] Prisma Client gerado
- [ ] Dependências instaladas

---

## Pós-Aplicação

### 1. Verificar Arquivos

- [ ] `tsconfig.api.json` existe na raiz
- [ ] `apps/api/src/config/env.ts` existe
- [ ] `apps/api/src/lib/prisma.ts` existe
- [ ] `apps/api/src/middleware/auth.ts` existe

### 2. Verificar Build

```bash
cd apps/api
pnpm build
```

- [ ] Build completa sem erros
- [ ] Diretório `dist/` criado
- [ ] Arquivo `dist/index.js` existe
- [ ] Subpastas `dist/controllers/`, `dist/routes/` existem

### 3. Verificar Prisma

```bash
npx prisma generate
```

- [ ] Prisma Client gerado sem erros
- [ ] Arquivo `node_modules/.prisma/client/index.d.ts` existe

### 4. Verificar Imports

Abrir qualquer controller e verificar:

- [ ] Imports terminam com `.js`
- [ ] Import do Prisma funciona: `import { prisma } from '../lib/prisma.js'`
- [ ] Import do logger funciona: `import { logger } from '../lib/logger.js'`
- [ ] Import do env funciona: `import { env } from '../config/env.js'`

### 5. Verificar TypeScript

```bash
cd apps/api
npx tsc --noEmit
```

- [ ] Nenhum erro de tipo
- [ ] AuthRequest reconhecido
- [ ] Prisma Client tipado corretamente

### 6. Teste de Execução (Opcional)

```bash
cd apps/api
pnpm dev
```

- [ ] Servidor inicia sem erros
- [ ] Conecta ao banco de dados
- [ ] Endpoint `/health` responde
- [ ] Endpoint `/api/health` responde

---

## Resultados Esperados

### Build Output

```
✓ Built in 3.2s
✓ 45 modules transformed
✓ dist/index.js created
```

### Dev Server Output

```
🚀 API Server running on port 3001
📝 Environment: development
🌐 CORS enabled for: http://localhost:5173
✅ Database connected
```

### Health Check

```bash
curl http://localhost:3001/health
```

Resposta esperada:
```json
{
  "status": "ok",
  "timestamp": "2025-10-10T12:00:00.000Z",
  "uptime": 1.234
}
```

---

## Problemas Comuns

### ❌ Build falha com "Cannot find module"

**Solução:**
```bash
pnpm install
npx prisma generate
```

### ❌ TypeScript reclama de tipos

**Solução:**
```bash
# Verificar se tsconfig.api.json foi copiado
cat tsconfig.api.json

# Reinstalar dependências
pnpm install
```

### ❌ Prisma Client não encontrado

**Solução:**
```bash
npx prisma generate
```

### ❌ Imports com erro

**Solução:**
```bash
bash patch_1_build_fix/scripts/fix-imports.sh /caminho/do/projeto
```

---

## Próximo Passo

Se todos os itens estão marcados ✅:

→ **Aplicar Patch 2 - Backend Completo**

---

**Data de Validação**: ___________  
**Validado por**: ___________  
**Status**: [ ] Aprovado [ ] Reprovado

