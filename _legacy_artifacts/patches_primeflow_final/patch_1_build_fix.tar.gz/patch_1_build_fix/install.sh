#!/bin/bash

set -e

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

PROJECT_DIR="$1"
PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ -z "$PROJECT_DIR" ]; then
    log_error "Uso: $0 <caminho-do-projeto>"
    log_info "Exemplo: $0 /home/administrator/unified/primeflow-hub-main"
    exit 1
fi

if [ ! -d "$PROJECT_DIR" ]; then
    log_error "Diretório não encontrado: $PROJECT_DIR"
    exit 1
fi

log_info "========================================="
log_info "PATCH 1 - CORREÇÃO DE BUILD"
log_info "========================================="
log_info ""
log_info "Projeto: $PROJECT_DIR"
log_info "Patch: $PATCH_DIR"
log_info ""

# Fase 1: Backup
log_info "[1/7] Criando backup..."
cd "$PROJECT_DIR"
BACKUP_FILE="../backup_pre_patch1_$(date +%Y%m%d_%H%M%S).tar.gz"
tar -czf "$BACKUP_FILE" \
    --exclude=node_modules \
    --exclude=dist \
    --exclude=.next \
    --exclude=build \
    . 2>/dev/null || true
log_success "Backup criado: $BACKUP_FILE"

# Fase 2: Corrigir tsconfig.api.json
log_info "[2/7] Corrigindo tsconfig.api.json..."
if [ -f "$PATCH_DIR/fixes/tsconfig.api.json" ]; then
    cp "$PATCH_DIR/fixes/tsconfig.api.json" "$PROJECT_DIR/tsconfig.api.json"
    log_success "tsconfig.api.json atualizado"
else
    log_warning "Arquivo tsconfig.api.json não encontrado no patch"
fi

# Fase 3: Corrigir arquivos de configuração
log_info "[3/7] Corrigindo arquivos de configuração..."

# Corrigir env.config.ts
if [ -f "$PATCH_DIR/fixes/env.config.ts" ]; then
    mkdir -p "$PROJECT_DIR/apps/api/src/config"
    cp "$PATCH_DIR/fixes/env.config.ts" "$PROJECT_DIR/apps/api/src/config/env.ts"
    log_success "env.ts atualizado"
fi

# Corrigir prisma.lib.ts
if [ -f "$PATCH_DIR/fixes/prisma.lib.ts" ]; then
    mkdir -p "$PROJECT_DIR/apps/api/src/lib"
    cp "$PATCH_DIR/fixes/prisma.lib.ts" "$PROJECT_DIR/apps/api/src/lib/prisma.ts"
    log_success "prisma.ts atualizado"
fi

# Corrigir auth.middleware.ts
if [ -f "$PATCH_DIR/fixes/auth.middleware.ts" ]; then
    mkdir -p "$PROJECT_DIR/apps/api/src/middleware"
    cp "$PATCH_DIR/fixes/auth.middleware.ts" "$PROJECT_DIR/apps/api/src/middleware/auth.ts"
    log_success "auth.ts atualizado"
fi

# Fase 4: Corrigir imports
log_info "[4/7] Corrigindo imports..."
if [ -f "$PATCH_DIR/scripts/fix-imports.sh" ]; then
    bash "$PATCH_DIR/scripts/fix-imports.sh" "$PROJECT_DIR"
else
    log_warning "Script fix-imports.sh não encontrado"
fi

# Fase 5: Gerar Prisma Client
log_info "[5/7] Gerando Prisma Client..."
cd "$PROJECT_DIR"
if [ -f "prisma/schema.prisma" ]; then
    npx prisma generate 2>&1 | tail -5
    log_success "Prisma Client gerado"
else
    log_warning "schema.prisma não encontrado"
fi

# Fase 6: Instalar dependências
log_info "[6/7] Verificando dependências..."
cd "$PROJECT_DIR"

# Verificar se pnpm está disponível
if command -v pnpm &> /dev/null; then
    log_info "Instalando dependências com pnpm..."
    pnpm install 2>&1 | tail -10
    log_success "Dependências instaladas"
else
    log_warning "pnpm não encontrado, usando npm..."
    npm install 2>&1 | tail -10
    log_success "Dependências instaladas"
fi

# Fase 7: Validar build
log_info "[7/7] Validando build..."
cd "$PROJECT_DIR/apps/api"

# Tentar build
log_info "Executando build..."
if pnpm build 2>&1 | tee /tmp/patch1_build.log | tail -15; then
    if [ -d "dist" ] && [ "$(ls -A dist)" ]; then
        log_success "Build funcionando!"
        log_info ""
        log_info "Arquivos gerados:"
        ls -lh dist/ | head -10
    else
        log_warning "Build executou mas dist está vazio"
    fi
else
    log_error "Build falhou. Verifique os logs acima."
    log_info ""
    log_info "Últimos erros:"
    tail -30 /tmp/patch1_build.log
    log_info ""
    log_warning "O patch foi aplicado, mas o build ainda tem problemas."
    log_info "Verifique:"
    log_info "  1. Se todas as dependências estão instaladas"
    log_info "  2. Se o Prisma Client foi gerado"
    log_info "  3. Se as variáveis de ambiente estão configuradas"
    exit 1
fi

log_info ""
log_info "========================================="
log_success "✅ PATCH 1 APLICADO COM SUCESSO!"
log_info "========================================="
log_info ""
log_info "Próximos passos:"
log_info "  1. Aplicar Patch 2 - Backend Completo"
log_info "  2. Aplicar Patch 3 - Frontend Completo"
log_info ""
log_info "Para testar o backend:"
log_info "  cd $PROJECT_DIR/apps/api"
log_info "  pnpm dev"
log_info ""

