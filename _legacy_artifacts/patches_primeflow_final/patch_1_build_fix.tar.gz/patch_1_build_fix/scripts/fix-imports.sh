#!/bin/bash

# Script para corrigir imports problemáticos no backend

PROJECT_DIR="$1"

if [ -z "$PROJECT_DIR" ]; then
    echo "❌ Uso: $0 <caminho-do-projeto>"
    exit 1
fi

echo "🔧 Corrigindo imports no backend..."

API_DIR="$PROJECT_DIR/apps/api/src"

# Corrigir imports do Prisma Client
echo "  → Corrigindo imports do Prisma..."
find "$API_DIR" -type f -name "*.ts" -exec sed -i \
    -e "s|from '@prisma/client'|from '@prisma/client'|g" \
    -e "s|import { prisma }|import { prisma }|g" \
    {} \;

# Corrigir imports de shared
echo "  → Corrigindo imports de @primeflow/shared..."
find "$API_DIR" -type f -name "*.ts" -exec sed -i \
    -e "s|from '@primeflow/shared'|from '@primeflow/shared'|g" \
    {} \;

# Corrigir imports relativos
echo "  → Corrigindo imports relativos..."
find "$API_DIR" -type f -name "*.ts" -exec sed -i \
    -e "s|from '\.\./lib/logger'|from '../lib/logger.js'|g" \
    -e "s|from '\.\./lib/prisma'|from '../lib/prisma.js'|g" \
    -e "s|from '\.\./config/env'|from '../config/env.js'|g" \
    -e "s|from '\.\./middleware/auth'|from '../middleware/auth.js'|g" \
    {} \;

echo "✅ Imports corrigidos!"

