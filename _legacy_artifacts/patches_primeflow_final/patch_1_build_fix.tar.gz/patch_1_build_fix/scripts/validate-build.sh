#!/bin/bash

# Script para validar o build do backend

PROJECT_DIR="$1"

if [ -z "$PROJECT_DIR" ]; then
    echo "❌ Uso: $0 <caminho-do-projeto>"
    exit 1
fi

echo "🔍 Validando build do backend..."
echo ""

cd "$PROJECT_DIR"

# Verificar se Prisma Client foi gerado
echo "[1/4] Verificando Prisma Client..."
if [ ! -d "node_modules/.prisma/client" ] && [ ! -d "node_modules/@prisma/client" ]; then
    echo "  ⚠️  Prisma Client não encontrado. Gerando..."
    npx prisma generate
fi
echo "  ✅ Prisma Client OK"

# Verificar tsconfig
echo "[2/4] Verificando tsconfig..."
if [ ! -f "tsconfig.api.json" ]; then
    echo "  ❌ tsconfig.api.json não encontrado!"
    exit 1
fi
echo "  ✅ tsconfig OK"

# Verificar dependências críticas
echo "[3/4] Verificando dependências..."
MISSING_DEPS=()

if ! npm list express > /dev/null 2>&1; then
    MISSING_DEPS+=("express")
fi

if ! npm list @prisma/client > /dev/null 2>&1; then
    MISSING_DEPS+=("@prisma/client")
fi

if ! npm list typescript > /dev/null 2>&1; then
    MISSING_DEPS+=("typescript")
fi

if [ ${#MISSING_DEPS[@]} -gt 0 ]; then
    echo "  ⚠️  Dependências faltando: ${MISSING_DEPS[*]}"
    echo "  → Instalando dependências..."
    pnpm install
fi
echo "  ✅ Dependências OK"

# Tentar build
echo "[4/4] Testando build..."
cd "$PROJECT_DIR/apps/api"

if pnpm build 2>&1 | tee /tmp/build-output.log; then
    echo ""
    echo "✅ BUILD SUCESSO!"
    echo ""
    echo "Diretório dist criado:"
    ls -lh dist/ 2>/dev/null | head -5
    exit 0
else
    echo ""
    echo "❌ BUILD FALHOU!"
    echo ""
    echo "Últimos erros:"
    tail -20 /tmp/build-output.log
    exit 1
fi

