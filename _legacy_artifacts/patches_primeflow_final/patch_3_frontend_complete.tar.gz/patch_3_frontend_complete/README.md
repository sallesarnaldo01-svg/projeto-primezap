# 🎨 Patch 3 - Frontend Completo

**Versão**: 1.0.0  
**Data**: 10/10/2025  
**Objetivo**: Conectar páginas mockadas às APIs reais  
**Prioridade**: 🟢 MÉDIA  
**Tempo Estimado**: 15-20 minutos  
**Pré-requisitos**: Patch 1 e Patch 2 aplicados

---

## 🎯 O Que Este Patch Faz

Este patch fornece os **serviços de API** e **hooks customizados** necessários para conectar as páginas do frontend às APIs reais criadas no Patch 2.

### Princípio Fundamental

**🎨 PRESERVAR A APARÊNCIA**  
**🔌 CONECTAR AS FUNCIONALIDADES**

Este patch **NÃO altera** o design, layout ou estilos existentes. Ele apenas substitui dados mockados por chamadas de API reais.

---

## 📦 O Que Está Incluído

### Serviços de API

1. ✅ **dashboard.service.ts** - Métricas e KPIs
2. ✅ **crm.service.ts** - Gerenciamento de deals
3. ✅ **contacts.service.ts** - CRUD de contatos
4. ✅ **tickets.service.ts** - Sistema de tickets (a criar)
5. ✅ **users.service.ts** - Gerenciamento de usuários (a criar)
6. ✅ **reports.service.ts** - Relatórios (a criar)
7. ✅ **messages.service.ts** - Mensagens (a criar)

### Hooks Customizados

1. ✅ **useDashboard.ts** - Hooks para Dashboard
2. ✅ **useCRM.ts** - Hooks para CRM
3. ✅ **useContacts.ts** - Hooks para Contatos (a criar)
4. ✅ **useTickets.ts** - Hooks para Tickets (a criar)
5. ✅ **useUsers.ts** - Hooks para Usuários (a criar)

### Documentação

1. ✅ **INTEGRATION_GUIDE.md** - Guia completo de integração
2. ✅ **README.md** - Este arquivo

---

## 🚀 Como Aplicar

### Pré-requisitos

1. ✅ Patch 1 aplicado (build funcionando)
2. ✅ Patch 2 aplicado (7 controllers criados)
3. ✅ Backend rodando em http://localhost:3001
4. ✅ Frontend rodando em http://localhost:5173

### Instalação

```bash
# 1. Extrair o patch
cd /home/administrator
tar -xzf patch_3_frontend_complete.tar.gz
cd patch_3_frontend_complete

# 2. Executar instalação
sudo bash install.sh /home/administrator/unified/primeflow-hub-main

# 3. Aguardar conclusão (15-20 minutos)
```

---

## 📋 Páginas a Integrar

Após aplicar o patch, você precisará atualizar manualmente as seguintes páginas:

### 1. Dashboard.tsx ⭐ PRIORITÁRIO

**Status**: Dados mockados  
**Objetivo**: Conectar às APIs de métricas

**Arquivos necessários:**
- `src/services/dashboard.service.ts` ✅
- `src/hooks/useDashboard.ts` ✅

**Endpoints usados:**
- `GET /api/dashboard/metrics`
- `GET /api/dashboard/funnel`
- `GET /api/dashboard/tickets-by-status`
- `GET /api/dashboard/recent-activity`
- `GET /api/dashboard/performance`

**Tempo estimado**: 30 minutos

---

### 2. CRM.tsx ⭐ PRIORITÁRIO

**Status**: Dados mockados  
**Objetivo**: Conectar ao pipeline de vendas

**Arquivos necessários:**
- `src/services/crm.service.ts` ✅
- `src/hooks/useCRM.ts` ✅

**Endpoints usados:**
- `GET /api/crm/deals`
- `POST /api/crm/deals`
- `PUT /api/crm/deals/:id`
- `PUT /api/crm/deals/:id/stage`
- `GET /api/crm/pipeline`

**Tempo estimado**: 45 minutos

---

### 3. Contatos.tsx

**Status**: Dados mockados  
**Objetivo**: CRUD completo de contatos

**Arquivos necessários:**
- `src/services/contacts.service.ts` ✅
- `src/hooks/useContacts.ts` (a criar)

**Endpoints usados:**
- `GET /api/contacts`
- `POST /api/contacts`
- `PUT /api/contacts/:id`
- `DELETE /api/contacts/:id`

**Tempo estimado**: 40 minutos

---

### 4. Atendimentos.tsx

**Status**: Dados mockados  
**Objetivo**: Sistema de tickets funcional

**Arquivos necessários:**
- `src/services/tickets.service.ts` (a criar)
- `src/hooks/useTickets.ts` (a criar)

**Endpoints usados:**
- `GET /api/tickets`
- `POST /api/tickets`
- `PUT /api/tickets/:id`
- `PUT /api/tickets/:id/assign`

**Tempo estimado**: 40 minutos

---

### 5. Usuarios.tsx

**Status**: Dados mockados  
**Objetivo**: Gerenciamento de usuários

**Arquivos necessários:**
- `src/services/users.service.ts` (a criar)
- `src/hooks/useUsers.ts` (a criar)

**Endpoints usados:**
- `GET /api/users`
- `POST /api/users`
- `PUT /api/users/:id`
- `PUT /api/users/:id/role`
- `PUT /api/users/:id/status`

**Tempo estimado**: 35 minutos

---

### 6. Relatórios.tsx

**Status**: Dados mockados  
**Objetivo**: Relatórios reais com exportação

**Arquivos necessários:**
- `src/services/reports.service.ts` (a criar)
- `src/hooks/useReports.ts` (a criar)

**Endpoints usados:**
- `GET /api/reports/sales`
- `GET /api/reports/performance`
- `GET /api/reports/conversations`
- `GET /api/reports/export`

**Tempo estimado**: 40 minutos

---

### 7. Login.tsx

**Status**: Parcialmente funcional  
**Objetivo**: Autenticação completa

**Arquivos necessários:**
- `src/services/auth.service.ts` (já existe)

**Endpoints usados:**
- `POST /api/auth/login` ✅
- `POST /api/auth/register` (adicionar)
- `POST /api/auth/logout` (adicionar)

**Tempo estimado**: 20 minutos

---

## ✅ Validação

### 1. Verificar Arquivos Instalados

```bash
cd /home/administrator/unified/primeflow-hub-main

# Serviços
ls -l src/services/ | grep -E "(dashboard|crm|contacts)"

# Hooks
ls -l src/hooks/ | grep -E "(useDashboard|useCRM)"
```

### 2. Verificar Dependências

```bash
# React Query deve estar instalado
npm list @tanstack/react-query

# Sonner deve estar instalado
npm list sonner
```

### 3. Testar Integração

```bash
# Terminal 1: Backend
cd apps/api
pnpm dev

# Terminal 2: Frontend
cd ../..
pnpm dev

# Abrir navegador em http://localhost:5173
```

---

## 📖 Guia de Integração

Consulte o guia completo em: **`docs/INTEGRATION_GUIDE.md`**

O guia contém:
- Exemplos de código para cada página
- Padrões de uso dos hooks
- Tratamento de loading e erros
- Preservação da aparência
- Troubleshooting

---

## 🎨 Preservando a Aparência

### ✅ O Que Manter

- Layout existente
- Classes CSS
- Componentes visuais
- Estrutura de grid
- Cores e estilos
- Animações
- Ícones
- Tipografia

### ❌ O Que NÃO Alterar

- Design visual
- Posicionamento
- Espaçamentos
- Breakpoints
- Temas
- Paleta de cores

### 🔄 O Que Substituir

```tsx
// ANTES (mockado)
const [data, setData] = useState(mockData);

// DEPOIS (API real)
const { data, isLoading } = useServiceHook();
```

---

## 🔧 Configuração

### Variáveis de Ambiente

Adicione ao `.env`:

```env
VITE_API_URL=http://localhost:3001/api
```

### API Client

O arquivo `src/services/api.ts` deve estar configurado:

```tsx
import axios from 'axios';

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:3001/api'
});

// Adicionar token automaticamente
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});
```

---

## 🧪 Testando

### Teste Manual

1. **Login**
   - Acessar http://localhost:5173/login
   - Fazer login com credenciais válidas
   - Verificar se o token é salvo

2. **Dashboard**
   - Verificar se as métricas são carregadas
   - Verificar se o funil aparece
   - Verificar se as atividades são listadas

3. **CRM**
   - Verificar se os deals aparecem no pipeline
   - Arrastar deal entre colunas
   - Criar novo deal
   - Editar deal existente

4. **Contatos**
   - Listar contatos
   - Buscar contato
   - Criar novo contato
   - Editar contato
   - Deletar contato

### Teste Automatizado

```bash
# Rodar testes (se configurados)
pnpm test
```

---

## 🐛 Troubleshooting

### Erro: "Cannot find module '@/hooks/useDashboard'"

**Solução:**
```bash
# Verificar se o arquivo existe
ls src/hooks/useDashboard.ts

# Se não existir, copiar novamente
cp patch_3_frontend_complete/hooks/useDashboard.ts src/hooks/
```

### Erro: "Network Error"

**Solução:**
```bash
# Verificar se backend está rodando
curl http://localhost:3001/health

# Verificar variável de ambiente
echo $VITE_API_URL
```

### Dados não aparecem

**Solução:**
1. Abrir DevTools (F12)
2. Verificar aba Network
3. Verificar se as requisições estão sendo feitas
4. Verificar se o status é 200
5. Verificar se há erros de CORS

### Erro: "401 Unauthorized"

**Solução:**
```bash
# Fazer logout e login novamente
localStorage.removeItem('token');
window.location.href = '/login';
```

---

## 📊 Progresso da Integração

Use este checklist para acompanhar o progresso:

- [ ] **Patch aplicado**
  - [ ] Serviços copiados
  - [ ] Hooks copiados
  - [ ] Dependências instaladas

- [ ] **Dashboard.tsx**
  - [ ] Métricas conectadas
  - [ ] Funil conectado
  - [ ] Atividades conectadas
  - [ ] Testado

- [ ] **CRM.tsx**
  - [ ] Pipeline conectado
  - [ ] Drag & drop funcionando
  - [ ] CRUD de deals funcionando
  - [ ] Testado

- [ ] **Contatos.tsx**
  - [ ] Lista conectada
  - [ ] Busca funcionando
  - [ ] CRUD funcionando
  - [ ] Testado

- [ ] **Atendimentos.tsx**
  - [ ] Lista de tickets conectada
  - [ ] Filtros funcionando
  - [ ] Atribuição funcionando
  - [ ] Testado

- [ ] **Usuarios.tsx**
  - [ ] Lista conectada
  - [ ] CRUD funcionando
  - [ ] Roles funcionando
  - [ ] Testado

- [ ] **Relatórios.tsx**
  - [ ] Relatórios conectados
  - [ ] Filtros funcionando
  - [ ] Exportação funcionando
  - [ ] Testado

- [ ] **Login.tsx**
  - [ ] Login funcionando
  - [ ] Registro funcionando
  - [ ] Logout funcionando
  - [ ] Testado

---

## 📝 Notas Importantes

1. **Aparência Preservada**: O design visual não deve ser alterado
2. **Funcionalidades Existentes**: Não desfazer o que já funciona
3. **Incremental**: Pode integrar uma página por vez
4. **Testável**: Cada página deve ser testada após integração
5. **Reversível**: Backup criado automaticamente

---

## 🔄 Próximos Passos

Após aplicar este patch:

1. ✅ **Patch 1 Completo** - Build funcionando
2. ✅ **Patch 2 Completo** - Backend completo
3. ✅ **Patch 3 Aplicado** - Serviços e hooks criados
4. ⏭️ **Integrar páginas** - Seguir INTEGRATION_GUIDE.md
5. ⏭️ **Testar tudo** - Validar funcionalidades
6. ⏭️ **Deploy** - Colocar em produção

---

## 📞 Suporte

Se encontrar problemas:

1. Consultar `docs/INTEGRATION_GUIDE.md`
2. Verificar logs do backend
3. Verificar DevTools do navegador
4. Verificar se todas as dependências estão instaladas

---

**Desenvolvido com ❤️ para o Primeflow-Hub**  
**Mantenha a aparência, conecte as funcionalidades! 🎨🔌**

