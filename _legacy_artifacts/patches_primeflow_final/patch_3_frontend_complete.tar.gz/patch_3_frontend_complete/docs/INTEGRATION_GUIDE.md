# 📘 Guia de Integração - Patch 3

Este guia explica como integrar as APIs reais nas páginas do frontend, substituindo os dados mockados.

---

## 🎯 Objetivo

**Manter a aparência atual** das páginas e **apenas substituir dados mockados** por chamadas de API reais.

**NÃO alterar:**
- Layout
- Estilos
- Componentes visuais
- Estrutura de navegação

**APENAS alterar:**
- Fontes de dados (de mock para API)
- Lógica de fetch
- Estados de loading/error

---

## 📋 Páginas a Atualizar

### 1. Dashboard.tsx

**Localização**: `src/pages/Dashboard.tsx`

**Dados mockados a substituir:**
- Métricas de conversas, contatos, campanhas
- Funil de vendas
- Tickets por status
- Atividades recentes

**Como integrar:**

```tsx
// ANTES (mockado)
const [metrics, setMetrics] = useState({
  conversations: { total: 150, active: 45 },
  contacts: { total: 320 },
  campaigns: { total: 12, active: 3 }
});

// DEPOIS (API real)
import { useDashboardMetrics, useDashboardFunnel } from '@/hooks/useDashboard';

function Dashboard() {
  const { data: metrics, isLoading: metricsLoading } = useDashboardMetrics();
  const { data: funnelData, isLoading: funnelLoading } = useDashboardFunnel();

  if (metricsLoading || funnelLoading) {
    return <div className="flex items-center justify-center h-screen">
      <Loader2 className="h-8 w-8 animate-spin" />
    </div>;
  }

  return (
    <div className="space-y-6">
      {/* Cards de métricas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Conversas</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{metrics?.conversations.total}</p>
            <p className="text-sm text-muted-foreground">
              {metrics?.conversations.active} ativas
            </p>
          </CardContent>
        </Card>
        {/* Outros cards... */}
      </div>

      {/* Funil de vendas */}
      <Card>
        <CardHeader>
          <CardTitle>Funil de Vendas</CardTitle>
        </CardHeader>
        <CardContent>
          {funnelData?.funnel.map(stage => (
            <div key={stage.stage}>
              <p>{stage.stage}: {stage.count} deals</p>
              <p>Valor: R$ {stage.value.toLocaleString()}</p>
            </div>
          ))}
          <p className="mt-4">
            Taxa de conversão: {funnelData?.conversionRate}%
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
```

---

### 2. CRM.tsx

**Localização**: `src/pages/CRM.tsx`

**Dados mockados a substituir:**
- Lista de deals
- Pipeline Kanban
- Criação/edição de deals

**Como integrar:**

```tsx
// ANTES (mockado)
const [deals, setDeals] = useState([
  { id: '1', title: 'Deal 1', value: 5000, stage: 'QUALIFIED' },
  // ...
]);

// DEPOIS (API real)
import { usePipeline, useUpdateDealStage, useCreateDeal } from '@/hooks/useCRM';

function CRM() {
  const { data: pipeline, isLoading } = usePipeline();
  const updateStage = useUpdateDealStage();
  const createDeal = useCreateDeal();

  const handleDragEnd = (result: any) => {
    if (!result.destination) return;

    const dealId = result.draggableId;
    const newStage = result.destination.droppableId;

    updateStage.mutate({ id: dealId, stage: newStage });
  };

  const handleCreateDeal = (data: any) => {
    createDeal.mutate(data);
  };

  if (isLoading) return <Loading />;

  return (
    <DragDropContext onDragEnd={handleDragEnd}>
      <div className="grid grid-cols-4 gap-4">
        {Object.entries(pipeline || {}).map(([stage, deals]) => (
          <Droppable key={stage} droppableId={stage}>
            {(provided) => (
              <div ref={provided.innerRef} {...provided.droppableProps}>
                <h3>{stage}</h3>
                {deals.map((deal, index) => (
                  <Draggable key={deal.id} draggableId={deal.id} index={index}>
                    {(provided) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        {...provided.dragHandleProps}
                      >
                        <Card>
                          <CardHeader>
                            <CardTitle>{deal.title}</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p>R$ {deal.value.toLocaleString()}</p>
                          </CardContent>
                        </Card>
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        ))}
      </div>
    </DragDropContext>
  );
}
```

---

### 3. Contatos.tsx

**Localização**: `src/pages/Contatos.tsx`

**Dados mockados a substituir:**
- Lista de contatos
- Busca e filtros
- Criação/edição/exclusão

**Como integrar:**

```tsx
import { useContacts, useCreateContact, useUpdateContact, useDeleteContact } from '@/hooks/useContacts';
import { useState } from 'react';

function Contatos() {
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);

  const { data, isLoading } = useContacts({ search, page, limit: 50 });
  const createContact = useCreateContact();
  const updateContact = useUpdateContact();
  const deleteContact = useDeleteContact();

  const handleCreate = (contactData: any) => {
    createContact.mutate(contactData);
  };

  const handleUpdate = (id: string, contactData: any) => {
    updateContact.mutate({ id, data: contactData });
  };

  const handleDelete = (id: string) => {
    if (confirm('Tem certeza que deseja deletar este contato?')) {
      deleteContact.mutate(id);
    }
  };

  if (isLoading) return <Loading />;

  return (
    <div className="space-y-4">
      {/* Barra de busca */}
      <div className="flex gap-2">
        <Input
          placeholder="Buscar contatos..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <Button onClick={() => setShowCreateDialog(true)}>
          Novo Contato
        </Button>
      </div>

      {/* Lista de contatos */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {data?.contacts.map(contact => (
          <Card key={contact.id}>
            <CardHeader>
              <CardTitle>{contact.name}</CardTitle>
            </CardHeader>
            <CardContent>
              <p>{contact.email}</p>
              <p>{contact.phone}</p>
              <div className="flex gap-2 mt-4">
                <Button size="sm" onClick={() => handleEdit(contact)}>
                  Editar
                </Button>
                <Button
                  size="sm"
                  variant="destructive"
                  onClick={() => handleDelete(contact.id)}
                >
                  Deletar
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Paginação */}
      <div className="flex justify-center gap-2">
        <Button
          disabled={page === 1}
          onClick={() => setPage(p => p - 1)}
        >
          Anterior
        </Button>
        <span>Página {page} de {data?.pagination.pages}</span>
        <Button
          disabled={page === data?.pagination.pages}
          onClick={() => setPage(p => p + 1)}
        >
          Próxima
        </Button>
      </div>
    </div>
  );
}
```

---

### 4. Atendimentos.tsx

**Localização**: `src/pages/Atendimentos.tsx`

**Dados mockados a substituir:**
- Fila de tickets
- Status e prioridades
- Atribuição de tickets

**Como integrar:**

```tsx
import { useTickets, useAssignTicket, useUpdateTicket } from '@/hooks/useTickets';

function Atendimentos() {
  const [statusFilter, setStatusFilter] = useState<string>();
  const [priorityFilter, setPriorityFilter] = useState<string>();

  const { data, isLoading } = useTickets({
    status: statusFilter,
    priority: priorityFilter
  });

  const assignTicket = useAssignTicket();
  const updateTicket = useUpdateTicket();

  const handleAssign = (ticketId: string, userId: string) => {
    assignTicket.mutate({ id: ticketId, assignedToId: userId });
  };

  const handleUpdateStatus = (ticketId: string, status: string) => {
    updateTicket.mutate({ id: ticketId, data: { status } });
  };

  if (isLoading) return <Loading />;

  return (
    <div className="space-y-4">
      {/* Filtros */}
      <div className="flex gap-2">
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger>
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="OPEN">Aberto</SelectItem>
            <SelectItem value="IN_PROGRESS">Em Progresso</SelectItem>
            <SelectItem value="RESOLVED">Resolvido</SelectItem>
          </SelectContent>
        </Select>

        <Select value={priorityFilter} onValueChange={setPriorityFilter}>
          <SelectTrigger>
            <SelectValue placeholder="Prioridade" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="LOW">Baixa</SelectItem>
            <SelectItem value="MEDIUM">Média</SelectItem>
            <SelectItem value="HIGH">Alta</SelectItem>
            <SelectItem value="URGENT">Urgente</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Lista de tickets */}
      <div className="space-y-2">
        {data?.tickets.map(ticket => (
          <Card key={ticket.id}>
            <CardHeader>
              <CardTitle>{ticket.title}</CardTitle>
              <Badge>{ticket.status}</Badge>
              <Badge variant={ticket.priority === 'URGENT' ? 'destructive' : 'default'}>
                {ticket.priority}
              </Badge>
            </CardHeader>
            <CardContent>
              <p>{ticket.description}</p>
              <div className="flex gap-2 mt-4">
                <Button onClick={() => handleUpdateStatus(ticket.id, 'IN_PROGRESS')}>
                  Iniciar
                </Button>
                <Button onClick={() => handleUpdateStatus(ticket.id, 'RESOLVED')}>
                  Resolver
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
```

---

## 🔧 Configuração do API Client

Certifique-se de que o arquivo `src/services/api.ts` está configurado corretamente:

```tsx
import axios from 'axios';

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:3001/api',
  headers: {
    'Content-Type': 'application/json'
  }
});

// Interceptor para adicionar token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Interceptor para tratar erros
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);
```

---

## 🎨 Mantendo a Aparência

**IMPORTANTE**: Ao integrar as APIs, mantenha:

✅ **Manter:**
- Classes CSS existentes
- Estrutura de componentes
- Layout e grid
- Cores e estilos
- Animações
- Ícones

❌ **NÃO alterar:**
- Design visual
- Posicionamento de elementos
- Tipografia
- Espaçamentos
- Breakpoints responsivos

---

## 🧪 Testando

1. **Iniciar backend:**
```bash
cd apps/api
pnpm dev
```

2. **Iniciar frontend:**
```bash
cd ../..
pnpm dev
```

3. **Verificar no navegador:**
- Abrir http://localhost:5173
- Login com credenciais válidas
- Navegar pelas páginas
- Verificar se os dados são carregados da API
- Testar criação, edição e exclusão

---

## 📝 Checklist de Integração

Por página, verificar:

- [ ] Dados mockados removidos
- [ ] Hook de API implementado
- [ ] Loading state adicionado
- [ ] Error handling implementado
- [ ] Aparência preservada
- [ ] Funcionalidades testadas
- [ ] Paginação funcionando (se aplicável)
- [ ] Filtros funcionando (se aplicável)
- [ ] CRUD completo (se aplicável)

---

## 🆘 Troubleshooting

### Erro: "Network Error"

**Causa**: Backend não está rodando ou URL incorreta

**Solução**:
```bash
# Verificar se backend está rodando
curl http://localhost:3001/health

# Se não estiver, iniciar:
cd apps/api && pnpm dev
```

### Erro: "401 Unauthorized"

**Causa**: Token inválido ou expirado

**Solução**:
- Fazer logout e login novamente
- Verificar se o token está sendo enviado no header

### Dados não aparecem

**Causa**: Banco de dados vazio

**Solução**:
- Popular banco com dados de teste
- Verificar se as migrations foram executadas

---

**Boa integração! 🚀**

