import { useQuery } from '@tanstack/react-query';
import { dashboardService } from '../services/dashboard.service';

export function useDashboardMetrics() {
  return useQuery({
    queryKey: ['dashboard', 'metrics'],
    queryFn: () => dashboardService.getMetrics(),
    refetchInterval: 30000, // Atualizar a cada 30 segundos
  });
}

export function useDashboardFunnel() {
  return useQuery({
    queryKey: ['dashboard', 'funnel'],
    queryFn: () => dashboardService.getFunnel(),
    refetchInterval: 60000, // Atualizar a cada 1 minuto
  });
}

export function useDashboardTicketsByStatus() {
  return useQuery({
    queryKey: ['dashboard', 'tickets-by-status'],
    queryFn: () => dashboardService.getTicketsByStatus(),
    refetchInterval: 30000,
  });
}

export function useDashboardRecentActivity(limit: number = 10) {
  return useQuery({
    queryKey: ['dashboard', 'recent-activity', limit],
    queryFn: () => dashboardService.getRecentActivity(limit),
    refetchInterval: 15000, // Atualizar a cada 15 segundos
  });
}

export function useDashboardPerformance(period: 'day' | 'week' | 'month' = 'week') {
  return useQuery({
    queryKey: ['dashboard', 'performance', period],
    queryFn: () => dashboardService.getPerformance(period),
    refetchInterval: 60000,
  });
}

