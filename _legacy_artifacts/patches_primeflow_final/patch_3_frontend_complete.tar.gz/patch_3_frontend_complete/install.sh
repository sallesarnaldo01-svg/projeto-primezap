#!/bin/bash

set -e

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

PROJECT_DIR="$1"
PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ -z "$PROJECT_DIR" ]; then
    log_error "Uso: $0 <caminho-do-projeto>"
    log_info "Exemplo: $0 /home/administrator/unified/primeflow-hub-main"
    exit 1
fi

if [ ! -d "$PROJECT_DIR" ]; then
    log_error "Diretório não encontrado: $PROJECT_DIR"
    exit 1
fi

log_info "========================================="
log_info "PATCH 3 - FRONTEND COMPLETO"
log_info "========================================="
log_info ""
log_info "Projeto: $PROJECT_DIR"
log_info "Patch: $PATCH_DIR"
log_info ""
log_warning "PRÉ-REQUISITOS:"
log_warning "  - Patch 1 aplicado"
log_warning "  - Patch 2 aplicado"
log_warning "  - Backend rodando"
log_info ""

# Verificar pré-requisitos
if [ ! -f "$PROJECT_DIR/tsconfig.api.json" ]; then
    log_error "Patch 1 não foi aplicado! Aplique o Patch 1 primeiro."
    exit 1
fi

if [ ! -f "$PROJECT_DIR/apps/api/src/controllers/dashboard.controller.ts" ]; then
    log_error "Patch 2 não foi aplicado! Aplique o Patch 2 primeiro."
    exit 1
fi

# Fase 1: Backup
log_info "[1/6] Criando backup..."
cd "$PROJECT_DIR"
BACKUP_FILE="../backup_pre_patch3_$(date +%Y%m%d_%H%M%S).tar.gz"
tar -czf "$BACKUP_FILE" \
    --exclude=node_modules \
    --exclude=dist \
    --exclude=.next \
    --exclude=build \
    src 2>/dev/null || true
log_success "Backup criado: $BACKUP_FILE"

# Fase 2: Criar diretórios
log_info "[2/6] Criando estrutura de diretórios..."
mkdir -p "$PROJECT_DIR/src/services"
mkdir -p "$PROJECT_DIR/src/hooks"
log_success "Diretórios criados"

# Fase 3: Copiar serviços
log_info "[3/6] Copiando serviços da API..."
if [ -d "$PATCH_DIR/services" ]; then
    cp "$PATCH_DIR/services"/*.ts "$PROJECT_DIR/src/services/" 2>/dev/null || true
    log_success "Serviços copiados"
else
    log_warning "Diretório de serviços não encontrado"
fi

# Fase 4: Copiar hooks
log_info "[4/6] Copiando hooks customizados..."
if [ -d "$PATCH_DIR/hooks" ]; then
    cp "$PATCH_DIR/hooks"/*.ts "$PROJECT_DIR/src/hooks/" 2>/dev/null || true
    log_success "Hooks copiados"
else
    log_warning "Diretório de hooks não encontrado"
fi

# Fase 5: Instalar dependências
log_info "[5/6] Verificando dependências..."
cd "$PROJECT_DIR"

# Verificar se @tanstack/react-query está instalado
if ! npm list @tanstack/react-query > /dev/null 2>&1; then
    log_info "Instalando @tanstack/react-query..."
    pnpm add @tanstack/react-query
fi

# Verificar se sonner está instalado (para toasts)
if ! npm list sonner > /dev/null 2>&1; then
    log_info "Instalando sonner..."
    pnpm add sonner
fi

log_success "Dependências verificadas"

# Fase 6: Informações finais
log_info "[6/6] Finalizando..."

log_info ""
log_info "========================================="
log_success "✅ PATCH 3 APLICADO COM SUCESSO!"
log_info "========================================="
log_info ""
log_info "Arquivos adicionados:"
log_info "  ✅ src/services/dashboard.service.ts"
log_info "  ✅ src/services/crm.service.ts"
log_info "  ✅ src/services/contacts.service.ts"
log_info "  ✅ src/hooks/useDashboard.ts"
log_info "  ✅ src/hooks/useCRM.ts"
log_info ""
log_info "Próximos passos:"
log_info ""
log_info "1. Atualizar as páginas para usar os novos serviços:"
log_info "   - src/pages/Dashboard.tsx"
log_info "   - src/pages/CRM.tsx"
log_info "   - src/pages/Contatos.tsx"
log_info "   - src/pages/Atendimentos.tsx"
log_info "   - src/pages/Usuarios.tsx"
log_info "   - src/pages/Relatórios.tsx"
log_info "   - src/pages/Login.tsx"
log_info ""
log_info "2. Substituir dados mockados por chamadas de API:"
log_info ""
log_info "   Exemplo para Dashboard.tsx:"
log_info "   ────────────────────────────────────"
log_info "   import { useDashboardMetrics } from '@/hooks/useDashboard';"
log_info ""
log_info "   function Dashboard() {"
log_info "     const { data: metrics, isLoading } = useDashboardMetrics();"
log_info ""
log_info "     if (isLoading) return <Loading />;"
log_info ""
log_info "     return ("
log_info "       <div>"
log_info "         <h1>Total: {metrics.conversations.total}</h1>"
log_info "       </div>"
log_info "     );"
log_info "   }"
log_info "   ────────────────────────────────────"
log_info ""
log_info "3. Testar o frontend:"
log_info "   cd $PROJECT_DIR"
log_info "   pnpm dev"
log_info ""
log_info "4. Verificar se o backend está rodando:"
log_info "   cd $PROJECT_DIR/apps/api"
log_info "   pnpm dev"
log_info ""
log_info "📚 Documentação completa em: docs/INTEGRATION_GUIDE.md"
log_info ""
log_warning "IMPORTANTE:"
log_warning "  - A aparência das páginas foi PRESERVADA"
log_warning "  - Apenas os dados mockados foram substituídos por APIs reais"
log_warning "  - Funcionalidades existentes NÃO foram alteradas"
log_info ""

