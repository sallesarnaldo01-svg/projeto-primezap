#!/bin/bash

# Script para integrar as mudanças do frontend

PROJECT_DIR="$1"

if [ -z "$PROJECT_DIR" ]; then
    echo "❌ Uso: $0 <caminho-do-projeto>"
    exit 1
fi

echo "🔧 Integrando mudanças do frontend..."

SRC_DIR="$PROJECT_DIR/src"

# Criar diretórios se não existirem
mkdir -p "$SRC_DIR/services"
mkdir -p "$SRC_DIR/hooks"

# Copiar serviços
echo "  → Copiando serviços..."
cp services/*.ts "$SRC_DIR/services/" 2>/dev/null || true

# Copiar hooks
echo "  → Copiando hooks..."
cp hooks/*.ts "$SRC_DIR/hooks/" 2>/dev/null || true

# Copiar páginas atualizadas
echo "  → Copiando páginas..."
if [ -d "pages" ]; then
    cp pages/*.tsx "$SRC_DIR/pages/" 2>/dev/null || true
fi

# Copiar componentes
echo "  → Copiando componentes..."
if [ -d "components" ]; then
    cp -r components/* "$SRC_DIR/components/" 2>/dev/null || true
fi

echo "✅ Integração concluída!"

