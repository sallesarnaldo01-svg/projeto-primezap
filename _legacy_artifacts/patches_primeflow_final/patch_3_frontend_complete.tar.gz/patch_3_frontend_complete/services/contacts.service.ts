import { api } from './api';

export interface Contact {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  avatar?: string;
  tags: string[];
  customFields: Record<string, any>;
  notes?: string;
  userId: string;
  createdAt: string;
  updatedAt: string;
  _count?: {
    conversations: number;
    deals: number;
  };
}

export interface ContactDetails extends Contact {
  conversations?: Array<{
    id: string;
    platform: string;
    status: string;
    lastMessageAt: string;
    createdAt: string;
  }>;
  deals?: Array<{
    id: string;
    title: string;
    value: number;
    stage: string;
    createdAt: string;
  }>;
}

export interface CreateContactInput {
  name: string;
  email?: string;
  phone?: string;
  avatar?: string;
  tags?: string[];
  customFields?: Record<string, any>;
  notes?: string;
}

export interface UpdateContactInput {
  name?: string;
  email?: string;
  phone?: string;
  avatar?: string;
  tags?: string[];
  customFields?: Record<string, any>;
  notes?: string;
}

export const contactsService = {
  async getContacts(params?: {
    search?: string;
    tag?: string;
    page?: number;
    limit?: number;
    sortBy?: string;
    order?: 'asc' | 'desc';
  }): Promise<{ contacts: Contact[]; pagination: any }> {
    const response = await api.get('/contacts', { params });
    return response.data;
  },

  async getContact(id: string): Promise<ContactDetails> {
    const response = await api.get(`/contacts/${id}`);
    return response.data;
  },

  async createContact(data: CreateContactInput): Promise<Contact> {
    const response = await api.post('/contacts', data);
    return response.data;
  },

  async updateContact(id: string, data: UpdateContactInput): Promise<Contact> {
    const response = await api.put(`/contacts/${id}`, data);
    return response.data;
  },

  async deleteContact(id: string): Promise<void> {
    await api.delete(`/contacts/${id}`);
  },

  async addTags(id: string, tags: string[]): Promise<Contact> {
    const response = await api.post(`/contacts/${id}/tags`, { tags });
    return response.data;
  },

  async removeTags(id: string, tags: string[]): Promise<Contact> {
    const response = await api.delete(`/contacts/${id}/tags`, { data: { tags } });
    return response.data;
  }
};

