import { api } from './api';

export interface Deal {
  id: string;
  title: string;
  value: number;
  stage: 'LEAD' | 'QUALIFIED' | 'PROPOSAL' | 'NEGOTIATION' | 'CLOSED_WON' | 'CLOSED_LOST';
  expectedCloseDate?: string;
  closedAt?: string;
  notes?: string;
  contactId: string;
  contact?: {
    id: string;
    name: string;
    email?: string;
    phone?: string;
    avatar?: string;
  };
  assignedToId?: string;
  assignedTo?: {
    id: string;
    name: string;
    email: string;
    avatar?: string;
  };
  createdAt: string;
  updatedAt: string;
}

export interface CreateDealInput {
  title: string;
  contactId: string;
  value?: number;
  stage?: string;
  expectedCloseDate?: string;
  notes?: string;
}

export interface UpdateDealInput {
  title?: string;
  value?: number;
  stage?: string;
  expectedCloseDate?: string;
  notes?: string;
  assignedToId?: string;
}

export interface Pipeline {
  LEAD: Deal[];
  QUALIFIED: Deal[];
  PROPOSAL: Deal[];
  NEGOTIATION: Deal[];
}

export const crmService = {
  async getDeals(params?: {
    stage?: string;
    search?: string;
    page?: number;
    limit?: number;
  }): Promise<{ deals: Deal[]; pagination: any }> {
    const response = await api.get('/crm/deals', { params });
    return response.data;
  },

  async createDeal(data: CreateDealInput): Promise<Deal> {
    const response = await api.post('/crm/deals', data);
    return response.data;
  },

  async updateDeal(id: string, data: UpdateDealInput): Promise<Deal> {
    const response = await api.put(`/crm/deals/${id}`, data);
    return response.data;
  },

  async updateDealStage(id: string, stage: string): Promise<Deal> {
    const response = await api.put(`/crm/deals/${id}/stage`, { stage });
    return response.data;
  },

  async deleteDeal(id: string): Promise<void> {
    await api.delete(`/crm/deals/${id}`);
  },

  async getPipeline(): Promise<Pipeline> {
    const response = await api.get('/crm/pipeline');
    return response.data;
  }
};

