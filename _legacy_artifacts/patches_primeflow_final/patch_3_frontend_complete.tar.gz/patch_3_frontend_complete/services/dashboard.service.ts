import { api } from './api';

export interface DashboardMetrics {
  conversations: {
    total: number;
    active: number;
    today: number;
    thisWeek: number;
    thisMonth: number;
    growthRate: number;
  };
  contacts: {
    total: number;
  };
  campaigns: {
    total: number;
    active: number;
  };
}

export interface FunnelData {
  stage: string;
  count: number;
  value: number;
}

export interface TicketsByStatus {
  status: string;
  count: number;
}

export interface Activity {
  id: string;
  type: string;
  description: string;
  createdAt: string;
  user: {
    id: string;
    name: string;
    email: string;
    avatar?: string;
  };
}

export interface PerformanceMetrics {
  avgResponseTime: number;
  avgResolutionTime: number;
  satisfactionRate: number;
  period: string;
}

export const dashboardService = {
  async getMetrics(): Promise<DashboardMetrics> {
    const response = await api.get('/dashboard/metrics');
    return response.data.metrics;
  },

  async getFunnel(): Promise<{ funnel: FunnelData[]; conversionRate: number }> {
    const response = await api.get('/dashboard/funnel');
    return response.data;
  },

  async getTicketsByStatus(): Promise<TicketsByStatus[]> {
    const response = await api.get('/dashboard/tickets-by-status');
    return response.data.tickets;
  },

  async getRecentActivity(limit: number = 10): Promise<Activity[]> {
    const response = await api.get('/dashboard/recent-activity', {
      params: { limit }
    });
    return response.data.activities;
  },

  async getPerformance(period: 'day' | 'week' | 'month' = 'week'): Promise<PerformanceMetrics> {
    const response = await api.get('/dashboard/performance', {
      params: { period }
    });
    return response.data.performance;
  }
};

