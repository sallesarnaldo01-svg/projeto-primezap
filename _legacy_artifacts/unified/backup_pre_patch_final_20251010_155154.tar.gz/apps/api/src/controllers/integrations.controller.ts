// apps/api/src/controllers/integrations.controller.ts
import { Request, Response } from 'express';
import { supabase } from '../lib/supabase';
import axios from 'axios';

/**
 * Controller para gerenciar integrações (WhatsApp, Facebook, Instagram)
 */

// Listar todas as integrações do usuário
export const getIntegrations = async (req: Request, res: Response) => {
  try {
    const userId = req.user?.id;

    const { data, error } = await supabase
      .from('integrations')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) throw error;

    res.json(data);
  } catch (error: any) {
    console.error('Error fetching integrations:', error);
    res.status(500).json({ error: error.message });
  }
};

// Obter status agregado das integrações
export const getIntegrationsStatus = async (req: Request, res: Response) => {
  try {
    const userId = req.user?.id;

    const { data, error } = await supabase
      .from('integrations')
      .select('id, platform, status, last_sync_at, updated_at, created_at')
      .eq('user_id', userId)
      .order('updated_at', { ascending: false });

    if (error) throw error;

    const stats = {
      total: data?.length ?? 0,
      active: data?.filter((integration) => integration.status === 'active').length ?? 0,
      error: data?.filter((integration) => integration.status === 'error').length ?? 0,
      pending: data?.filter((integration) => integration.status === 'pending').length ?? 0,
    };

    res.json({ stats, integrations: data });
  } catch (error: any) {
    console.error('Error fetching integration status:', error);
    res.status(500).json({ error: error.message });
  }
};

// Obter uma integração específica
export const getIntegration = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const userId = req.user?.id;

    const { data, error } = await supabase
      .from('integrations')
      .select('*')
      .eq('id', id)
      .eq('user_id', userId)
      .single();

    if (error) throw error;

    if (!data) {
      return res.status(404).json({ error: 'Integration not found' });
    }

    res.json(data);
  } catch (error: any) {
    console.error('Error fetching integration:', error);
    res.status(500).json({ error: error.message });
  }
};

// Criar nova integração
export const createIntegration = async (req: Request, res: Response) => {
  try {
    const userId = req.user?.id;
    const { platform, name, ...credentials } = req.body;

    // Validar plataforma
    if (!['whatsapp', 'facebook', 'instagram'].includes(platform)) {
      return res.status(400).json({ error: 'Invalid platform' });
    }

    // Validar credenciais conforme a plataforma
    if (platform === 'whatsapp') {
      if (!credentials.access_token || !credentials.phone_number_id) {
        return res.status(400).json({ 
          error: 'WhatsApp requires access_token and phone_number_id' 
        });
      }
    }

    const { data, error } = await supabase
      .from('integrations')
      .insert({
        user_id: userId,
        platform,
        name,
        status: 'pending',
        ...credentials,
      })
      .select()
      .single();

    if (error) throw error;

    // Testar conexão
    const testResult = await testIntegrationConnection(data);
    
    // Atualizar status
    await supabase
      .from('integrations')
      .update({ status: testResult.success ? 'active' : 'error' })
      .eq('id', data.id);

    res.status(201).json({ ...data, test_result: testResult });
  } catch (error: any) {
    console.error('Error creating integration:', error);
    res.status(500).json({ error: error.message });
  }
};

// Atualizar integração
export const updateIntegration = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const userId = req.user?.id;
    const updates = req.body;

    const { data, error } = await supabase
      .from('integrations')
      .update(updates)
      .eq('id', id)
      .eq('user_id', userId)
      .select()
      .single();

    if (error) throw error;

    if (!data) {
      return res.status(404).json({ error: 'Integration not found' });
    }

    res.json(data);
  } catch (error: any) {
    console.error('Error updating integration:', error);
    res.status(500).json({ error: error.message });
  }
};

// Deletar integração
export const deleteIntegration = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const userId = req.user?.id;

    const { error } = await supabase
      .from('integrations')
      .delete()
      .eq('id', id)
      .eq('user_id', userId);

    if (error) throw error;

    res.status(204).send();
  } catch (error: any) {
    console.error('Error deleting integration:', error);
    res.status(500).json({ error: error.message });
  }
};

// Testar conexão da integração
export const testIntegration = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const userId = req.user?.id;

    const { data: integration, error } = await supabase
      .from('integrations')
      .select('*')
      .eq('id', id)
      .eq('user_id', userId)
      .single();

    if (error) throw error;

    if (!integration) {
      return res.status(404).json({ error: 'Integration not found' });
    }

    const result = await testIntegrationConnection(integration);

    // Atualizar status
    await supabase
      .from('integrations')
      .update({ 
        status: result.success ? 'active' : 'error',
        last_sync_at: new Date().toISOString()
      })
      .eq('id', id);

    res.json(result);
  } catch (error: any) {
    console.error('Error testing integration:', error);
    res.status(500).json({ error: error.message });
  }
};

// Sincronizar integração (buscar dados atualizados)
export const syncIntegration = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const userId = req.user?.id;

    const { data: integration, error } = await supabase
      .from('integrations')
      .select('*')
      .eq('id', id)
      .eq('user_id', userId)
      .single();

    if (error) throw error;

    if (!integration) {
      return res.status(404).json({ error: 'Integration not found' });
    }

    // Sincronizar conforme a plataforma
    let syncResult;
    switch (integration.platform) {
      case 'whatsapp':
        syncResult = await syncWhatsApp(integration);
        break;
      case 'facebook':
        syncResult = await syncFacebook(integration);
        break;
      case 'instagram':
        syncResult = await syncInstagram(integration);
        break;
      default:
        throw new Error('Unsupported platform');
    }

    // Atualizar last_sync_at
    await supabase
      .from('integrations')
      .update({ last_sync_at: new Date().toISOString() })
      .eq('id', id);

    res.json(syncResult);
  } catch (error: any) {
    console.error('Error syncing integration:', error);
    res.status(500).json({ error: error.message });
  }
};

// ============================================================================
// FUNÇÕES AUXILIARES
// ============================================================================

/**
 * Testar conexão com a integração
 */
async function testIntegrationConnection(integration: any) {
  try {
    switch (integration.platform) {
      case 'whatsapp':
        return await testWhatsAppConnection(integration);
      case 'facebook':
        return await testFacebookConnection(integration);
      case 'instagram':
        return await testInstagramConnection(integration);
      default:
        return { success: false, error: 'Unsupported platform' };
    }
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

/**
 * Testar conexão WhatsApp
 */
async function testWhatsAppConnection(integration: any) {
  try {
    const response = await axios.get(
      `https://graph.facebook.com/${integration.api_version}/${integration.phone_number_id}`,
      {
        headers: {
          Authorization: `Bearer ${integration.access_token}`,
        },
      }
    );

    return {
      success: true,
      data: {
        phone_number: response.data.display_phone_number,
        verified: response.data.verified_name,
        quality_rating: response.data.quality_rating,
      },
    };
  } catch (error: any) {
    return {
      success: false,
      error: error.response?.data?.error?.message || error.message,
    };
  }
}

/**
 * Testar conexão Facebook
 */
async function testFacebookConnection(integration: any) {
  try {
    const response = await axios.get(
      `https://graph.facebook.com/${integration.api_version}/me`,
      {
        params: {
          access_token: integration.access_token,
          fields: 'id,name',
        },
      }
    );

    return {
      success: true,
      data: {
        page_id: response.data.id,
        page_name: response.data.name,
      },
    };
  } catch (error: any) {
    return {
      success: false,
      error: error.response?.data?.error?.message || error.message,
    };
  }
}

/**
 * Testar conexão Instagram
 */
async function testInstagramConnection(integration: any) {
  try {
    const response = await axios.get(
      `https://graph.facebook.com/${integration.api_version}/${integration.instagram_account_id}`,
      {
        params: {
          access_token: integration.access_token,
          fields: 'id,username,profile_picture_url',
        },
      }
    );

    return {
      success: true,
      data: {
        instagram_id: response.data.id,
        username: response.data.username,
        profile_picture: response.data.profile_picture_url,
      },
    };
  } catch (error: any) {
    return {
      success: false,
      error: error.response?.data?.error?.message || error.message,
    };
  }
}

/**
 * Sincronizar WhatsApp
 */
async function syncWhatsApp(integration: any) {
  // Implementar lógica de sincronização
  return { success: true, message: 'WhatsApp synchronized' };
}

/**
 * Sincronizar Facebook
 */
async function syncFacebook(integration: any) {
  // Implementar lógica de sincronização
  return { success: true, message: 'Facebook synchronized' };
}

/**
 * Sincronizar Instagram
 */
async function syncInstagram(integration: any) {
  // Implementar lógica de sincronização
  return { success: true, message: 'Instagram synchronized' };
}

export const integrationsController = {
  list: getIntegrations,
  status: getIntegrationsStatus,
  create: createIntegration,
  update: updateIntegration,
  delete: deleteIntegration,
  sync: syncIntegration,
  test: testIntegration,
};
