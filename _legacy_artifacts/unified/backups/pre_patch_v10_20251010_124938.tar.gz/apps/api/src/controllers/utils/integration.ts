import { Connection } from '@prisma/client';

type PrismaJson = Record<string, any> | null;

export interface IntegrationView {
  id: string;
  provider: string;
  status: 'connected' | 'connecting' | 'disconnected' | 'error';
  connectedAt?: string;
  lastSyncAt?: string;
  config?: Record<string, any>;
  error?: string;
}

export interface IntegrationStatusView {
  provider: string;
  connected: boolean;
  accounts: number;
  lastSync?: string;
}

function normalizeMeta(meta: PrismaJson): Record<string, any> {
  if (!meta) {
    return {};
  }

  if (typeof meta === 'object' && !Array.isArray(meta)) {
    return meta;
  }

  return { value: meta };
}

export function mapConnectionStatus(status: string): IntegrationView['status'] {
  switch (status) {
    case 'CONNECTED':
      return 'connected';
    case 'CONNECTING':
      return 'connecting';
    case 'ERROR':
      return 'error';
    default:
      return 'disconnected';
  }
}

export function connectionToIntegration(
  connection: Connection
): IntegrationView {
  const meta = normalizeMeta(connection.meta as PrismaJson);
  const status = mapConnectionStatus(connection.status);

  return {
    id: connection.id,
    provider: connection.type.toLowerCase(),
    status,
    connectedAt:
      status === 'connected' && connection.updatedAt
        ? connection.updatedAt.toISOString()
        : undefined,
    lastSyncAt:
      typeof meta.lastSyncAt === 'string' ? meta.lastSyncAt : undefined,
    config: meta,
    error:
      typeof meta.error === 'string'
        ? meta.error
        : meta.error?.message ?? undefined,
  };
}

export function summarizeIntegrations(
  connections: Connection[]
): IntegrationStatusView[] {
  const summaryMap = new Map<string, IntegrationStatusView>();

  for (const connection of connections) {
    const provider = connection.type.toLowerCase();
    const current = summaryMap.get(provider) ?? {
      provider,
      connected: false,
      accounts: 0,
      lastSync: undefined as string | undefined,
    };

    const meta = normalizeMeta(connection.meta as PrismaJson);
    current.accounts += 1;

    if (connection.status === 'CONNECTED') {
      current.connected = true;
    }

    const metaLastSync =
      typeof meta.lastSyncAt === 'string' ? meta.lastSyncAt : undefined;

    const candidate =
      metaLastSync ??
      (connection.updatedAt ? connection.updatedAt.toISOString() : undefined);

    if (
      candidate &&
      (!current.lastSync ||
        new Date(candidate).getTime() > new Date(current.lastSync).getTime())
    ) {
      current.lastSync = candidate;
    }

    summaryMap.set(provider, current);
  }

  return Array.from(summaryMap.values()).map(({ lastSync, ...rest }) => ({
    ...rest,
    lastSync,
  }));
}
