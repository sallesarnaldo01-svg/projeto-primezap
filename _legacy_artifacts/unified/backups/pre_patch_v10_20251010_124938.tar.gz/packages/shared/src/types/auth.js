export var Role;
(function (Role) {
    Role["ADMIN"] = "ADMIN";
    Role["MANAGER"] = "MANAGER";
    Role["AGENT"] = "AGENT";
})(Role || (Role = {}));
