export var BroadcastStatus;
(function (BroadcastStatus) {
    BroadcastStatus["DRAFT"] = "DRAFT";
    BroadcastStatus["RUNNING"] = "RUNNING";
    BroadcastStatus["PAUSED"] = "PAUSED";
    BroadcastStatus["DONE"] = "DONE";
    BroadcastStatus["FAILED"] = "FAILED";
})(BroadcastStatus || (BroadcastStatus = {}));
