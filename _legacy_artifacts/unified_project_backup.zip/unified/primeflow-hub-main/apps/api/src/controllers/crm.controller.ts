import { Request, Response } from 'express';
import { prisma } from '../lib/prisma.js';
import { logger } from '../lib/logger.js';
import { AuthRequest } from '../middleware/auth.js';

/**
 * GET /api/crm/deals
 * Lista todos os deals
 */
export async function getDeals(req: AuthRequest, res: Response) {
  try {
    const userId = req.user?.id;
    const { stage, search, page = '1', limit = '50' } = req.query;

    const where: any = userId ? { userId } : {};
    
    if (stage) {
      where.stage = stage;
    }
    
    if (search) {
      where.OR = [
        { title: { contains: search as string, mode: 'insensitive' } },
        { contact: { name: { contains: search as string, mode: 'insensitive' } } }
      ];
    }

    const skip = (parseInt(page as string) - 1) * parseInt(limit as string);

    const [deals, total] = await Promise.all([
      prisma.deal.findMany({
        where,
        include: {
          contact: {
            select: {
              id: true,
              name: true,
              email: true,
              phone: true,
              avatar: true
            }
          },
          assignedTo: {
            select: {
              id: true,
              name: true,
              email: true,
              avatar: true
            }
          }
        },
        orderBy: { updatedAt: 'desc' },
        skip,
        take: parseInt(limit as string)
      }),
      prisma.deal.count({ where })
    ]);

    res.json({
      deals,
      pagination: {
        page: parseInt(page as string),
        limit: parseInt(limit as string),
        total,
        pages: Math.ceil(total / parseInt(limit as string))
      }
    });
  } catch (error) {
    logger.error({ error }, 'Error fetching deals');
    res.status(500).json({ error: 'Erro ao buscar deals' });
  }
}

/**
 * POST /api/crm/deals
 * Cria um novo deal
 */
export async function createDeal(req: AuthRequest, res: Response) {
  try {
    const userId = req.user?.id;
    const { title, contactId, value, stage, expectedCloseDate, notes } = req.body;

    if (!title || !contactId) {
      return res.status(400).json({ error: 'Título e contato são obrigatórios' });
    }

    const deal = await prisma.deal.create({
      data: {
        title,
        contactId,
        value: value || 0,
        stage: stage || 'LEAD',
        expectedCloseDate: expectedCloseDate ? new Date(expectedCloseDate) : null,
        notes,
        userId: userId!,
        assignedToId: userId
      },
      include: {
        contact: {
          select: {
            id: true,
            name: true,
            email: true,
            phone: true
          }
        }
      }
    });

    // Registrar atividade
    await prisma.activity.create({
      data: {
        type: 'DEAL_CREATED',
        description: `Deal "${title}" criado`,
        userId: userId!,
        metadata: { dealId: deal.id }
      }
    });

    logger.info({ dealId: deal.id }, 'Deal created');
    res.status(201).json(deal);
  } catch (error) {
    logger.error({ error }, 'Error creating deal');
    res.status(500).json({ error: 'Erro ao criar deal' });
  }
}

/**
 * PUT /api/crm/deals/:id
 * Atualiza um deal
 */
export async function updateDeal(req: AuthRequest, res: Response) {
  try {
    const { id } = req.params;
    const userId = req.user?.id;
    const { title, value, stage, expectedCloseDate, notes, assignedToId } = req.body;

    // Verificar se o deal existe e pertence ao usuário
    const existingDeal = await prisma.deal.findFirst({
      where: {
        id,
        ...(userId ? { userId } : {})
      }
    });

    if (!existingDeal) {
      return res.status(404).json({ error: 'Deal não encontrado' });
    }

    const deal = await prisma.deal.update({
      where: { id },
      data: {
        ...(title && { title }),
        ...(value !== undefined && { value }),
        ...(stage && { stage }),
        ...(expectedCloseDate && { expectedCloseDate: new Date(expectedCloseDate) }),
        ...(notes !== undefined && { notes }),
        ...(assignedToId && { assignedToId })
      },
      include: {
        contact: true,
        assignedTo: {
          select: {
            id: true,
            name: true,
            email: true
          }
        }
      }
    });

    // Registrar atividade se mudou de estágio
    if (stage && stage !== existingDeal.stage) {
      await prisma.activity.create({
        data: {
          type: 'DEAL_STAGE_CHANGED',
          description: `Deal "${deal.title}" movido de ${existingDeal.stage} para ${stage}`,
          userId: userId!,
          metadata: { dealId: deal.id, oldStage: existingDeal.stage, newStage: stage }
        }
      });
    }

    logger.info({ dealId: deal.id }, 'Deal updated');
    res.json(deal);
  } catch (error) {
    logger.error({ error }, 'Error updating deal');
    res.status(500).json({ error: 'Erro ao atualizar deal' });
  }
}

/**
 * PUT /api/crm/deals/:id/stage
 * Move deal para outro estágio
 */
export async function updateDealStage(req: AuthRequest, res: Response) {
  try {
    const { id } = req.params;
    const { stage } = req.body;
    const userId = req.user?.id;

    if (!stage) {
      return res.status(400).json({ error: 'Estágio é obrigatório' });
    }

    const validStages = ['LEAD', 'QUALIFIED', 'PROPOSAL', 'NEGOTIATION', 'CLOSED_WON', 'CLOSED_LOST'];
    if (!validStages.includes(stage)) {
      return res.status(400).json({ error: 'Estágio inválido' });
    }

    const existingDeal = await prisma.deal.findFirst({
      where: {
        id,
        ...(userId ? { userId } : {})
      }
    });

    if (!existingDeal) {
      return res.status(404).json({ error: 'Deal não encontrado' });
    }

    const deal = await prisma.deal.update({
      where: { id },
      data: {
        stage,
        ...(stage === 'CLOSED_WON' && { closedAt: new Date() }),
        ...(stage === 'CLOSED_LOST' && { closedAt: new Date() })
      },
      include: {
        contact: true,
        assignedTo: {
          select: {
            id: true,
            name: true,
            email: true
          }
        }
      }
    });

    // Registrar atividade
    await prisma.activity.create({
      data: {
        type: 'DEAL_STAGE_CHANGED',
        description: `Deal "${deal.title}" movido para ${stage}`,
        userId: userId!,
        metadata: { dealId: deal.id, oldStage: existingDeal.stage, newStage: stage }
      }
    });

    logger.info({ dealId: deal.id, stage }, 'Deal stage updated');
    res.json(deal);
  } catch (error) {
    logger.error({ error }, 'Error updating deal stage');
    res.status(500).json({ error: 'Erro ao atualizar estágio' });
  }
}

/**
 * DELETE /api/crm/deals/:id
 * Deleta um deal
 */
export async function deleteDeal(req: AuthRequest, res: Response) {
  try {
    const { id } = req.params;
    const userId = req.user?.id;

    const deal = await prisma.deal.findFirst({
      where: {
        id,
        ...(userId ? { userId } : {})
      }
    });

    if (!deal) {
      return res.status(404).json({ error: 'Deal não encontrado' });
    }

    await prisma.deal.delete({
      where: { id }
    });

    // Registrar atividade
    await prisma.activity.create({
      data: {
        type: 'DEAL_DELETED',
        description: `Deal "${deal.title}" deletado`,
        userId: userId!,
        metadata: { dealId: id }
      }
    });

    logger.info({ dealId: id }, 'Deal deleted');
    res.json({ message: 'Deal deletado com sucesso' });
  } catch (error) {
    logger.error({ error }, 'Error deleting deal');
    res.status(500).json({ error: 'Erro ao deletar deal' });
  }
}

/**
 * GET /api/crm/pipeline
 * Retorna visão do pipeline
 */
export async function getPipeline(req: AuthRequest, res: Response) {
  try {
    const userId = req.user?.id;

    const deals = await prisma.deal.findMany({
      where: {
        ...(userId ? { userId } : {}),
        stage: {
          notIn: ['CLOSED_WON', 'CLOSED_LOST']
        }
      },
      include: {
        contact: {
          select: {
            id: true,
            name: true,
            email: true,
            avatar: true
          }
        },
        assignedTo: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        }
      },
      orderBy: { updatedAt: 'desc' }
    });

    // Agrupar por estágio
    const pipeline = {
      LEAD: deals.filter(d => d.stage === 'LEAD'),
      QUALIFIED: deals.filter(d => d.stage === 'QUALIFIED'),
      PROPOSAL: deals.filter(d => d.stage === 'PROPOSAL'),
      NEGOTIATION: deals.filter(d => d.stage === 'NEGOTIATION')
    };

    res.json(pipeline);
  } catch (error) {
    logger.error({ error }, 'Error fetching pipeline');
    res.status(500).json({ error: 'Erro ao buscar pipeline' });
  }
}

