export var ConnectionType;
(function (ConnectionType) {
    ConnectionType["WHATSAPP"] = "WHATSAPP";
    ConnectionType["FACEBOOK"] = "FACEBOOK";
    ConnectionType["INSTAGRAM"] = "INSTAGRAM";
})(ConnectionType || (ConnectionType = {}));
export var MessageDirection;
(function (MessageDirection) {
    MessageDirection["IN"] = "IN";
    MessageDirection["OUT"] = "OUT";
})(MessageDirection || (MessageDirection = {}));
