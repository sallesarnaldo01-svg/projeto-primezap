/**
 * Facebook Messenger Provider Service
 * Primeflow-Hub - Patch 3
 * 
 * Integração completa com Facebook Messenger API
 */

import axios, { AxiosInstance } from 'axios';
import { prisma } from '../lib/prisma.js';

export interface FacebookConfig {
  pageId: string;
  pageAccessToken: string;
  appSecret: string;
  tenantId: string;
}

export interface FacebookMessage {
  recipientId: string;
  text?: string;
  attachment?: {
    type: 'image' | 'video' | 'audio' | 'file';
    url: string;
  };
}

export class FacebookProvider {
  private client: AxiosInstance;
  private config: FacebookConfig;
  private readonly API_VERSION = 'v18.0';

  constructor(config: FacebookConfig) {
    this.config = config;
    this.client = axios.create({
      baseURL: `https://graph.facebook.com/${this.API_VERSION}`,
      params: {
        access_token: config.pageAccessToken,
      },
      timeout: 30000,
    });
  }

  /**
   * Enviar mensagem de texto
   */
  async sendTextMessage(recipientId: string, text: string): Promise<{
    success: boolean;
    messageId?: string;
  }> {
    try {
      const response = await this.client.post('/me/messages', {
        recipient: { id: recipientId },
        message: { text },
      });

      // Salvar mensagem no banco
      await this.saveMessage({
        recipientId,
        text,
        messageId: response.data.message_id,
        status: 'sent',
      });

      return {
        success: true,
        messageId: response.data.message_id,
      };
    } catch (error) {
      console.error('Error sending Facebook message:', error);
      
      await this.saveMessage({
        recipientId,
        text,
        status: 'failed',
        error: error.message,
      });

      throw new Error(`Erro ao enviar mensagem: ${error.response?.data?.error?.message || error.message}`);
    }
  }

  /**
   * Enviar mensagem com anexo
   */
  async sendAttachment(message: FacebookMessage): Promise<{
    success: boolean;
    messageId?: string;
  }> {
    try {
      const response = await this.client.post('/me/messages', {
        recipient: { id: message.recipientId },
        message: {
          attachment: {
            type: message.attachment.type,
            payload: {
              url: message.attachment.url,
              is_reusable: true,
            },
          },
        },
      });

      await this.saveMessage({
        recipientId: message.recipientId,
        text: message.text,
        mediaUrl: message.attachment.url,
        messageId: response.data.message_id,
        status: 'sent',
      });

      return {
        success: true,
        messageId: response.data.message_id,
      };
    } catch (error) {
      console.error('Error sending Facebook attachment:', error);
      throw new Error(`Erro ao enviar anexo: ${error.response?.data?.error?.message || error.message}`);
    }
  }

  /**
   * Marcar mensagem como lida
   */
  async markAsRead(senderId: string): Promise<boolean> {
    try {
      await this.client.post('/me/messages', {
        recipient: { id: senderId },
        sender_action: 'mark_seen',
      });

      return true;
    } catch (error) {
      console.error('Error marking as read:', error);
      return false;
    }
  }

  /**
   * Enviar indicador de digitação
   */
  async sendTypingIndicator(recipientId: string, typing: boolean = true): Promise<boolean> {
    try {
      await this.client.post('/me/messages', {
        recipient: { id: recipientId },
        sender_action: typing ? 'typing_on' : 'typing_off',
      });

      return true;
    } catch (error) {
      console.error('Error sending typing indicator:', error);
      return false;
    }
  }

  /**
   * Buscar informações do perfil do usuário
   */
  async getUserProfile(userId: string): Promise<{
    id: string;
    name: string;
    profilePic?: string;
  }> {
    try {
      const response = await this.client.get(`/${userId}`, {
        params: {
          fields: 'id,name,profile_pic',
        },
      });

      return {
        id: response.data.id,
        name: response.data.name,
        profilePic: response.data.profile_pic,
      };
    } catch (error) {
      console.error('Error getting user profile:', error);
      throw new Error(`Erro ao buscar perfil: ${error.message}`);
    }
  }

  /**
   * Configurar webhook
   */
  async setupWebhook(webhookUrl: string, verifyToken: string): Promise<{
    success: boolean;
    instructions: string;
  }> {
    try {
      // Salvar configuração no banco
      await prisma.integration.upsert({
        where: {
          tenantId_provider: {
            tenantId: this.config.tenantId,
            provider: 'facebook',
          },
        },
        update: {
          webhookUrl,
          webhookEnabled: true,
          config: {
            pageId: this.config.pageId,
            verifyToken,
          },
        },
        create: {
          tenantId: this.config.tenantId,
          provider: 'facebook',
          webhookUrl,
          webhookEnabled: true,
          status: 'connected',
          config: {
            pageId: this.config.pageId,
            verifyToken,
          },
        },
      });

      return {
        success: true,
        instructions: `
1. Acesse https://developers.facebook.com/apps
2. Selecione seu app
3. Vá em Messenger > Settings
4. Em Webhooks, clique em "Add Callback URL"
5. Cole a URL: ${webhookUrl}
6. Cole o Verify Token: ${verifyToken}
7. Selecione os eventos: messages, messaging_postbacks, messaging_optins
8. Clique em "Verify and Save"
        `.trim(),
      };
    } catch (error) {
      console.error('Error setting up webhook:', error);
      throw new Error(`Erro ao configurar webhook: ${error.message}`);
    }
  }

  /**
   * Verificar webhook (usado pelo Facebook)
   */
  static verifyWebhook(
    mode: string,
    token: string,
    challenge: string,
    expectedToken: string
  ): string | null {
    if (mode === 'subscribe' && token === expectedToken) {
      return challenge;
    }
    return null;
  }

  /**
   * Processar webhook recebido
   */
  static async processWebhook(tenantId: string, body: any): Promise<void> {
    try {
      if (body.object !== 'page') {
        console.log('Not a page webhook');
        return;
      }

      for (const entry of body.entry) {
        for (const event of entry.messaging) {
          if (event.message) {
            await this.handleIncomingMessage(tenantId, event);
          } else if (event.postback) {
            await this.handlePostback(tenantId, event);
          } else if (event.delivery) {
            await this.handleDelivery(tenantId, event);
          } else if (event.read) {
            await this.handleRead(tenantId, event);
          }
        }
      }
    } catch (error) {
      console.error('Error processing Facebook webhook:', error);
    }
  }

  /**
   * Processar mensagem recebida
   */
  private static async handleIncomingMessage(
    tenantId: string,
    event: any
  ): Promise<void> {
    try {
      const senderId = event.sender.id;
      const message = event.message;
      const text = message.text || '';
      const attachments = message.attachments || [];

      // Buscar informações do usuário
      const integration = await prisma.integration.findFirst({
        where: {
          tenantId,
          provider: 'facebook',
        },
      });

      if (!integration) {
        console.error('Facebook integration not found');
        return;
      }

      const provider = new FacebookProvider({
        pageId: integration.config.pageId,
        pageAccessToken: integration.accessToken,
        appSecret: integration.appSecret,
        tenantId,
      });

      const userProfile = await provider.getUserProfile(senderId);

      // Buscar ou criar contato
      const contact = await prisma.contact.upsert({
        where: {
          tenantId_externalId: {
            tenantId,
            externalId: senderId,
          },
        },
        update: {
          name: userProfile.name,
        },
        create: {
          tenantId,
          externalId: senderId,
          name: userProfile.name,
          phone: senderId, // Usar ID como telefone temporário
          origem: 'facebook',
        },
      });

      // Buscar ou criar conversa
      const conversation = await prisma.conversation.upsert({
        where: {
          tenantId_contactId_provider: {
            tenantId,
            contactId: contact.id,
            provider: 'facebook',
          },
        },
        update: {
          lastMessageAt: new Date(),
          unreadCount: { increment: 1 },
        },
        create: {
          tenantId,
          contactId: contact.id,
          provider: 'facebook',
          status: 'open',
          lastMessageAt: new Date(),
          unreadCount: 1,
        },
      });

      // Salvar mensagem
      const mediaUrl = attachments[0]?.payload?.url;
      await prisma.message.create({
        data: {
          conversationId: conversation.id,
          externalId: message.mid,
          direction: 'inbound',
          content: text,
          mediaUrl,
          status: 'received',
          receivedAt: new Date(event.timestamp),
        },
      });

      // TODO: Enfileirar para processamento de IA
      console.log('Facebook message saved, ready for AI processing');
    } catch (error) {
      console.error('Error handling Facebook incoming message:', error);
    }
  }

  /**
   * Processar postback (botões)
   */
  private static async handlePostback(
    tenantId: string,
    event: any
  ): Promise<void> {
    try {
      const senderId = event.sender.id;
      const payload = event.postback.payload;

      console.log('Postback received:', { senderId, payload });
      
      // TODO: Processar ação do botão
    } catch (error) {
      console.error('Error handling postback:', error);
    }
  }

  /**
   * Processar confirmação de entrega
   */
  private static async handleDelivery(
    tenantId: string,
    event: any
  ): Promise<void> {
    try {
      const messageIds = event.delivery.mids || [];

      await prisma.message.updateMany({
        where: {
          externalId: { in: messageIds },
        },
        data: {
          status: 'delivered',
        },
      });
    } catch (error) {
      console.error('Error handling delivery:', error);
    }
  }

  /**
   * Processar confirmação de leitura
   */
  private static async handleRead(
    tenantId: string,
    event: any
  ): Promise<void> {
    try {
      // Marcar mensagens como lidas até o watermark
      const watermark = event.read.watermark;
      
      await prisma.message.updateMany({
        where: {
          conversation: {
            tenantId,
            provider: 'facebook',
          },
          sentAt: {
            lte: new Date(watermark),
          },
          direction: 'outbound',
        },
        data: {
          status: 'read',
        },
      });
    } catch (error) {
      console.error('Error handling read:', error);
    }
  }

  /**
   * Salvar mensagem no banco de dados
   */
  private async saveMessage(data: {
    recipientId: string;
    text?: string;
    mediaUrl?: string;
    messageId?: string;
    status: string;
    error?: string;
  }): Promise<void> {
    try {
      // Buscar contato pelo externalId
      const contact = await prisma.contact.findFirst({
        where: {
          tenantId: this.config.tenantId,
          externalId: data.recipientId,
        },
      });

      if (!contact) {
        console.warn('Contact not found for recipient:', data.recipientId);
        return;
      }

      // Buscar conversa
      const conversation = await prisma.conversation.findFirst({
        where: {
          tenantId: this.config.tenantId,
          contactId: contact.id,
          provider: 'facebook',
        },
      });

      if (!conversation) {
        console.warn('Conversation not found');
        return;
      }

      // Salvar mensagem
      await prisma.message.create({
        data: {
          conversationId: conversation.id,
          externalId: data.messageId,
          direction: 'outbound',
          content: data.text || '',
          mediaUrl: data.mediaUrl,
          status: data.status,
          error: data.error,
          sentAt: new Date(),
        },
      });
    } catch (error) {
      console.error('Error saving Facebook message to database:', error);
    }
  }
}

