/**
 * Instagram Direct Provider Service
 * Primeflow-Hub - Patch 3
 * 
 * Integração com Instagram Direct (usa Facebook Graph API)
 */

import { FacebookProvider, FacebookConfig, FacebookMessage } from './facebook.provider.js';
import { prisma } from '../lib/prisma.js';

export interface InstagramConfig extends FacebookConfig {
  instagramAccountId: string;
}

/**
 * Instagram Provider
 * Herda do FacebookProvider pois usa a mesma API
 */
export class InstagramProvider extends FacebookProvider {
  private instagramAccountId: string;

  constructor(config: InstagramConfig) {
    super(config);
    this.instagramAccountId = config.instagramAccountId;
  }

  /**
   * Processar webhook do Instagram
   * Similar ao Facebook mas com algumas diferenças
   */
  static async processWebhook(tenantId: string, body: any): Promise<void> {
    try {
      if (body.object !== 'instagram') {
        console.log('Not an Instagram webhook');
        return;
      }

      for (const entry of body.entry) {
        for (const event of entry.messaging) {
          if (event.message) {
            await this.handleIncomingMessage(tenantId, event);
          } else if (event.postback) {
            await this.handlePostback(tenantId, event);
          }
        }
      }
    } catch (error) {
      console.error('Error processing Instagram webhook:', error);
    }
  }

  /**
   * Processar mensagem recebida do Instagram
   */
  private static async handleIncomingMessage(
    tenantId: string,
    event: any
  ): Promise<void> {
    try {
      const senderId = event.sender.id;
      const message = event.message;
      const text = message.text || '';
      const attachments = message.attachments || [];

      // Buscar integração
      const integration = await prisma.integration.findFirst({
        where: {
          tenantId,
          provider: 'instagram',
        },
      });

      if (!integration) {
        console.error('Instagram integration not found');
        return;
      }

      // Buscar ou criar contato
      const contact = await prisma.contact.upsert({
        where: {
          tenantId_externalId: {
            tenantId,
            externalId: senderId,
          },
        },
        update: {},
        create: {
          tenantId,
          externalId: senderId,
          name: senderId, // Nome temporário
          phone: senderId,
          origem: 'instagram',
        },
      });

      // Buscar ou criar conversa
      const conversation = await prisma.conversation.upsert({
        where: {
          tenantId_contactId_provider: {
            tenantId,
            contactId: contact.id,
            provider: 'instagram',
          },
        },
        update: {
          lastMessageAt: new Date(),
          unreadCount: { increment: 1 },
        },
        create: {
          tenantId,
          contactId: contact.id,
          provider: 'instagram',
          status: 'open',
          lastMessageAt: new Date(),
          unreadCount: 1,
        },
      });

      // Salvar mensagem
      const mediaUrl = attachments[0]?.payload?.url;
      await prisma.message.create({
        data: {
          conversationId: conversation.id,
          externalId: message.mid,
          direction: 'inbound',
          content: text,
          mediaUrl,
          status: 'received',
          receivedAt: new Date(event.timestamp),
        },
      });

      console.log('Instagram message saved, ready for AI processing');
    } catch (error) {
      console.error('Error handling Instagram incoming message:', error);
    }
  }

  /**
   * Processar postback do Instagram
   */
  private static async handlePostback(
    tenantId: string,
    event: any
  ): Promise<void> {
    try {
      const senderId = event.sender.id;
      const payload = event.postback.payload;

      console.log('Instagram postback received:', { senderId, payload });
      
      // TODO: Processar ação do botão
    } catch (error) {
      console.error('Error handling Instagram postback:', error);
    }
  }
}

