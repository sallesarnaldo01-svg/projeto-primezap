/**
 * WhatsApp Provider Service
 * Primeflow-Hub - Patch 3
 * 
 * Integração completa com WhatsApp Business API (Evolution API)
 */

import axios, { AxiosInstance } from 'axios';
import { prisma } from '../lib/prisma.js';
import QRCode from 'qrcode';

export interface WhatsAppConfig {
  instanceName: string;
  apiUrl: string;
  apiKey: string;
  tenantId: string;
}

export interface WhatsAppMessage {
  to: string;
  text?: string;
  mediaUrl?: string;
  mediaType?: 'image' | 'video' | 'audio' | 'document';
  caption?: string;
}

export class WhatsAppProvider {
  private client: AxiosInstance;
  private config: WhatsAppConfig;

  constructor(config: WhatsAppConfig) {
    this.config = config;
    this.client = axios.create({
      baseURL: config.apiUrl,
      headers: {
        'apikey': config.apiKey,
        'Content-Type': 'application/json',
      },
      timeout: 30000,
    });
  }

  /**
   * Criar nova instância do WhatsApp
   */
  async createInstance(): Promise<{ qrcode: string; status: string }> {
    try {
      const response = await this.client.post('/instance/create', {
        instanceName: this.config.instanceName,
        qrcode: true,
        integration: 'WHATSAPP-BAILEYS',
      });

      // Salvar instância no banco
      await prisma.integration.upsert({
        where: {
          tenantId_provider: {
            tenantId: this.config.tenantId,
            provider: 'whatsapp',
          },
        },
        update: {
          instanceName: this.config.instanceName,
          status: 'pending',
          config: {
            apiUrl: this.config.apiUrl,
          },
        },
        create: {
          tenantId: this.config.tenantId,
          provider: 'whatsapp',
          instanceName: this.config.instanceName,
          status: 'pending',
          config: {
            apiUrl: this.config.apiUrl,
          },
        },
      });

      return {
        qrcode: response.data.qrcode?.base64 || '',
        status: response.data.instance?.state || 'pending',
      };
    } catch (error) {
      console.error('Error creating WhatsApp instance:', error);
      throw new Error(`Erro ao criar instância: ${error.message}`);
    }
  }

  /**
   * Buscar QR Code da instância
   */
  async getQRCode(): Promise<string> {
    try {
      const response = await this.client.get(
        `/instance/connect/${this.config.instanceName}`
      );

      if (response.data.base64) {
        return response.data.base64;
      }

      // Se não tiver QR code, gerar um placeholder
      const placeholderQR = await QRCode.toDataURL('Aguardando conexão...');
      return placeholderQR;
    } catch (error) {
      console.error('Error getting QR code:', error);
      throw new Error(`Erro ao buscar QR code: ${error.message}`);
    }
  }

  /**
   * Verificar status da conexão
   */
  async getConnectionStatus(): Promise<{
    state: string;
    connected: boolean;
    phone?: string;
  }> {
    try {
      const response = await this.client.get(
        `/instance/connectionState/${this.config.instanceName}`
      );

      const state = response.data.state || 'disconnected';
      const connected = state === 'open';

      // Atualizar status no banco
      await prisma.integration.updateMany({
        where: {
          tenantId: this.config.tenantId,
          provider: 'whatsapp',
          instanceName: this.config.instanceName,
        },
        data: {
          status: connected ? 'connected' : 'disconnected',
          lastSyncAt: new Date(),
        },
      });

      return {
        state,
        connected,
        phone: response.data.instance?.owner || undefined,
      };
    } catch (error) {
      console.error('Error getting connection status:', error);
      return {
        state: 'error',
        connected: false,
      };
    }
  }

  /**
   * Enviar mensagem de texto
   */
  async sendTextMessage(to: string, text: string): Promise<{
    success: boolean;
    messageId?: string;
  }> {
    try {
      // Formatar número (remover caracteres especiais)
      const formattedNumber = to.replace(/\D/g, '');
      const number = formattedNumber.includes('@')
        ? formattedNumber
        : `${formattedNumber}@s.whatsapp.net`;

      const response = await this.client.post(
        `/message/sendText/${this.config.instanceName}`,
        {
          number,
          text,
        }
      );

      // Salvar mensagem no banco
      await this.saveMessage({
        to: formattedNumber,
        text,
        messageId: response.data.key?.id,
        status: 'sent',
      });

      return {
        success: true,
        messageId: response.data.key?.id,
      };
    } catch (error) {
      console.error('Error sending text message:', error);
      
      // Salvar mensagem com erro
      await this.saveMessage({
        to,
        text,
        status: 'failed',
        error: error.message,
      });

      throw new Error(`Erro ao enviar mensagem: ${error.message}`);
    }
  }

  /**
   * Enviar mensagem com mídia
   */
  async sendMediaMessage(message: WhatsAppMessage): Promise<{
    success: boolean;
    messageId?: string;
  }> {
    try {
      const formattedNumber = message.to.replace(/\D/g, '');
      const number = formattedNumber.includes('@')
        ? formattedNumber
        : `${formattedNumber}@s.whatsapp.net`;

      const response = await this.client.post(
        `/message/sendMedia/${this.config.instanceName}`,
        {
          number,
          mediatype: message.mediaType || 'image',
          media: message.mediaUrl,
          caption: message.caption || message.text,
        }
      );

      await this.saveMessage({
        to: formattedNumber,
        text: message.caption || message.text,
        mediaUrl: message.mediaUrl,
        messageId: response.data.key?.id,
        status: 'sent',
      });

      return {
        success: true,
        messageId: response.data.key?.id,
      };
    } catch (error) {
      console.error('Error sending media message:', error);
      throw new Error(`Erro ao enviar mídia: ${error.message}`);
    }
  }

  /**
   * Buscar mensagens recebidas
   */
  async fetchMessages(limit: number = 50): Promise<any[]> {
    try {
      const response = await this.client.get(
        `/message/list/${this.config.instanceName}`,
        {
          params: { limit },
        }
      );

      return response.data.messages || [];
    } catch (error) {
      console.error('Error fetching messages:', error);
      return [];
    }
  }

  /**
   * Configurar webhook para receber mensagens
   */
  async setupWebhook(webhookUrl: string): Promise<boolean> {
    try {
      await this.client.post(
        `/webhook/set/${this.config.instanceName}`,
        {
          url: webhookUrl,
          webhook_by_events: true,
          webhook_base64: false,
          events: [
            'MESSAGES_UPSERT',
            'MESSAGES_UPDATE',
            'SEND_MESSAGE',
            'CONNECTION_UPDATE',
          ],
        }
      );

      // Salvar webhook no banco
      await prisma.integration.updateMany({
        where: {
          tenantId: this.config.tenantId,
          provider: 'whatsapp',
        },
        data: {
          webhookUrl,
          webhookEnabled: true,
        },
      });

      return true;
    } catch (error) {
      console.error('Error setting up webhook:', error);
      throw new Error(`Erro ao configurar webhook: ${error.message}`);
    }
  }

  /**
   * Desconectar instância
   */
  async disconnect(): Promise<boolean> {
    try {
      await this.client.delete(
        `/instance/logout/${this.config.instanceName}`
      );

      await prisma.integration.updateMany({
        where: {
          tenantId: this.config.tenantId,
          provider: 'whatsapp',
        },
        data: {
          status: 'disconnected',
        },
      });

      return true;
    } catch (error) {
      console.error('Error disconnecting:', error);
      return false;
    }
  }

  /**
   * Deletar instância
   */
  async deleteInstance(): Promise<boolean> {
    try {
      await this.client.delete(
        `/instance/delete/${this.config.instanceName}`
      );

      await prisma.integration.deleteMany({
        where: {
          tenantId: this.config.tenantId,
          provider: 'whatsapp',
          instanceName: this.config.instanceName,
        },
      });

      return true;
    } catch (error) {
      console.error('Error deleting instance:', error);
      return false;
    }
  }

  /**
   * Salvar mensagem no banco de dados
   */
  private async saveMessage(data: {
    to: string;
    text?: string;
    mediaUrl?: string;
    messageId?: string;
    status: string;
    error?: string;
  }): Promise<void> {
    try {
      // Buscar ou criar contato
      const contact = await prisma.contact.upsert({
        where: {
          tenantId_phone: {
            tenantId: this.config.tenantId,
            phone: data.to,
          },
        },
        update: {},
        create: {
          tenantId: this.config.tenantId,
          phone: data.to,
          name: data.to, // Nome temporário
          origem: 'whatsapp',
        },
      });

      // Buscar ou criar conversa
      const conversation = await prisma.conversation.upsert({
        where: {
          tenantId_contactId_provider: {
            tenantId: this.config.tenantId,
            contactId: contact.id,
            provider: 'whatsapp',
          },
        },
        update: {
          lastMessageAt: new Date(),
        },
        create: {
          tenantId: this.config.tenantId,
          contactId: contact.id,
          provider: 'whatsapp',
          status: 'open',
          lastMessageAt: new Date(),
        },
      });

      // Salvar mensagem
      await prisma.message.create({
        data: {
          conversationId: conversation.id,
          externalId: data.messageId,
          direction: 'outbound',
          content: data.text || '',
          mediaUrl: data.mediaUrl,
          status: data.status,
          error: data.error,
          sentAt: new Date(),
        },
      });
    } catch (error) {
      console.error('Error saving message to database:', error);
      // Não lançar erro para não bloquear envio
    }
  }

  /**
   * Processar webhook recebido
   */
  static async processWebhook(
    tenantId: string,
    instanceName: string,
    event: any
  ): Promise<void> {
    try {
      const eventType = event.event;

      switch (eventType) {
        case 'MESSAGES_UPSERT':
          await this.handleIncomingMessage(tenantId, event.data);
          break;

        case 'CONNECTION_UPDATE':
          await this.handleConnectionUpdate(tenantId, instanceName, event.data);
          break;

        case 'MESSAGES_UPDATE':
          await this.handleMessageUpdate(tenantId, event.data);
          break;

        default:
          console.log('Unhandled webhook event:', eventType);
      }
    } catch (error) {
      console.error('Error processing webhook:', error);
    }
  }

  /**
   * Processar mensagem recebida
   */
  private static async handleIncomingMessage(
    tenantId: string,
    data: any
  ): Promise<void> {
    try {
      const message = data.messages?.[0];
      if (!message || message.key?.fromMe) return; // Ignorar mensagens próprias

      const phone = message.key?.remoteJid?.replace('@s.whatsapp.net', '');
      const content = message.message?.conversation || 
                     message.message?.extendedTextMessage?.text || '';

      // Buscar ou criar contato
      const contact = await prisma.contact.upsert({
        where: {
          tenantId_phone: {
            tenantId,
            phone,
          },
        },
        update: {},
        create: {
          tenantId,
          phone,
          name: message.pushName || phone,
          origem: 'whatsapp',
        },
      });

      // Buscar ou criar conversa
      const conversation = await prisma.conversation.upsert({
        where: {
          tenantId_contactId_provider: {
            tenantId,
            contactId: contact.id,
            provider: 'whatsapp',
          },
        },
        update: {
          lastMessageAt: new Date(),
          unreadCount: { increment: 1 },
        },
        create: {
          tenantId,
          contactId: contact.id,
          provider: 'whatsapp',
          status: 'open',
          lastMessageAt: new Date(),
          unreadCount: 1,
        },
      });

      // Salvar mensagem
      await prisma.message.create({
        data: {
          conversationId: conversation.id,
          externalId: message.key?.id,
          direction: 'inbound',
          content,
          status: 'received',
          receivedAt: new Date(message.messageTimestamp * 1000),
        },
      });

      // TODO: Enfileirar para processamento de IA
      console.log('Message saved, ready for AI processing');
    } catch (error) {
      console.error('Error handling incoming message:', error);
    }
  }

  /**
   * Processar atualização de conexão
   */
  private static async handleConnectionUpdate(
    tenantId: string,
    instanceName: string,
    data: any
  ): Promise<void> {
    try {
      const state = data.state || 'disconnected';
      const connected = state === 'open';

      await prisma.integration.updateMany({
        where: {
          tenantId,
          provider: 'whatsapp',
          instanceName,
        },
        data: {
          status: connected ? 'connected' : 'disconnected',
          lastSyncAt: new Date(),
        },
      });
    } catch (error) {
      console.error('Error handling connection update:', error);
    }
  }

  /**
   * Processar atualização de mensagem (lida, entregue, etc)
   */
  private static async handleMessageUpdate(
    tenantId: string,
    data: any
  ): Promise<void> {
    try {
      const update = data.update;
      const messageId = update?.key?.id;
      const status = update?.status;

      if (messageId && status) {
        await prisma.message.updateMany({
          where: {
            externalId: messageId,
          },
          data: {
            status: status === 3 ? 'read' : status === 2 ? 'delivered' : 'sent',
          },
        });
      }
    } catch (error) {
      console.error('Error handling message update:', error);
    }
  }
}

