/**
 * Webhooks Controller
 * Primeflow-Hub - Patch 3
 * 
 * Controller centralizado para receber webhooks de todos os providers
 */

import { Request, Response } from 'express';
import crypto from 'crypto';
import { WhatsAppProvider } from '../services/whatsapp.provider.js';
import { FacebookProvider } from '../services/facebook.provider.js';
import { InstagramProvider } from '../services/instagram.provider.js';
import { prisma } from '../lib/prisma.js';

export const webhooksController = {
  /**
   * POST /webhooks/whatsapp/:tenantId
   * Receber webhooks do WhatsApp (Evolution API)
   */
  async whatsapp(req: Request, res: Response) {
    try {
      const { tenantId } = req.params;
      const event = req.body;

      console.log('WhatsApp webhook received:', {
        tenantId,
        event: event.event,
      });

      // Buscar integração
      const integration = await prisma.integration.findFirst({
        where: {
          tenantId,
          provider: 'whatsapp',
        },
      });

      if (!integration) {
        return res.status(404).json({ error: 'Integration not found' });
      }

      // Processar webhook de forma assíncrona
      WhatsAppProvider.processWebhook(
        tenantId,
        integration.instanceName,
        event
      ).catch(error => {
        console.error('Error processing WhatsApp webhook:', error);
      });

      // Responder imediatamente
      res.status(200).json({ success: true });
    } catch (error) {
      console.error('Error in WhatsApp webhook:', error);
      res.status(500).json({ 
        error: 'Internal server error',
        message: error.message 
      });
    }
  },

  /**
   * GET /webhooks/facebook/:tenantId
   * Verificar webhook do Facebook (challenge)
   */
  async facebookVerify(req: Request, res: Response) {
    try {
      const { tenantId } = req.params;
      const mode = req.query['hub.mode'];
      const token = req.query['hub.verify_token'];
      const challenge = req.query['hub.challenge'];

      console.log('Facebook webhook verification:', {
        tenantId,
        mode,
        token,
      });

      // Buscar integração
      const integration = await prisma.integration.findFirst({
        where: {
          tenantId,
          provider: 'facebook',
        },
      });

      if (!integration) {
        return res.status(404).send('Integration not found');
      }

      const expectedToken = integration.config?.verifyToken || 'primeflow_verify';

      // Verificar token
      const challengeResponse = FacebookProvider.verifyWebhook(
        mode as string,
        token as string,
        challenge as string,
        expectedToken
      );

      if (challengeResponse) {
        console.log('Facebook webhook verified successfully');
        return res.status(200).send(challengeResponse);
      }

      res.status(403).send('Forbidden');
    } catch (error) {
      console.error('Error in Facebook webhook verification:', error);
      res.status(500).send('Internal server error');
    }
  },

  /**
   * POST /webhooks/facebook/:tenantId
   * Receber webhooks do Facebook Messenger
   */
  async facebook(req: Request, res: Response) {
    try {
      const { tenantId } = req.params;
      const body = req.body;

      console.log('Facebook webhook received:', {
        tenantId,
        object: body.object,
      });

      // Verificar assinatura (segurança)
      const signature = req.headers['x-hub-signature-256'] as string;
      if (signature) {
        const integration = await prisma.integration.findFirst({
          where: { tenantId, provider: 'facebook' },
        });

        if (integration?.appSecret) {
          const isValid = this.verifyFacebookSignature(
            req.body,
            signature,
            integration.appSecret
          );

          if (!isValid) {
            console.error('Invalid Facebook signature');
            return res.status(403).json({ error: 'Invalid signature' });
          }
        }
      }

      // Processar webhook de forma assíncrona
      FacebookProvider.processWebhook(tenantId, body).catch(error => {
        console.error('Error processing Facebook webhook:', error);
      });

      // Responder imediatamente
      res.status(200).json({ success: true });
    } catch (error) {
      console.error('Error in Facebook webhook:', error);
      res.status(500).json({ 
        error: 'Internal server error',
        message: error.message 
      });
    }
  },

  /**
   * GET /webhooks/instagram/:tenantId
   * Verificar webhook do Instagram (challenge)
   */
  async instagramVerify(req: Request, res: Response) {
    try {
      const { tenantId } = req.params;
      const mode = req.query['hub.mode'];
      const token = req.query['hub.verify_token'];
      const challenge = req.query['hub.challenge'];

      console.log('Instagram webhook verification:', {
        tenantId,
        mode,
        token,
      });

      // Buscar integração
      const integration = await prisma.integration.findFirst({
        where: {
          tenantId,
          provider: 'instagram',
        },
      });

      if (!integration) {
        return res.status(404).send('Integration not found');
      }

      const expectedToken = integration.config?.verifyToken || 'primeflow_verify';

      // Verificar token (mesmo processo do Facebook)
      const challengeResponse = FacebookProvider.verifyWebhook(
        mode as string,
        token as string,
        challenge as string,
        expectedToken
      );

      if (challengeResponse) {
        console.log('Instagram webhook verified successfully');
        return res.status(200).send(challengeResponse);
      }

      res.status(403).send('Forbidden');
    } catch (error) {
      console.error('Error in Instagram webhook verification:', error);
      res.status(500).send('Internal server error');
    }
  },

  /**
   * POST /webhooks/instagram/:tenantId
   * Receber webhooks do Instagram Direct
   */
  async instagram(req: Request, res: Response) {
    try {
      const { tenantId } = req.params;
      const body = req.body;

      console.log('Instagram webhook received:', {
        tenantId,
        object: body.object,
      });

      // Verificar assinatura
      const signature = req.headers['x-hub-signature-256'] as string;
      if (signature) {
        const integration = await prisma.integration.findFirst({
          where: { tenantId, provider: 'instagram' },
        });

        if (integration?.appSecret) {
          const isValid = this.verifyFacebookSignature(
            req.body,
            signature,
            integration.appSecret
          );

          if (!isValid) {
            console.error('Invalid Instagram signature');
            return res.status(403).json({ error: 'Invalid signature' });
          }
        }
      }

      // Processar webhook de forma assíncrona
      InstagramProvider.processWebhook(tenantId, body).catch(error => {
        console.error('Error processing Instagram webhook:', error);
      });

      // Responder imediatamente
      res.status(200).json({ success: true });
    } catch (error) {
      console.error('Error in Instagram webhook:', error);
      res.status(500).json({ 
        error: 'Internal server error',
        message: error.message 
      });
    }
  },

  /**
   * POST /webhooks/test/:tenantId
   * Endpoint de teste para simular webhooks
   */
  async test(req: Request, res: Response) {
    try {
      const { tenantId } = req.params;
      const { provider, event } = req.body;

      console.log('Test webhook:', { tenantId, provider, event });

      switch (provider) {
        case 'whatsapp':
          await WhatsAppProvider.processWebhook(tenantId, 'test-instance', event);
          break;

        case 'facebook':
          await FacebookProvider.processWebhook(tenantId, event);
          break;

        case 'instagram':
          await InstagramProvider.processWebhook(tenantId, event);
          break;

        default:
          return res.status(400).json({ error: 'Invalid provider' });
      }

      res.json({ success: true, message: 'Test webhook processed' });
    } catch (error) {
      console.error('Error in test webhook:', error);
      res.status(500).json({ 
        error: 'Internal server error',
        message: error.message 
      });
    }
  },

  /**
   * GET /webhooks/status/:tenantId
   * Verificar status de todos os webhooks
   */
  async status(req: Request, res: Response) {
    try {
      const { tenantId } = req.params;

      const integrations = await prisma.integration.findMany({
        where: { tenantId },
        select: {
          provider: true,
          webhookUrl: true,
          webhookEnabled: true,
          status: true,
          lastSyncAt: true,
        },
      });

      const status = integrations.map(integration => ({
        provider: integration.provider,
        webhookUrl: integration.webhookUrl,
        enabled: integration.webhookEnabled,
        status: integration.status,
        lastSync: integration.lastSyncAt,
      }));

      res.json(status);
    } catch (error) {
      console.error('Error getting webhook status:', error);
      res.status(500).json({ 
        error: 'Internal server error',
        message: error.message 
      });
    }
  },

  /**
   * Verificar assinatura do Facebook/Instagram
   */
  verifyFacebookSignature(
    body: any,
    signature: string,
    appSecret: string
  ): boolean {
    try {
      const expectedSignature = crypto
        .createHmac('sha256', appSecret)
        .update(JSON.stringify(body))
        .digest('hex');

      const signatureHash = signature.split('sha256=')[1];

      return crypto.timingSafeEqual(
        Buffer.from(signatureHash, 'hex'),
        Buffer.from(expectedSignature, 'hex')
      );
    } catch (error) {
      console.error('Error verifying signature:', error);
      return false;
    }
  },
};

