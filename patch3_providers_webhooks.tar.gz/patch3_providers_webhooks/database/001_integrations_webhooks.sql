-- ============================================================
-- Patch 3: Providers e Webhooks - Database Migration
-- Primeflow-Hub
-- Versão: 1.0.0
-- Data: 12/10/2025
-- ============================================================

-- Tabela de Integrações
CREATE TABLE IF NOT EXISTS integrations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  provider VARCHAR(50) NOT NULL, -- 'whatsapp', 'facebook', 'instagram'
  status VARCHAR(20) NOT NULL DEFAULT 'disconnected', -- 'connected', 'disconnected', 'error'
  config JSONB NOT NULL DEFAULT '{}',
  credentials JSONB NOT NULL DEFAULT '{}',
  metadata JSONB DEFAULT '{}',
  last_sync_at TIMESTAMP,
  error_message TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
  UNIQUE(tenant_id, provider)
);

-- Índices para integrações
CREATE INDEX IF NOT EXISTS idx_integrations_tenant ON integrations(tenant_id);
CREATE INDEX IF NOT EXISTS idx_integrations_provider ON integrations(provider);
CREATE INDEX IF NOT EXISTS idx_integrations_status ON integrations(status);

-- Tabela de Webhooks Logs
CREATE TABLE IF NOT EXISTS webhook_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  provider VARCHAR(50) NOT NULL,
  event_type VARCHAR(100) NOT NULL,
  payload JSONB NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'pending', -- 'pending', 'processed', 'error'
  error_message TEXT,
  processed_at TIMESTAMP,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Índices para webhook logs
CREATE INDEX IF NOT EXISTS idx_webhook_logs_tenant ON webhook_logs(tenant_id);
CREATE INDEX IF NOT EXISTS idx_webhook_logs_provider ON webhook_logs(provider);
CREATE INDEX IF NOT EXISTS idx_webhook_logs_status ON webhook_logs(status);
CREATE INDEX IF NOT EXISTS idx_webhook_logs_created ON webhook_logs(created_at DESC);

-- Tabela de Mensagens (se não existir)
CREATE TABLE IF NOT EXISTS messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  conversation_id UUID REFERENCES conversations(id) ON DELETE CASCADE,
  contact_id UUID REFERENCES contacts(id) ON DELETE SET NULL,
  provider VARCHAR(50) NOT NULL,
  external_id VARCHAR(255),
  direction VARCHAR(10) NOT NULL, -- 'inbound', 'outbound'
  type VARCHAR(50) NOT NULL DEFAULT 'text', -- 'text', 'image', 'video', 'audio', 'document'
  content TEXT,
  media_url TEXT,
  metadata JSONB DEFAULT '{}',
  status VARCHAR(20) DEFAULT 'sent', -- 'sent', 'delivered', 'read', 'failed'
  read_at TIMESTAMP,
  delivered_at TIMESTAMP,
  sent_at TIMESTAMP,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Índices para mensagens
CREATE INDEX IF NOT EXISTS idx_messages_tenant ON messages(tenant_id);
CREATE INDEX IF NOT EXISTS idx_messages_conversation ON messages(conversation_id);
CREATE INDEX IF NOT EXISTS idx_messages_contact ON messages(contact_id);
CREATE INDEX IF NOT EXISTS idx_messages_provider ON messages(provider);
CREATE INDEX IF NOT EXISTS idx_messages_external ON messages(external_id);
CREATE INDEX IF NOT EXISTS idx_messages_direction ON messages(direction);
CREATE INDEX IF NOT EXISTS idx_messages_created ON messages(created_at DESC);

-- Tabela de Conversas (se não existir)
CREATE TABLE IF NOT EXISTS conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  contact_id UUID REFERENCES contacts(id) ON DELETE SET NULL,
  provider VARCHAR(50) NOT NULL,
  external_id VARCHAR(255),
  status VARCHAR(20) NOT NULL DEFAULT 'open', -- 'open', 'closed', 'archived'
  last_message_at TIMESTAMP,
  last_message_preview TEXT,
  unread_count INTEGER DEFAULT 0,
  assigned_to UUID REFERENCES users(id) ON DELETE SET NULL,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
  UNIQUE(tenant_id, provider, external_id)
);

-- Índices para conversas
CREATE INDEX IF NOT EXISTS idx_conversations_tenant ON conversations(tenant_id);
CREATE INDEX IF NOT EXISTS idx_conversations_contact ON conversations(contact_id);
CREATE INDEX IF NOT EXISTS idx_conversations_provider ON conversations(provider);
CREATE INDEX IF NOT EXISTS idx_conversations_status ON conversations(status);
CREATE INDEX IF NOT EXISTS idx_conversations_assigned ON conversations(assigned_to);
CREATE INDEX IF NOT EXISTS idx_conversations_last_message ON conversations(last_message_at DESC);

-- Função para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers para updated_at
DROP TRIGGER IF EXISTS update_integrations_updated_at ON integrations;
CREATE TRIGGER update_integrations_updated_at
  BEFORE UPDATE ON integrations
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_messages_updated_at ON messages;
CREATE TRIGGER update_messages_updated_at
  BEFORE UPDATE ON messages
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_conversations_updated_at ON conversations;
CREATE TRIGGER update_conversations_updated_at
  BEFORE UPDATE ON conversations
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Adicionar colunas em tabelas existentes (se necessário)
DO $$ 
BEGIN
  -- Adicionar coluna provider em contacts se não existir
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'contacts' AND column_name = 'provider'
  ) THEN
    ALTER TABLE contacts ADD COLUMN provider VARCHAR(50);
    CREATE INDEX idx_contacts_provider ON contacts(provider);
  END IF;

  -- Adicionar coluna external_id em contacts se não existir
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'contacts' AND column_name = 'external_id'
  ) THEN
    ALTER TABLE contacts ADD COLUMN external_id VARCHAR(255);
    CREATE INDEX idx_contacts_external ON contacts(external_id);
  END IF;
END $$;

-- Inserir dados de exemplo (opcional - comentado)
-- INSERT INTO integrations (tenant_id, provider, status, config) VALUES
-- ((SELECT id FROM tenants LIMIT 1), 'whatsapp', 'disconnected', '{"instanceName": "primeflow-instance"}'),
-- ((SELECT id FROM tenants LIMIT 1), 'facebook', 'disconnected', '{"pageId": ""}'),
-- ((SELECT id FROM tenants LIMIT 1), 'instagram', 'disconnected', '{"accountId": ""}');

-- Comentários nas tabelas
COMMENT ON TABLE integrations IS 'Armazena configurações de integrações com providers externos';
COMMENT ON TABLE webhook_logs IS 'Log de todos os webhooks recebidos para auditoria';
COMMENT ON TABLE messages IS 'Todas as mensagens enviadas e recebidas';
COMMENT ON TABLE conversations IS 'Conversas agrupadas por contato e provider';

-- Permissões (ajustar conforme necessário)
-- GRANT SELECT, INSERT, UPDATE, DELETE ON integrations TO primeflow_api;
-- GRANT SELECT, INSERT, UPDATE, DELETE ON webhook_logs TO primeflow_api;
-- GRANT SELECT, INSERT, UPDATE, DELETE ON messages TO primeflow_api;
-- GRANT SELECT, INSERT, UPDATE, DELETE ON conversations TO primeflow_api;

-- ============================================================
-- Fim da Migration
-- ============================================================

