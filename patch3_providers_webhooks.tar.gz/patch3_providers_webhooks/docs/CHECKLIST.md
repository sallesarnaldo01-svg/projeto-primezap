# ✅ Checklist de Validação - Patch 3

Use este checklist para garantir que o Patch 3 foi instalado e configurado corretamente.

## 📦 Instalação

### Arquivos Backend

- [ ] `apps/api/src/services/whatsapp.provider.ts` existe
- [ ] `apps/api/src/services/facebook.provider.ts` existe
- [ ] `apps/api/src/services/instagram.provider.ts` existe
- [ ] `apps/api/src/webhooks/webhooks.controller.ts` existe

### Rotas Adicionadas

- [ ] Import do `webhooksController` adicionado em `apps/api/src/index.ts`
- [ ] Rota `POST /webhooks/whatsapp/:tenantId` adicionada
- [ ] Rota `GET /webhooks/facebook/:tenantId` adicionada
- [ ] Rota `POST /webhooks/facebook/:tenantId` adicionada
- [ ] Rota `GET /webhooks/instagram/:tenantId` adicionada
- [ ] Rota `POST /webhooks/instagram/:tenantId` adicionada
- [ ] Rota `POST /webhooks/test/:tenantId` adicionada
- [ ] Rota `GET /webhooks/status/:tenantId` adicionada

### Dependências

- [ ] `axios` instalado
- [ ] `qrcode` instalado
- [ ] `@types/qrcode` instalado (dev)

### Banco de Dados

- [ ] Migration `001_integrations_webhooks.sql` executada
- [ ] Tabela `integrations` criada
- [ ] Tabela `webhook_logs` criada
- [ ] Tabela `messages` criada
- [ ] Tabela `conversations` criada
- [ ] Índices criados corretamente
- [ ] Triggers funcionando

### Variáveis de Ambiente

- [ ] `EVOLUTION_API_URL` configurada
- [ ] `EVOLUTION_API_KEY` configurada
- [ ] `FACEBOOK_APP_ID` configurada
- [ ] `FACEBOOK_APP_SECRET` configurada
- [ ] `FACEBOOK_PAGE_ACCESS_TOKEN` configurada
- [ ] `INSTAGRAM_ACCOUNT_ID` configurada
- [ ] `WEBHOOK_BASE_URL` configurada

### Compilação

- [ ] Projeto compila sem erros TypeScript
- [ ] Sem erros de imports
- [ ] Sem erros de tipos
- [ ] Build bem-sucedido

---

## 🔧 Configuração WhatsApp

### Evolution API

- [ ] Evolution API está rodando (própria ou terceirizada)
- [ ] URL da API está acessível
- [ ] API Key está correta
- [ ] Teste de conexão bem-sucedido:
  ```bash
  curl https://sua-evolution-api.com/instance/fetchInstances \
    -H "apikey: sua-key"
  ```

### Instância WhatsApp

- [ ] Instância criada via API
- [ ] QR Code gerado
- [ ] QR Code escaneado com WhatsApp
- [ ] Status mostra "connected"
- [ ] Webhook configurado na Evolution API

### Testes WhatsApp

- [ ] Enviar mensagem de texto funciona
- [ ] Enviar imagem funciona
- [ ] Enviar vídeo funciona
- [ ] Enviar áudio funciona
- [ ] Enviar documento funciona
- [ ] Receber mensagem salva no banco
- [ ] Webhook recebe evento MESSAGES_UPSERT
- [ ] Webhook recebe evento CONNECTION_UPDATE
- [ ] Status de mensagem atualiza (enviada, entregue, lida)

---

## 🔧 Configuração Facebook

### Facebook App

- [ ] App criado em https://developers.facebook.com
- [ ] Tipo de app: "Business"
- [ ] Produto "Messenger" adicionado
- [ ] Página do Facebook conectada
- [ ] Page Access Token gerado
- [ ] App ID anotado
- [ ] App Secret anotado

### Webhook Facebook

- [ ] URL do webhook configurada: `https://api.primezapia.com/webhooks/facebook/TENANT_ID`
- [ ] Verify Token: `primeflow_verify`
- [ ] Verificação do webhook bem-sucedida (✅ verde no Facebook)
- [ ] Eventos subscritos:
  - [ ] messages
  - [ ] messaging_postbacks
  - [ ] messaging_optins
  - [ ] message_deliveries
  - [ ] message_reads

### Testes Facebook

- [ ] Enviar mensagem de texto funciona
- [ ] Enviar imagem funciona
- [ ] Enviar vídeo funciona
- [ ] Enviar áudio funciona
- [ ] Enviar arquivo funciona
- [ ] Receber mensagem salva no banco
- [ ] Webhook recebe mensagens
- [ ] Perfil do usuário é buscado corretamente
- [ ] Status de entrega atualiza
- [ ] Status de leitura atualiza
- [ ] Marcar como lida funciona
- [ ] Indicador de digitação funciona

---

## 🔧 Configuração Instagram

### Instagram Business

- [ ] Conta do Instagram é Business ou Creator
- [ ] Conta conectada a uma Página do Facebook
- [ ] Instagram Account ID anotado

### Webhook Instagram

- [ ] Produto "Instagram" adicionado ao Facebook App
- [ ] Conta do Instagram conectada
- [ ] URL do webhook configurada: `https://api.primezapia.com/webhooks/instagram/TENANT_ID`
- [ ] Verify Token: `primeflow_verify`
- [ ] Verificação do webhook bem-sucedida
- [ ] Eventos subscritos:
  - [ ] messages
  - [ ] messaging_postbacks

### Testes Instagram

- [ ] Enviar mensagem de texto funciona
- [ ] Enviar imagem funciona
- [ ] Receber mensagem salva no banco
- [ ] Webhook recebe mensagens
- [ ] Postbacks (botões) funcionam

---

## 🔒 Segurança

### HTTPS/SSL

- [ ] Domínio possui certificado SSL válido
- [ ] Webhooks acessíveis via HTTPS
- [ ] Certificado não expirado
- [ ] Sem erros de certificado

### Validação de Assinaturas

- [ ] Validação de assinatura do Facebook ativa
- [ ] Validação de assinatura do Instagram ativa
- [ ] App Secret correto no .env
- [ ] Testes de validação passando

### Rate Limiting

- [ ] Rate limiting configurado (recomendado)
- [ ] Limite: 100 requisições/minuto por IP
- [ ] Logs de rate limiting funcionando

---

## 🧪 Testes de Integração

### Teste End-to-End WhatsApp

1. [ ] Conectar WhatsApp (escanear QR Code)
2. [ ] Enviar mensagem de teste do sistema para um número
3. [ ] Receber resposta do número
4. [ ] Verificar mensagem salva no banco:
   ```sql
   SELECT * FROM messages 
   WHERE provider = 'whatsapp' 
   ORDER BY created_at DESC 
   LIMIT 10;
   ```
5. [ ] Verificar conversa criada:
   ```sql
   SELECT * FROM conversations 
   WHERE provider = 'whatsapp' 
   ORDER BY last_message_at DESC 
   LIMIT 5;
   ```

### Teste End-to-End Facebook

1. [ ] Configurar webhook no Facebook
2. [ ] Enviar mensagem de teste da Página para um usuário
3. [ ] Receber resposta do usuário
4. [ ] Verificar mensagem salva no banco
5. [ ] Verificar conversa criada

### Teste End-to-End Instagram

1. [ ] Configurar webhook no Instagram
2. [ ] Enviar mensagem de teste do Instagram para um usuário
3. [ ] Receber resposta do usuário
4. [ ] Verificar mensagem salva no banco
5. [ ] Verificar conversa criada

### Teste de Webhook Manual

```bash
# Testar webhook WhatsApp
curl -X POST http://localhost:3333/webhooks/test/SEU_TENANT_ID \
  -H "Content-Type: application/json" \
  -d '{
    "provider": "whatsapp",
    "event": {
      "event": "MESSAGES_UPSERT",
      "data": {
        "messages": [{
          "key": { "remoteJid": "5511999999999@s.whatsapp.net", "fromMe": false },
          "message": { "conversation": "Teste de webhook" },
          "messageTimestamp": 1234567890
        }]
      }
    }
  }'
```

- [ ] Webhook de teste retorna sucesso
- [ ] Mensagem de teste salva no banco
- [ ] Log de webhook criado

---

## 📊 Monitoramento

### Logs

- [ ] Logs de aplicação funcionando
- [ ] Logs de webhook salvos em `webhook_logs`
- [ ] Logs de erro capturados
- [ ] Comando de visualização de logs:
  ```bash
  tail -f apps/api/logs/app.log
  ```

### Status de Integrações

- [ ] Endpoint `/webhooks/status/:tenantId` funciona
- [ ] Retorna status de todas as integrações
- [ ] Mostra última sincronização
- [ ] Mostra erros se houver

### Banco de Dados

- [ ] Mensagens sendo salvas corretamente
- [ ] Conversas sendo atualizadas
- [ ] Contatos sendo criados/atualizados
- [ ] Logs de webhook sendo salvos
- [ ] Índices performando bem (verificar com EXPLAIN)

---

## 🚨 Troubleshooting

### Se WhatsApp não conecta:

- [ ] Verificar se Evolution API está rodando
- [ ] Verificar URL e API Key
- [ ] Verificar logs da Evolution API
- [ ] Tentar recriar instância

### Se Facebook webhook falha:

- [ ] Verificar se URL está acessível publicamente
- [ ] Verificar se HTTPS está funcionando
- [ ] Verificar Verify Token
- [ ] Verificar logs do servidor
- [ ] Verificar App Secret

### Se mensagens não são recebidas:

- [ ] Verificar se webhook está configurado
- [ ] Verificar se eventos estão subscritos
- [ ] Verificar logs de webhook
- [ ] Testar webhook manualmente
- [ ] Verificar se tenant_id está correto

---

## ✅ Validação Final

### Critérios de Aceitação

- [ ] Todas as 3 integrações funcionando
- [ ] Envio de mensagens funciona em todos os canais
- [ ] Recebimento de mensagens funciona em todos os canais
- [ ] Mensagens sendo salvas no banco
- [ ] Conversas sendo criadas/atualizadas
- [ ] Webhooks recebendo eventos
- [ ] Sem erros de compilação
- [ ] Sem erros em runtime
- [ ] Documentação completa
- [ ] Testes passando

### Métricas de Sucesso

- [ ] 100% das integrações conectadas
- [ ] 0 erros de compilação
- [ ] < 1% de falha em webhooks
- [ ] < 100ms de latência média
- [ ] 100% de mensagens persistidas

---

## 📝 Notas

**Data de Validação**: _______________

**Validado por**: _______________

**Observações**:
```
_________________________________________________________________
_________________________________________________________________
_________________________________________________________________
```

**Status Final**: 
- [ ] ✅ Aprovado - Pronto para produção
- [ ] ⚠️ Aprovado com ressalvas - Documentar issues
- [ ] ❌ Reprovado - Necessita correções

---

**Versão do Checklist**: 1.0.0  
**Última Atualização**: 12/10/2025

