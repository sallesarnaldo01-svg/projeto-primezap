# 🔧 Guia de Configuração Completo - Patch 3

Este guia detalha passo a passo como configurar todas as integrações do Patch 3.

---

## 📋 Índice

1. [Pré-requisitos](#pré-requisitos)
2. [Configuração do WhatsApp](#configuração-do-whatsapp)
3. [Configuração do Facebook](#configuração-do-facebook)
4. [Configuração do Instagram](#configuração-do-instagram)
5. [Configuração de Produção](#configuração-de-produção)
6. [Troubleshooting](#troubleshooting)

---

## Pré-requisitos

Antes de começar, certifique-se de ter:

### Requisitos Técnicos

| Item | Versão Mínima | Verificação |
|------|---------------|-------------|
| Node.js | 18.0.0 | `node --version` |
| PostgreSQL | 14.0 | `psql --version` |
| pnpm | 8.0.0 | `pnpm --version` |
| Domínio com SSL | - | Certificado válido |

### Requisitos de Negócio

- Conta do WhatsApp Business (número dedicado)
- Página do Facebook (para Messenger)
- Conta do Instagram Business ou Creator
- Domínio público com HTTPS configurado

### Acesso a Plataformas

- [ ] Acesso ao painel do Facebook Developers
- [ ] Acesso à página do Facebook que será usada
- [ ] Acesso à conta do Instagram Business
- [ ] Acesso ao servidor onde está o Primeflow-Hub

---

## Configuração do WhatsApp

### Opção 1: Usar Evolution API Hospedada (Recomendado)

**Vantagens**: Sem necessidade de infraestrutura própria, suporte técnico, atualizações automáticas.

**Passo 1: Escolher Provedor**

Provedores recomendados:
- [Evolution API Cloud](https://evolution-api.com) - Oficial
- [Zapmee](https://zapmee.com.br) - Brasil
- [ChatWoot Cloud](https://chatwoot.com) - Internacional

**Passo 2: Criar Conta**

1. Acesse o site do provedor escolhido
2. Crie uma conta
3. Escolha um plano (geralmente há plano gratuito para testes)
4. Anote a **URL da API** fornecida
5. Anote a **API Key** fornecida

**Passo 3: Configurar no Primeflow-Hub**

Edite o arquivo `.env`:

```env
EVOLUTION_API_URL=https://api.evolution-api.com
EVOLUTION_API_KEY=sua-api-key-aqui
```

**Passo 4: Conectar WhatsApp**

Via API do Primeflow-Hub:

```bash
curl -X POST http://localhost:3333/api/integrations/whatsapp/connect \
  -H "Authorization: Bearer SEU_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "instanceName": "primeflow-instance",
    "apiUrl": "https://api.evolution-api.com",
    "apiKey": "sua-api-key-aqui"
  }'
```

Resposta esperada:
```json
{
  "success": true,
  "qrcode": "data:image/png;base64,...",
  "status": "connecting"
}
```

**Passo 5: Escanear QR Code**

1. Copie o QR Code da resposta
2. Abra o WhatsApp no celular
3. Vá em Configurações > Aparelhos Conectados
4. Toque em "Conectar um aparelho"
5. Escaneie o QR Code

**Passo 6: Verificar Conexão**

```bash
curl -X GET http://localhost:3333/api/integrations/whatsapp/status \
  -H "Authorization: Bearer SEU_TOKEN"
```

Resposta esperada:
```json
{
  "status": "connected",
  "instanceName": "primeflow-instance",
  "phone": "5511999999999"
}
```

### Opção 2: Hospedar Evolution API Própria

**Vantagens**: Controle total, sem custos recorrentes, privacidade.

**Passo 1: Instalar via Docker**

```bash
# Criar diretório
mkdir -p ~/evolution-api
cd ~/evolution-api

# Criar docker-compose.yml
cat > docker-compose.yml << 'EOF'
version: '3.8'

services:
  evolution-api:
    image: atendai/evolution-api:latest
    container_name: evolution-api
    restart: always
    ports:
      - "8080:8080"
    environment:
      - AUTHENTICATION_API_KEY=sua-api-key-super-segura
      - DATABASE_ENABLED=true
      - DATABASE_CONNECTION_URI=postgresql://postgres:password@postgres:5432/evolution
      - DATABASE_SAVE_DATA_INSTANCE=true
      - DATABASE_SAVE_DATA_NEW_MESSAGE=true
      - DATABASE_SAVE_MESSAGE_UPDATE=true
      - DATABASE_SAVE_DATA_CONTACTS=true
      - DATABASE_SAVE_DATA_CHATS=true
    depends_on:
      - postgres

  postgres:
    image: postgres:15-alpine
    container_name: evolution-postgres
    restart: always
    environment:
      - POSTGRES_USER=postgres
      - POSTGRES_PASSWORD=password
      - POSTGRES_DB=evolution
    volumes:
      - postgres_data:/var/lib/postgresql/data

volumes:
  postgres_data:
EOF

# Iniciar
docker-compose up -d

# Verificar logs
docker-compose logs -f evolution-api
```

**Passo 2: Configurar Nginx (Opcional)**

```nginx
server {
    listen 80;
    server_name evolution.seudominio.com;
    
    location / {
        return 301 https://$server_name$request_uri;
    }
}

server {
    listen 443 ssl http2;
    server_name evolution.seudominio.com;
    
    ssl_certificate /etc/letsencrypt/live/evolution.seudominio.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/evolution.seudominio.com/privkey.pem;
    
    location / {
        proxy_pass http://localhost:8080;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

**Passo 3: Obter Certificado SSL**

```bash
sudo certbot --nginx -d evolution.seudominio.com
```

**Passo 4: Testar API**

```bash
curl https://evolution.seudominio.com/instance/fetchInstances \
  -H "apikey: sua-api-key-super-segura"
```

**Passo 5: Configurar no Primeflow-Hub**

```env
EVOLUTION_API_URL=https://evolution.seudominio.com
EVOLUTION_API_KEY=sua-api-key-super-segura
```

### Configurar Webhook da Evolution API

**Importante**: Configure o webhook para que a Evolution API envie eventos para o Primeflow-Hub.

**Via API da Evolution**:

```bash
curl -X POST https://evolution.seudominio.com/webhook/set/primeflow-instance \
  -H "apikey: sua-api-key" \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://api.primezapia.com/webhooks/whatsapp/SEU_TENANT_ID",
    "webhook_by_events": true,
    "events": [
      "MESSAGES_UPSERT",
      "MESSAGES_UPDATE",
      "CONNECTION_UPDATE"
    ]
  }'
```

---

## Configuração do Facebook

### Passo 1: Criar Facebook App

1. Acesse https://developers.facebook.com/apps
2. Clique em **"Criar App"**
3. Escolha tipo: **"Business"**
4. Preencha:
   - Nome do app: `Primeflow Hub`
   - Email de contato: seu email
   - Finalidade do app: `Yourself or your own business`
5. Clique em **"Criar App"**

### Passo 2: Adicionar Produto Messenger

1. No painel do app, vá em **"Adicionar Produto"**
2. Encontre **"Messenger"** e clique em **"Configurar"**
3. Você será redirecionado para a página de configuração do Messenger

### Passo 3: Gerar Page Access Token

1. Em **"Messenger" > "Configurações"**
2. Na seção **"Tokens de Acesso"**
3. Clique em **"Adicionar ou remover páginas"**
4. Selecione a página do Facebook que deseja usar
5. Autorize as permissões solicitadas
6. Volte para **"Tokens de Acesso"**
7. Selecione sua página
8. Clique em **"Gerar Token"**
9. **Copie e salve o token** (não será mostrado novamente)

### Passo 4: Obter App ID e App Secret

1. No menu lateral, clique em **"Configurações" > "Básico"**
2. Copie o **"ID do App"**
3. Clique em **"Mostrar"** ao lado de **"Chave Secreta do App"**
4. Copie a **"Chave Secreta"**

### Passo 5: Configurar Webhook

1. Em **"Messenger" > "Configurações"**
2. Na seção **"Webhooks"**
3. Clique em **"Adicionar URL de retorno de chamada"**
4. Preencha:
   - **URL de retorno de chamada**: `https://api.primezapia.com/webhooks/facebook/SEU_TENANT_ID`
   - **Verificar token**: `primeflow_verify`
5. Clique em **"Verificar e salvar"**

**Importante**: A verificação só funcionará se:
- O Primeflow-Hub estiver rodando
- A URL estiver acessível publicamente
- HTTPS estiver configurado corretamente

### Passo 6: Subscrever Eventos

Após a verificação bem-sucedida:

1. Na mesma seção de Webhooks
2. Clique em **"Adicionar subscrições"**
3. Selecione os eventos:
   - ✅ `messages`
   - ✅ `messaging_postbacks`
   - ✅ `messaging_optins`
   - ✅ `message_deliveries`
   - ✅ `message_reads`
4. Clique em **"Salvar"**

### Passo 7: Configurar no Primeflow-Hub

Edite o arquivo `.env`:

```env
FACEBOOK_APP_ID=123456789012345
FACEBOOK_APP_SECRET=abc123def456ghi789jkl012mno345pq
FACEBOOK_PAGE_ACCESS_TOKEN=EAABsbCS1iHgBO...
```

### Passo 8: Testar Integração

**Enviar mensagem de teste**:

```bash
curl -X POST http://localhost:3333/api/integrations/facebook/send \
  -H "Authorization: Bearer SEU_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "recipientId": "USER_PSID",
    "message": {
      "text": "Olá! Esta é uma mensagem de teste do Primeflow Hub."
    }
  }'
```

**Receber mensagem**:

1. Envie uma mensagem para sua página do Facebook
2. Verifique se o webhook foi chamado
3. Verifique se a mensagem foi salva no banco:

```sql
SELECT * FROM messages 
WHERE provider = 'facebook' 
ORDER BY created_at DESC 
LIMIT 5;
```

### Passo 9: Modo de Produção (Opcional)

Para usar em produção, o app precisa ser aprovado pelo Facebook:

1. No painel do app, vá em **"Revisão do App"**
2. Adicione as permissões necessárias:
   - `pages_messaging`
   - `pages_manage_metadata`
3. Preencha os detalhes da revisão
4. Envie para revisão
5. Aguarde aprovação (pode levar alguns dias)

**Nota**: Enquanto não aprovado, o app funciona apenas para administradores, desenvolvedores e testadores do app.

---

## Configuração do Instagram

### Pré-requisitos

- Conta do Instagram deve ser **Business** ou **Creator**
- Conta do Instagram deve estar conectada a uma **Página do Facebook**
- Facebook App já criado (do passo anterior)

### Passo 1: Converter Conta para Business

Se sua conta ainda não é Business:

1. Abra o Instagram no celular
2. Vá em **Configurações** > **Conta**
3. Toque em **Mudar para conta profissional**
4. Escolha **Business** ou **Creator**
5. Conecte a uma Página do Facebook

### Passo 2: Adicionar Produto Instagram

1. No painel do Facebook App
2. Vá em **"Adicionar Produto"**
3. Encontre **"Instagram"** e clique em **"Configurar"**

### Passo 3: Conectar Conta do Instagram

1. Em **"Instagram" > "Configurações básicas"**
2. Clique em **"Conectar conta do Instagram"**
3. Faça login com sua conta do Instagram
4. Autorize as permissões
5. Selecione a conta que deseja conectar

### Passo 4: Obter Instagram Account ID

**Método 1: Via Graph API Explorer**

1. Acesse https://developers.facebook.com/tools/explorer
2. Selecione seu app
3. Gere um token com permissões `instagram_basic`, `instagram_manage_messages`
4. Execute a query:
   ```
   GET /me/accounts
   ```
5. Encontre sua página e copie o `id`
6. Execute outra query:
   ```
   GET /{PAGE_ID}?fields=instagram_business_account
   ```
7. Copie o `instagram_business_account.id`

**Método 2: Via API**

```bash
curl -X GET "https://graph.facebook.com/v18.0/me/accounts?access_token=SEU_PAGE_TOKEN" \
  | jq '.data[0].id' \
  | xargs -I {} curl -X GET "https://graph.facebook.com/v18.0/{}?fields=instagram_business_account&access_token=SEU_PAGE_TOKEN"
```

### Passo 5: Configurar Webhook

1. Em **"Instagram" > "Configurações"**
2. Na seção **"Webhooks"**
3. Clique em **"Adicionar URL de retorno de chamada"**
4. Preencha:
   - **URL**: `https://api.primezapia.com/webhooks/instagram/SEU_TENANT_ID`
   - **Verificar token**: `primeflow_verify`
5. Clique em **"Verificar e salvar"**

### Passo 6: Subscrever Eventos

1. Após verificação bem-sucedida
2. Clique em **"Adicionar subscrições"**
3. Selecione:
   - ✅ `messages`
   - ✅ `messaging_postbacks`
4. Clique em **"Salvar"**

### Passo 7: Configurar no Primeflow-Hub

Edite o arquivo `.env`:

```env
INSTAGRAM_ACCOUNT_ID=17841405309211844
```

**Nota**: Use o mesmo `FACEBOOK_APP_ID`, `FACEBOOK_APP_SECRET` e `FACEBOOK_PAGE_ACCESS_TOKEN` do Facebook.

### Passo 8: Testar Integração

**Enviar mensagem de teste**:

```bash
curl -X POST http://localhost:3333/api/integrations/instagram/send \
  -H "Authorization: Bearer SEU_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "recipientId": "USER_IGID",
    "message": {
      "text": "Olá! Esta é uma mensagem de teste do Primeflow Hub."
    }
  }'
```

**Receber mensagem**:

1. Envie uma mensagem para sua conta do Instagram
2. Verifique se o webhook foi chamado
3. Verifique se a mensagem foi salva no banco

---

## Configuração de Produção

### HTTPS/SSL Obrigatório

Webhooks do Facebook e Instagram **só funcionam com HTTPS**.

**Configurar Let's Encrypt**:

```bash
# Instalar Certbot
sudo apt update
sudo apt install certbot python3-certbot-nginx

# Obter certificado
sudo certbot --nginx -d api.primezapia.com

# Renovação automática
sudo certbot renew --dry-run
```

### Nginx Configuration

```nginx
# Configuração completa para produção
upstream primeflow_backend {
    server localhost:3333;
    keepalive 64;
}

server {
    listen 80;
    server_name api.primezapia.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name api.primezapia.com;
    
    # SSL
    ssl_certificate /etc/letsencrypt/live/api.primezapia.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.primezapia.com/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    
    # Logs
    access_log /var/log/nginx/primeflow_access.log;
    error_log /var/log/nginx/primeflow_error.log;
    
    # Webhooks (públicos)
    location /webhooks/ {
        proxy_pass http://primeflow_backend;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Timeout maior para webhooks
        proxy_read_timeout 60s;
        proxy_connect_timeout 60s;
        
        # Limitar tamanho do body
        client_max_body_size 10M;
    }
    
    # API (autenticada)
    location /api/ {
        proxy_pass http://primeflow_backend;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

### Rate Limiting

Adicione rate limiting para proteger os webhooks:

```typescript
// apps/api/src/index.ts
import rateLimit from 'express-rate-limit';

const webhookLimiter = rateLimit({
  windowMs: 1 * 60 * 1000, // 1 minuto
  max: 100, // 100 requisições por minuto
  message: 'Too many requests from this IP',
  standardHeaders: true,
  legacyHeaders: false,
});

app.use('/webhooks/', webhookLimiter);
```

### Monitoramento

**PM2 para manter o processo rodando**:

```bash
# Instalar PM2
npm install -g pm2

# Iniciar aplicação
cd /home/administrator/unified/primeflow-hub-main
pm2 start "pnpm dev" --name primeflow-api

# Salvar configuração
pm2 save

# Iniciar no boot
pm2 startup
```

**Logs**:

```bash
# Ver logs em tempo real
pm2 logs primeflow-api

# Ver logs de webhook
tail -f apps/api/logs/webhook.log
```

---

## Troubleshooting

### WhatsApp não conecta

**Sintoma**: QR Code não aparece ou não conecta após escanear.

**Soluções**:

1. Verificar se Evolution API está rodando:
   ```bash
   curl https://sua-evolution-api.com/instance/fetchInstances \
     -H "apikey: sua-key"
   ```

2. Verificar logs da Evolution API:
   ```bash
   docker logs evolution-api
   ```

3. Recriar instância:
   ```bash
   # Deletar instância antiga
   curl -X DELETE https://sua-evolution-api.com/instance/delete/primeflow-instance \
     -H "apikey: sua-key"
   
   # Criar nova
   curl -X POST https://sua-evolution-api.com/instance/create \
     -H "apikey: sua-key" \
     -H "Content-Type: application/json" \
     -d '{"instanceName": "primeflow-instance", "qrcode": true}'
   ```

### Facebook webhook não verifica

**Sintoma**: Erro ao tentar verificar webhook no Facebook.

**Soluções**:

1. Verificar se URL está acessível:
   ```bash
   curl https://api.primezapia.com/webhooks/facebook/SEU_TENANT_ID
   ```

2. Verificar logs do servidor:
   ```bash
   tail -f apps/api/logs/app.log
   ```

3. Verificar Verify Token:
   - Deve ser exatamente `primeflow_verify`
   - Case-sensitive

4. Testar manualmente:
   ```bash
   curl "https://api.primezapia.com/webhooks/facebook/SEU_TENANT_ID?hub.mode=subscribe&hub.challenge=test&hub.verify_token=primeflow_verify"
   ```

### Mensagens não são recebidas

**Sintoma**: Webhook configurado, mas mensagens não chegam.

**Soluções**:

1. Verificar se eventos estão subscritos no Facebook

2. Verificar logs de webhook:
   ```sql
   SELECT * FROM webhook_logs 
   ORDER BY created_at DESC 
   LIMIT 10;
   ```

3. Testar webhook manualmente:
   ```bash
   curl -X POST https://api.primezapia.com/webhooks/test/SEU_TENANT_ID \
     -H "Content-Type: application/json" \
     -d '{"provider": "facebook", "event": {"test": true}}'
   ```

4. Verificar se tenant_id está correto

### Erro de assinatura inválida

**Sintoma**: `Invalid signature` nos logs.

**Soluções**:

1. Verificar App Secret no `.env`
2. Verificar se body está sendo parseado como JSON
3. Adicionar middleware:
   ```typescript
   app.use(express.json());
   ```

---

**Versão**: 1.0.0  
**Última Atualização**: 12/10/2025

