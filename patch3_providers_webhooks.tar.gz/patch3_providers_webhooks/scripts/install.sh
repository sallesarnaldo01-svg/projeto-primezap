#!/bin/bash

###############################################################################
# Patch 3: Providers e Webhooks - Script de Instalação
# Primeflow-Hub
# Versão: 1.1.0
###############################################################################

set -e

# Cores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Banner
echo "═══════════════════════════════════════════════════════════"
echo "  🚀 Patch 3: Providers e Webhooks - Instalação (v1.1.0)"
echo "  Primeflow-Hub - Integrações Omnichannel"
echo "═══════════════════════════════════════════════════════════"
echo ""

# Verificar argumentos
if [ -z "$1" ]; then
    log_error "Uso: $0 <caminho-do-projeto>"
    log_info "Exemplo: $0 /home/administrator/unified/primeflow-hub-main"
    exit 1
fi

PROJECT_PATH="$1"
PATCH_DIR=$(pwd)

if [ ! -d "$PROJECT_PATH" ]; then
    log_error "Projeto não encontrado: $PROJECT_PATH"
    exit 1
fi

log_info "Projeto encontrado: $PROJECT_PATH"

# Criar backup
BACKUP_DIR="$PROJECT_PATH/../backup_patch3_$(date +%Y%m%d_%H%M%S)"
log_info "Criando backup em: $BACKUP_DIR"
mkdir -p "$BACKUP_DIR"
cp -r "$PROJECT_PATH/apps/api/src/services" "$BACKUP_DIR/" 2>/dev/null || true
cp -r "$PROJECT_PATH/apps/api/src/webhooks" "$BACKUP_DIR/" 2>/dev/null || true
log_success "Backup criado!"

# Passo 1: Copiar Providers
log_info "Passo 1/7: Copiando providers..."
mkdir -p "$PROJECT_PATH/apps/api/src/services"
cp backend/services/whatsapp.provider.ts "$PROJECT_PATH/apps/api/src/services/"
cp backend/services/facebook.provider.ts "$PROJECT_PATH/apps/api/src/services/"
cp backend/services/instagram.provider.ts "$PROJECT_PATH/apps/api/src/services/"
log_success "Providers copiados!"

# Passo 2: Copiar Webhooks Controller
log_info "Passo 2/7: Copiando webhooks controller..."
mkdir -p "$PROJECT_PATH/apps/api/src/webhooks"
cp backend/webhooks/webhooks.controller.ts "$PROJECT_PATH/apps/api/src/webhooks/"
log_success "Webhooks controller copiado!"

# Passo 3: Adicionar rotas
log_info "Passo 3/7: Adicionando rotas de webhooks..."
INDEX_FILE="$PROJECT_PATH/apps/api/src/index.ts"

if grep -q "webhooksController" "$INDEX_FILE"; then
    log_warning "Rotas de webhooks já existem, pulando..."
else
    log_info "Adicionando rotas..."
    
    # Adicionar import no topo
    sed -i "1i import { webhooksController } from './webhooks/webhooks.controller.js';" "$INDEX_FILE"
    
    # Adicionar rotas depois da inicialização do express
    sed -i '/const app = express();/a \
// ============================================================\
// Patch 3: Rotas de Webhooks (públicas)\
// ============================================================\
app.post("/webhooks/whatsapp/:tenantId", webhooksController.whatsapp);\
app.get("/webhooks/facebook/:tenantId", webhooksController.facebookVerify);\
app.post("/webhooks/facebook/:tenantId", webhooksController.facebook);\
app.get("/webhooks/instagram/:tenantId", webhooksController.instagramVerify);\
app.post("/webhooks/instagram/:tenantId", webhooksController.instagram);\
app.post("/webhooks/test/:tenantId", webhooksController.test);\
app.get("/webhooks/status/:tenantId", authMiddleware, webhooksController.status);\
' "$INDEX_FILE"

    log_success "Rotas adicionadas!"
fi

# Passo 4: Instalar dependências
log_info "Passo 4/7: Instalando dependências..."
cd "$PROJECT_PATH/apps/api"
if command -v pnpm &> /dev/null; then
    pnpm add axios qrcode 2>&1 | grep -v "deprecated" || true
    pnpm add -D @types/qrcode 2>&1 | grep -v "deprecated" || true
    log_success "Dependências backend instaladas!"
else
    log_warning "pnpm não encontrado, instale manualmente: pnpm add axios qrcode"
fi

# Passo 5: Aplicar Migration do Banco de Dados
log_info "Passo 5/7: Lembrete de Migration do Banco de Dados"
DB_SCRIPT="database/001_integrations_webhooks.sql"

if [ -f "$PATCH_DIR/$DB_SCRIPT" ]; then
    log_warning "A migration do banco de dados precisa ser aplicada MANUALMENTE."
    log_warning "Execute o seguinte comando, substituindo as credenciais do seu banco de dados:"
    echo ""
    echo -e "${YELLOW}PGPASSWORD=\"SUA_SENHA\" psql -h SEU_HOST -U SEU_USUARIO -d SEU_BANCO -f \"$PATCH_DIR/$DB_SCRIPT\"}${NC}"
    echo ""
    log_info "Exemplo com as credenciais padrão do Docker:"
    echo -e "${YELLOW}PGPASSWORD=\"docker\" psql -h localhost -U docker -d primeflow -f \"$PATCH_DIR/$DB_SCRIPT\"}${NC}"
    echo ""
else
    log_error "Script de migration '$DB_SCRIPT' não encontrado no diretório do patch!"
fi


# Passo 6: Configurar variáveis de ambiente
log_info "Passo 6/7: Configurando variáveis de ambiente..."
ENV_FILE="$PROJECT_PATH/.env"

if [ ! -f "$ENV_FILE" ]; then
    log_warning "Arquivo .env não encontrado, criando..."
    touch "$ENV_FILE"
fi

# Adicionar variáveis se não existirem
if ! grep -q "EVOLUTION_API_URL" "$ENV_FILE"; then
    cat >> "$ENV_FILE" << 'EOF'

# ============================================================
# Patch 3: Configurações de Integrações
# ============================================================

# WhatsApp (Evolution API)
EVOLUTION_API_URL=https://sua-evolution-api.com
EVOLUTION_API_KEY=sua-api-key

# Facebook Messenger
FACEBOOK_APP_ID=seu-app-id
FACEBOOK_APP_SECRET=seu-app-secret
FACEBOOK_PAGE_ACCESS_TOKEN=seu-page-token

# Instagram Direct
INSTAGRAM_ACCOUNT_ID=seu-instagram-id

# Webhook Base URL
WEBHOOK_BASE_URL=https://api.primezapia.com
EOF

    log_success "Variáveis de ambiente adicionadas!"
    log_warning "IMPORTANTE: Edite o arquivo .env e configure suas credenciais!"
else
    log_warning "Variáveis de ambiente já existem, pulando..."
fi

# Passo 7: Validar instalação
log_info "Passo 7/7: Validando instalação..."

VALIDATION_ERRORS=0

# Verificar providers
if [ ! -f "$PROJECT_PATH/apps/api/src/services/whatsapp.provider.ts" ]; then
    log_error "WhatsApp provider não encontrado!"
    VALIDATION_ERRORS=$((VALIDATION_ERRORS + 1))
fi

if [ ! -f "$PROJECT_PATH/apps/api/src/services/facebook.provider.ts" ]; then
    log_error "Facebook provider não encontrado!"
    VALIDATION_ERRORS=$((VALIDATION_ERRORS + 1))
fi

if [ ! -f "$PROJECT_PATH/apps/api/src/services/instagram.provider.ts" ]; then
    log_error "Instagram provider não encontrado!"
    VALIDATION_ERRORS=$((VALIDATION_ERRORS + 1))
fi

# Verificar webhooks controller
if [ ! -f "$PROJECT_PATH/apps/api/src/webhooks/webhooks.controller.ts" ]; then
    log_error "Webhooks controller não encontrado!"
    VALIDATION_ERRORS=$((VALIDATION_ERRORS + 1))
fi

if [ $VALIDATION_ERRORS -eq 0 ]; then
    log_success "Validação concluída com sucesso!"
else
    log_error "Validação falhou com $VALIDATION_ERRORS erros!"
    exit 1
fi

# Resumo
echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  ✅ Patch 3 Instalado com Sucesso!"
echo "═══════════════════════════════════════════════════════════"
echo ""
log_info "Arquivos instalados:"
echo "  ✅ backend/services/whatsapp.provider.ts"
echo "  ✅ backend/services/facebook.provider.ts"
echo "  ✅ backend/services/instagram.provider.ts"
echo "  ✅ backend/webhooks/webhooks.controller.ts"
echo "  ✅ 7 rotas de webhooks adicionadas"
echo ""
log_info "Backup criado em: $BACKUP_DIR"
echo ""
log_warning "⚠️  PRÓXIMOS PASSOS OBRIGATÓRIOS:"
echo ""
echo "1. APLICAR A MIGRATION DO BANCO DE DADOS (comando mostrado acima)."
echo ""
echo "2. Editar arquivo .env e configurar credenciais:"
echo "   nano $PROJECT_PATH/.env"
echo ""
echo "3. Consultar o GUIA DE CONFIGURAÇÃO para conectar os canais:"
echo "   - WhatsApp (Evolution API)"
echo "   - Facebook Messenger"
echo "   - Instagram Direct"
echo ""
echo "4. Testar as integrações conforme o CHECKLIST."
echo ""
log_info "Comandos úteis:"
echo "  cd $PROJECT_PATH"
echo "  pnpm dev                    # Rodar projeto"
echo "  tail -f apps/api/logs/app.log  # Ver logs"
echo ""
log_success "Instalação concluída! 🎉"
echo ""
log_warning "Leia a documentação na pasta 'docs' para instruções detalhadas!"
echo ""

