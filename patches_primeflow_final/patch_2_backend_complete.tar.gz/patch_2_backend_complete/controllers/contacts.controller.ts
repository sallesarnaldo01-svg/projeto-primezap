import { Request, Response } from 'express';
import { prisma } from '../lib/prisma.js';
import { logger } from '../lib/logger.js';
import { AuthRequest } from '../middleware/auth.js';

/**
 * GET /api/contacts
 * Lista todos os contatos
 */
export async function getContacts(req: AuthRequest, res: Response) {
  try {
    const userId = req.user?.id;
    const { search, tag, page = '1', limit = '50', sortBy = 'createdAt', order = 'desc' } = req.query;

    const where: any = userId ? { userId } : {};
    
    if (search) {
      where.OR = [
        { name: { contains: search as string, mode: 'insensitive' } },
        { email: { contains: search as string, mode: 'insensitive' } },
        { phone: { contains: search as string, mode: 'insensitive' } }
      ];
    }
    
    if (tag) {
      where.tags = {
        has: tag as string
      };
    }

    const skip = (parseInt(page as string) - 1) * parseInt(limit as string);

    const [contacts, total] = await Promise.all([
      prisma.contact.findMany({
        where,
        orderBy: { [sortBy as string]: order },
        skip,
        take: parseInt(limit as string),
        include: {
          _count: {
            select: {
              conversations: true,
              deals: true
            }
          }
        }
      }),
      prisma.contact.count({ where })
    ]);

    res.json({
      contacts,
      pagination: {
        page: parseInt(page as string),
        limit: parseInt(limit as string),
        total,
        pages: Math.ceil(total / parseInt(limit as string))
      }
    });
  } catch (error) {
    logger.error({ error }, 'Error fetching contacts');
    res.status(500).json({ error: 'Erro ao buscar contatos' });
  }
}

/**
 * GET /api/contacts/:id
 * Busca um contato específico
 */
export async function getContact(req: AuthRequest, res: Response) {
  try {
    const { id } = req.params;
    const userId = req.user?.id;

    const contact = await prisma.contact.findFirst({
      where: {
        id,
        ...(userId ? { userId } : {})
      },
      include: {
        conversations: {
          orderBy: { createdAt: 'desc' },
          take: 10,
          select: {
            id: true,
            platform: true,
            status: true,
            lastMessageAt: true,
            createdAt: true
          }
        },
        deals: {
          orderBy: { createdAt: 'desc' },
          take: 5,
          select: {
            id: true,
            title: true,
            value: true,
            stage: true,
            createdAt: true
          }
        },
        _count: {
          select: {
            conversations: true,
            deals: true
          }
        }
      }
    });

    if (!contact) {
      return res.status(404).json({ error: 'Contato não encontrado' });
    }

    res.json(contact);
  } catch (error) {
    logger.error({ error }, 'Error fetching contact');
    res.status(500).json({ error: 'Erro ao buscar contato' });
  }
}

/**
 * POST /api/contacts
 * Cria um novo contato
 */
export async function createContact(req: AuthRequest, res: Response) {
  try {
    const userId = req.user?.id;
    const { name, email, phone, avatar, tags, customFields, notes } = req.body;

    if (!name) {
      return res.status(400).json({ error: 'Nome é obrigatório' });
    }

    // Verificar se já existe contato com mesmo email ou telefone
    if (email || phone) {
      const existing = await prisma.contact.findFirst({
        where: {
          ...(userId ? { userId } : {}),
          OR: [
            ...(email ? [{ email }] : []),
            ...(phone ? [{ phone }] : [])
          ]
        }
      });

      if (existing) {
        return res.status(409).json({ 
          error: 'Contato já existe com este email ou telefone',
          existingContact: existing
        });
      }
    }

    const contact = await prisma.contact.create({
      data: {
        name,
        email,
        phone,
        avatar,
        tags: tags || [],
        customFields: customFields || {},
        notes,
        userId: userId!
      }
    });

    // Registrar atividade
    await prisma.activity.create({
      data: {
        type: 'CONTACT_CREATED',
        description: `Contato "${name}" criado`,
        userId: userId!,
        metadata: { contactId: contact.id }
      }
    });

    logger.info({ contactId: contact.id }, 'Contact created');
    res.status(201).json(contact);
  } catch (error) {
    logger.error({ error }, 'Error creating contact');
    res.status(500).json({ error: 'Erro ao criar contato' });
  }
}

/**
 * PUT /api/contacts/:id
 * Atualiza um contato
 */
export async function updateContact(req: AuthRequest, res: Response) {
  try {
    const { id } = req.params;
    const userId = req.user?.id;
    const { name, email, phone, avatar, tags, customFields, notes } = req.body;

    const existing = await prisma.contact.findFirst({
      where: {
        id,
        ...(userId ? { userId } : {})
      }
    });

    if (!existing) {
      return res.status(404).json({ error: 'Contato não encontrado' });
    }

    const contact = await prisma.contact.update({
      where: { id },
      data: {
        ...(name && { name }),
        ...(email !== undefined && { email }),
        ...(phone !== undefined && { phone }),
        ...(avatar !== undefined && { avatar }),
        ...(tags && { tags }),
        ...(customFields && { customFields }),
        ...(notes !== undefined && { notes })
      }
    });

    // Registrar atividade
    await prisma.activity.create({
      data: {
        type: 'CONTACT_UPDATED',
        description: `Contato "${contact.name}" atualizado`,
        userId: userId!,
        metadata: { contactId: contact.id }
      }
    });

    logger.info({ contactId: contact.id }, 'Contact updated');
    res.json(contact);
  } catch (error) {
    logger.error({ error }, 'Error updating contact');
    res.status(500).json({ error: 'Erro ao atualizar contato' });
  }
}

/**
 * DELETE /api/contacts/:id
 * Deleta um contato
 */
export async function deleteContact(req: AuthRequest, res: Response) {
  try {
    const { id } = req.params;
    const userId = req.user?.id;

    const contact = await prisma.contact.findFirst({
      where: {
        id,
        ...(userId ? { userId } : {})
      }
    });

    if (!contact) {
      return res.status(404).json({ error: 'Contato não encontrado' });
    }

    // Verificar se tem conversas ou deals associados
    const hasRelations = await prisma.contact.findFirst({
      where: { id },
      select: {
        _count: {
          select: {
            conversations: true,
            deals: true
          }
        }
      }
    });

    if (hasRelations && (hasRelations._count.conversations > 0 || hasRelations._count.deals > 0)) {
      return res.status(409).json({ 
        error: 'Não é possível deletar contato com conversas ou deals associados',
        counts: hasRelations._count
      });
    }

    await prisma.contact.delete({
      where: { id }
    });

    // Registrar atividade
    await prisma.activity.create({
      data: {
        type: 'CONTACT_DELETED',
        description: `Contato "${contact.name}" deletado`,
        userId: userId!,
        metadata: { contactId: id }
      }
    });

    logger.info({ contactId: id }, 'Contact deleted');
    res.json({ message: 'Contato deletado com sucesso' });
  } catch (error) {
    logger.error({ error }, 'Error deleting contact');
    res.status(500).json({ error: 'Erro ao deletar contato' });
  }
}

/**
 * POST /api/contacts/:id/tags
 * Adiciona tags a um contato
 */
export async function addTags(req: AuthRequest, res: Response) {
  try {
    const { id } = req.params;
    const { tags } = req.body;
    const userId = req.user?.id;

    if (!Array.isArray(tags) || tags.length === 0) {
      return res.status(400).json({ error: 'Tags devem ser um array não vazio' });
    }

    const contact = await prisma.contact.findFirst({
      where: {
        id,
        ...(userId ? { userId } : {})
      }
    });

    if (!contact) {
      return res.status(404).json({ error: 'Contato não encontrado' });
    }

    const updatedContact = await prisma.contact.update({
      where: { id },
      data: {
        tags: {
          push: tags
        }
      }
    });

    logger.info({ contactId: id, tags }, 'Tags added to contact');
    res.json(updatedContact);
  } catch (error) {
    logger.error({ error }, 'Error adding tags');
    res.status(500).json({ error: 'Erro ao adicionar tags' });
  }
}

/**
 * DELETE /api/contacts/:id/tags
 * Remove tags de um contato
 */
export async function removeTags(req: AuthRequest, res: Response) {
  try {
    const { id } = req.params;
    const { tags } = req.body;
    const userId = req.user?.id;

    if (!Array.isArray(tags) || tags.length === 0) {
      return res.status(400).json({ error: 'Tags devem ser um array não vazio' });
    }

    const contact = await prisma.contact.findFirst({
      where: {
        id,
        ...(userId ? { userId } : {})
      }
    });

    if (!contact) {
      return res.status(404).json({ error: 'Contato não encontrado' });
    }

    const newTags = contact.tags.filter(tag => !tags.includes(tag));

    const updatedContact = await prisma.contact.update({
      where: { id },
      data: {
        tags: newTags
      }
    });

    logger.info({ contactId: id, tags }, 'Tags removed from contact');
    res.json(updatedContact);
  } catch (error) {
    logger.error({ error }, 'Error removing tags');
    res.status(500).json({ error: 'Erro ao remover tags' });
  }
}

