#!/bin/bash

set -e

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

PROJECT_DIR="$1"
PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ -z "$PROJECT_DIR" ]; then
    log_error "Uso: $0 <caminho-do-projeto>"
    log_info "Exemplo: $0 /home/administrator/unified/primeflow-hub-main"
    exit 1
fi

if [ ! -d "$PROJECT_DIR" ]; then
    log_error "Diretório não encontrado: $PROJECT_DIR"
    exit 1
fi

log_info "========================================="
log_info "PATCH 2 - BACKEND COMPLETO"
log_info "========================================="
log_info ""
log_info "Projeto: $PROJECT_DIR"
log_info "Patch: $PATCH_DIR"
log_info ""
log_warning "PRÉ-REQUISITO: Patch 1 deve estar aplicado!"
log_info ""

# Verificar se Patch 1 foi aplicado
if [ ! -f "$PROJECT_DIR/tsconfig.api.json" ]; then
    log_error "Patch 1 não foi aplicado! Aplique o Patch 1 primeiro."
    exit 1
fi

# Fase 1: Backup
log_info "[1/6] Criando backup..."
cd "$PROJECT_DIR"
BACKUP_FILE="../backup_pre_patch2_$(date +%Y%m%d_%H%M%S).tar.gz"
tar -czf "$BACKUP_FILE" \
    --exclude=node_modules \
    --exclude=dist \
    --exclude=.next \
    --exclude=build \
    apps/api/src 2>/dev/null || true
log_success "Backup criado: $BACKUP_FILE"

# Fase 2: Copiar controllers
log_info "[2/6] Copiando novos controllers..."
CONTROLLERS_DIR="$PROJECT_DIR/apps/api/src/controllers"

if [ -d "$PATCH_DIR/controllers" ]; then
    cp "$PATCH_DIR/controllers/dashboard.controller.ts" "$CONTROLLERS_DIR/"
    cp "$PATCH_DIR/controllers/crm.controller.ts" "$CONTROLLERS_DIR/"
    cp "$PATCH_DIR/controllers/contacts.controller.ts" "$CONTROLLERS_DIR/"
    cp "$PATCH_DIR/controllers/tickets.controller.ts" "$CONTROLLERS_DIR/"
    cp "$PATCH_DIR/controllers/users.controller.ts" "$CONTROLLERS_DIR/"
    cp "$PATCH_DIR/controllers/reports.controller.ts" "$CONTROLLERS_DIR/"
    cp "$PATCH_DIR/controllers/messages.controller.ts" "$CONTROLLERS_DIR/"
    log_success "7 controllers copiados"
else
    log_error "Diretório de controllers não encontrado no patch"
    exit 1
fi

# Fase 3: Copiar rotas
log_info "[3/6] Copiando novas rotas..."
ROUTES_DIR="$PROJECT_DIR/apps/api/src/routes"

if [ -d "$PATCH_DIR/routes" ]; then
    cp "$PATCH_DIR/routes/dashboard.routes.ts" "$ROUTES_DIR/"
    cp "$PATCH_DIR/routes/crm.routes.ts" "$ROUTES_DIR/"
    cp "$PATCH_DIR/routes/contacts.routes.ts" "$ROUTES_DIR/"
    cp "$PATCH_DIR/routes/tickets.routes.ts" "$ROUTES_DIR/"
    cp "$PATCH_DIR/routes/users.routes.ts" "$ROUTES_DIR/"
    cp "$PATCH_DIR/routes/reports.routes.ts" "$ROUTES_DIR/"
    cp "$PATCH_DIR/routes/messages.routes.ts" "$ROUTES_DIR/"
    log_success "7 rotas copiadas"
else
    log_error "Diretório de rotas não encontrado no patch"
    exit 1
fi

# Fase 4: Atualizar index.ts
log_info "[4/6] Atualizando index.ts..."
if [ -f "$PATCH_DIR/scripts/update-index.sh" ]; then
    bash "$PATCH_DIR/scripts/update-index.sh" "$PROJECT_DIR"
    log_success "index.ts atualizado"
else
    log_warning "Script de atualização não encontrado, atualize manualmente"
fi

# Fase 5: Instalar dependências adicionais
log_info "[5/6] Verificando dependências..."
cd "$PROJECT_DIR"

# Verificar se bcryptjs está instalado (necessário para users.controller)
if ! npm list bcryptjs > /dev/null 2>&1; then
    log_info "Instalando bcryptjs..."
    pnpm add bcryptjs
    pnpm add -D @types/bcryptjs
fi

log_success "Dependências verificadas"

# Fase 6: Testar build
log_info "[6/6] Testando build..."
cd "$PROJECT_DIR/apps/api"

if pnpm build 2>&1 | tee /tmp/patch2_build.log | tail -15; then
    if [ -d "dist" ] && [ "$(ls -A dist)" ]; then
        log_success "Build funcionando!"
        log_info ""
        log_info "Novos controllers criados:"
        ls -1 dist/controllers/ | grep -E "(dashboard|crm|contacts|tickets|users|reports|messages)" || true
    else
        log_warning "Build executou mas dist está vazio"
    fi
else
    log_error "Build falhou. Verifique os logs acima."
    log_info ""
    log_info "Últimos erros:"
    tail -30 /tmp/patch2_build.log
    exit 1
fi

log_info ""
log_info "========================================="
log_success "✅ PATCH 2 APLICADO COM SUCESSO!"
log_info "========================================="
log_info ""
log_info "Controllers adicionados:"
log_info "  ✅ dashboard.controller.ts"
log_info "  ✅ crm.controller.ts"
log_info "  ✅ contacts.controller.ts"
log_info "  ✅ tickets.controller.ts"
log_info "  ✅ users.controller.ts"
log_info "  ✅ reports.controller.ts"
log_info "  ✅ messages.controller.ts"
log_info ""
log_info "Rotas adicionadas:"
log_info "  ✅ /api/dashboard/*"
log_info "  ✅ /api/crm/*"
log_info "  ✅ /api/contacts/*"
log_info "  ✅ /api/tickets/*"
log_info "  ✅ /api/users/*"
log_info "  ✅ /api/reports/*"
log_info "  ✅ /api/messages/*"
log_info ""
log_info "Próximo passo:"
log_info "  → Aplicar Patch 3 - Frontend Completo"
log_info ""
log_info "Para testar as novas APIs:"
log_info "  cd $PROJECT_DIR/apps/api"
log_info "  pnpm dev"
log_info ""
log_info "Exemplos de endpoints:"
log_info "  GET  http://localhost:3001/api/dashboard/metrics"
log_info "  GET  http://localhost:3001/api/crm/deals"
log_info "  GET  http://localhost:3001/api/contacts"
log_info "  GET  http://localhost:3001/api/tickets"
log_info ""

