#!/bin/bash

# Script para adicionar novas rotas ao index.ts

PROJECT_DIR="$1"
INDEX_FILE="$PROJECT_DIR/apps/api/src/index.ts"

if [ ! -f "$INDEX_FILE" ]; then
    echo "❌ Arquivo index.ts não encontrado: $INDEX_FILE"
    exit 1
fi

echo "🔧 Adicionando novas rotas ao index.ts..."

# Backup do index.ts
cp "$INDEX_FILE" "$INDEX_FILE.backup_patch2"

# Adicionar imports das novas rotas após os imports existentes
# Procurar a linha com último import de routes e adicionar depois
sed -i '/import conversationEventsRoutes/a\
import dashboardRoutes from '\''./routes/dashboard.routes.js'\'';\
import crmRoutes from '\''./routes/crm.routes.js'\'';\
import contactsRoutes from '\''./routes/contacts.routes.js'\'';\
import ticketsRoutes from '\''./routes/tickets.routes.js'\'';\
import usersRoutes from '\''./routes/users.routes.js'\'';\
import reportsRoutes from '\''./routes/reports.routes.js'\'';\
import messagesRoutes from '\''./routes/messages.routes.js'\'';' "$INDEX_FILE"

# Adicionar uso das rotas após as rotas existentes
# Procurar a linha com último app.use e adicionar depois
sed -i '/app.use('\''\/api\/conversations'\'', conversationEventsRoutes);/a\
app.use('\''\/api\/dashboard'\'', dashboardRoutes);\
app.use('\''\/api\/crm'\'', crmRoutes);\
app.use('\''\/api\/contacts'\'', contactsRoutes);\
app.use('\''\/api\/tickets'\'', ticketsRoutes);\
app.use('\''\/api\/users'\'', usersRoutes);\
app.use('\''\/api\/reports'\'', reportsRoutes);\
app.use('\''\/api\/messages'\'', messagesRoutes);' "$INDEX_FILE"

echo "✅ Rotas adicionadas ao index.ts"
echo "📝 Backup salvo em: $INDEX_FILE.backup_patch2"

